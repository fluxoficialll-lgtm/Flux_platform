
import { User, Group } from '../types';
import { authService } from './authService';
import { cryptoService } from './cryptoService';
import { db } from '@/database';

/**
 * SyncPay Service - CLIENTE (Frontend)
 * 
 * Integração Real. Sem Mocks.
 */

// Helper to safely get env var
const getApiBaseUrl = () => {
    try {
        // @ts-ignore
        const env = import.meta.env;
        return env?.VITE_API_URL || '';
    } catch (e) {
        return '';
    }
};

const BASE_URL = getApiBaseUrl();
const API_BASE = `${BASE_URL}/api/syncpay`;

const PLATFORM_FEE = 3.00;
const PLATFORM_WALLET = "nagasakitakit@gmail.com"; 

// Helper privado para extrair credenciais limpas do usuário
const getCredentials = (user: User) => {
    // PRODUCTION MODE: Strict check
    if (!user || !user.paymentConfig || !user.paymentConfig.isConnected) {
        throw new Error("O vendedor não conectou a conta SyncPay.");
    }

    const { clientId, clientSecret } = user.paymentConfig;
    
    if (!clientId || !clientSecret) {
        throw new Error("Credenciais do SyncPay incompletas ou inválidas.");
    }

    return {
        clientId: cryptoService.decryptData(clientId),
        clientSecret: cryptoService.decryptData(clientSecret)
    };
};

// Helper seguro de fetch
const safeFetch = async (url: string, options: RequestInit) => {
    try {
        const response = await fetch(url, options);
        return response;
    } catch (error: any) {
        if (error.name === 'TypeError' && error.message === 'Failed to fetch') {
            throw new Error('Não foi possível conectar ao servidor. Verifique sua conexão.');
        }
        throw error;
    }
};

export const syncPayService = {

    /**
     * Obtém as taxas atuais configuradas no servidor
     */
    getFees: async (): Promise<{ withdrawal_fee: number; platform_fee: number }> => {
        const response = await safeFetch(`${API_BASE}/fees`, { method: 'GET' });
        if (!response.ok) throw new Error("Falha ao obter taxas.");
        return await response.json();
    },

    /**
     * Testar Conexão (Chamado ao salvar configurações)
     */
    authenticate: async (clientId: string, clientSecret: string): Promise<void> => {
        try {
            const response = await safeFetch(`${API_BASE}/auth-token`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ clientId, clientSecret })
            });

            if (!response.ok) {
                const data = await response.json().catch(() => ({}));
                throw new Error(data.error || data.details || "Falha na autenticação com SyncPay.");
            }
        } catch (error: any) {
            console.error("Erro Auth:", error);
            throw error;
        }
    },

    /**
     * Criar Pagamento via Backend
     */
    createPayment: async (payer: User, group: Group): Promise<{pixCode: string, identifier: string, qrCodeImage?: string}> => {
        try {
            // 1. Identificar o Dono do Grupo (Vendedor)
            if (!group.creatorEmail) throw new Error("Grupo sem dono identificado.");
            
            const owner = db.users.get(group.creatorEmail);
            if (!owner) throw new Error("Vendedor não encontrado no banco de dados.");

            // 2. Obter credenciais do VENDEDOR (Owner)
            const { clientId, clientSecret } = getCredentials(owner);
            
            const price = parseFloat(group.price || '0');
            if (price < 6.00) throw new Error("Preço inválido (Mínimo R$ 6,00).");

            // Montar objeto payer dinamicamente (Dados do Comprador)
            const payerData: any = {
                name: payer.profile?.name || "Cliente",
                email: payer.email
            };

            if (payer.profile?.cpf) payerData.document = payer.profile.cpf;
            if (payer.profile?.phone) payerData.phone = payer.profile.phone;

            // 3. Montar Payload
            const sellerEmail = group.creatorEmail.trim().toLowerCase();
            const platformEmail = PLATFORM_WALLET.trim().toLowerCase();
            const isPlatformOwner = sellerEmail === platformEmail;
            
            let split_rules = [];

            if (!isPlatformOwner) {
                split_rules.push({
                    recipient_email: PLATFORM_WALLET,
                    amount: PLATFORM_FEE,
                    liable: true,
                    charge_processing_fee: false
                });
            }

            const payload = {
                amount: price,
                description: `Grupo VIP: ${group.name}`,
                payer: payerData,
                split_rules: split_rules.length > 0 ? split_rules : undefined
            };

            // 4. Enviar tudo para o backend processar
            const response = await safeFetch(`${API_BASE}/cash-in`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ clientId, clientSecret, payload })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || data.error || "Erro ao gerar PIX no provedor.");
            }
            
            const pixCode = data.pix_code || data.qrcode_text || data.emv;
            let qrCodeImage = data.qrcode_image || data.qrcode_base64 || data.image;
            if (qrCodeImage && !qrCodeImage.startsWith('http') && !qrCodeImage.startsWith('data:image')) {
                qrCodeImage = `data:image/png;base64,${qrCodeImage}`;
            }

            if (!pixCode) throw new Error("O provedor não retornou o código PIX.");
            
            return {
                pixCode: pixCode,
                identifier: data.transaction_id || data.id || data.transactionId,
                qrCodeImage: qrCodeImage
            };

        } catch (error: any) {
            console.error("Erro Service Pagamento:", error);
            throw error;
        }
    },

    /**
     * Solicitar Saque (Cash-out)
     */
    requestWithdrawal: async (user: User, amount: number, pixKey: string, pixKeyType: string): Promise<any> => {
        try {
            const { clientId, clientSecret } = getCredentials(user);

            // Obter taxa atualizada do servidor
            const fees = await syncPayService.getFees();
            const currentFee = fees.withdrawal_fee;

            if (amount <= currentFee) {
                throw new Error(`O valor do saque deve ser maior que a taxa atual de R$ ${currentFee.toFixed(2)}.`);
            }

            let cleanedPixKey = pixKey;
            if (['cpf', 'cnpj', 'phone', 'telefone'].includes(pixKeyType.toLowerCase())) {
                cleanedPixKey = pixKey.replace(/[^a-zA-Z0-9]/g, '');
            }

            const transferAmount = amount - currentFee;

            const payload = {
                amount: transferAmount,
                pix_key: cleanedPixKey,
                pix_key_type: pixKeyType.toUpperCase(),
                description: "Saque App Flux"
            };

            const response = await safeFetch(`${API_BASE}/cash-out`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ clientId, clientSecret, payload })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || data.error || "Erro ao processar saque no provedor.");
            }

            return data;
        } catch (error: any) {
            console.error("Erro Service Saque:", error);
            throw error;
        }
    },

    /**
     * Checar Status da Transação (Real Polling)
     */
    checkTransactionStatus: async (identifier: string, sellerEmail: string): Promise<'pending' | 'paid' | 'expired' | 'completed'> => {
        try {
            const seller = db.users.get(sellerEmail);
            if (!seller) return 'pending';

            const { clientId, clientSecret } = getCredentials(seller);

            const response = await safeFetch(`${API_BASE}/check-status`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ clientId, clientSecret, transactionId: identifier })
            });

            if (!response.ok) return 'pending';

            const data = await response.json();
            const status = (data.status || '').toLowerCase();
            
            if (['paid', 'completed', 'approved', 'settled'].includes(status)) return 'completed';
            if (['expired', 'canceled', 'failed'].includes(status)) return 'expired';

            return 'pending';
        } catch (err) {
            return 'pending';
        }
    },

    /**
     * Consultar Saldo (Wallet Balance)
     */
    getBalance: async (email: string): Promise<number> => {
        const user = db.users.get(email);
        if (!user) return 0;

        try {
            const { clientId, clientSecret } = getCredentials(user);
            
            const response = await safeFetch(`${API_BASE}/balance`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ clientId, clientSecret })
            });

            if (!response.ok) return 0;
            const data = await response.json();
            return Number(data.balance || data.amount || 0);
        } catch (e) {
            return 0;
        }
    },

    /**
     * Consultar Histórico de Vendas (Para Faturamento)
     */
    getTransactions: async (email: string): Promise<any[]> => {
        const user = db.users.get(email);
        if (!user) return [];

        try {
            const { clientId, clientSecret } = getCredentials(user);
            
            const response = await safeFetch(`${API_BASE}/transactions`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ clientId, clientSecret })
            });

            if (!response.ok) return [];
            const data = await response.json();
            return Array.isArray(data) ? data : [];
        } catch (e) {
            return [];
        }
    }
};
