
import { Post, Comment } from '../types';
import { db } from '@/database';
import { recommendationService } from './recommendationService';
import { postService } from './postService';

export const reelsService = {
  /**
   * Retrieves only posts of type 'video' (Reels).
   * Applies AI recommendation algorithm and Adult Content Filtering.
   */
  getReels: (userEmail?: string, allowAdultContent: boolean = false): Post[] => {
    const allPosts = db.posts.getAll();
    // Filter specifically for video type
    let videos = allPosts.filter(p => p.type === 'video');

    // Filter Adult Content if setting is disabled
    if (!allowAdultContent) {
        videos = videos.filter(p => !p.isAdultContent);
    }

    // AI Algorithm Integration (Always Active)
    if (userEmail) {
        return recommendationService.getRecommendedReels(videos, userEmail);
    }

    // Guest Mode: Random shuffle for exploration
    return videos.sort(() => 0.5 - Math.random());
  },

  // Wrapper para upload de video
  uploadVideo: async (file: File): Promise<string> => {
      return postService.uploadMedia(file);
  },

  /**
   * Adds a new Reel (video post) to the global storage.
   */
  addReel: (reel: Post) => {
    // Ensure strictly typed as video
    const newReel = { ...reel, type: 'video' as const };

    // --- DUPLICATE VIDEO CHECK ---
    const allPosts = db.posts.getAll();
    const isDuplicate = allPosts.some(existing => {
        // Check if video data matches exactly (Base64 or URL)
        if (existing.type === 'video' && existing.video && existing.video === newReel.video) {
            return true;
        }
        return false;
    });

    if (isDuplicate) {
        throw new Error("Este vídeo já foi postado no Reels.");
    }

    postService.addPost(newReel);
  },

  /**
   * Toggles like on a Reel.
   */
  toggleLike: (reelId: string): Post | undefined => {
    const post = db.posts.findById(reelId);

    if (post) {
      const newLiked = !post.liked;
      const updatedPost = {
        ...post,
        liked: newLiked,
        likes: post.likes + (newLiked ? 1 : -1)
      };
      
      db.posts.update(updatedPost);
      return updatedPost;
    }
    return undefined;
  },

  /**
   * Increments the view count for a Reel (Unique per user).
   */
  incrementView: (reelId: string, userEmail?: string) => {
    // Delegate to postService which handles unique view logic
    postService.incrementView(reelId, userEmail);
  },

  /**
   * Get a specific reel by ID
   */
  getReelById: (id: string): Post | undefined => {
    const reels = reelsService.getReels();
    return reels.find(r => r.id === id);
  }
};
