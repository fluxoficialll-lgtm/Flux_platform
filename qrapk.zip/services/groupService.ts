
import { Group, GroupLink, User } from '../types';
import { db } from '@/database';
import { authService } from './authService';

const API_URL = '/api/groups';

export const groupService = {
  // Busca grupos da API (Escalável)
  getGroups: async (): Promise<Group[]> => {
    // 1. Retorna cache local imediatamente para UI rápida
    const localGroups = db.groups.getAll();
    
    // 2. Busca atualização em background se possível
    try {
        const res = await fetch(API_URL);
        if (res.ok) {
            const data = await res.json();
            if (data.data) {
                db.groups.saveAll(data.data);
                return data.data; // Retorna dados frescos
            }
        }
    } catch (e) {
        console.warn("Offline/Dev: Serving local groups only");
    }
    
    return localGroups;
  },

  // Método síncrono para componentes UI antigos que precisam de dados imediatos
  getGroupsSync: (): Group[] => {
      return db.groups.getAll();
  },

  getAllGroupsForRanking: (): Group[] => {
      return db.groups.getAll();
  },

  getGroupById: (id: string): Group | undefined => {
    return db.groups.findById(id);
  },

  createGroup: (group: Group) => {
    if (group.creatorEmail) {
        group.members = [group.creatorEmail];
        group.admins = [group.creatorEmail];
    }
    // Optimistic update
    db.groups.add(group);
    
    // API call
    fetch(`${API_URL}/create`, { 
        method: 'POST', 
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(group) 
    }).catch(e => console.error("Group create sync failed", e));
  },

  updateGroup: (updatedGroup: Group) => {
    db.groups.update(updatedGroup);
    // API call placeholder
  },

  deleteGroup: (groupId: string) => {
    db.groups.delete(groupId);
    // API call placeholder
  },

  joinGroup: (groupId: string): 'joined' | 'pending' | 'full' | 'error' | 'banned' => {
      const group = db.groups.findById(groupId);
      const currentUserEmail = authService.getCurrentUserEmail();

      if (!group || !currentUserEmail) return 'error';

      if (group.members?.includes(currentUserEmail)) return 'joined';

      if (!group.isPrivate) {
          const members = group.members || [];
          group.members = [...members, currentUserEmail];
          db.groups.update(group);
          return 'joined';
      }
      return 'pending';
  },

  joinGroupByLinkCode: (code: string): { success: boolean; message: string; groupId?: string } => {
      const allGroups = db.groups.getAll();
      for (const group of allGroups) {
          if (group.links?.find(l => l.code === code)) {
             return { success: true, message: "Entrou no grupo!", groupId: group.id };
          }
      }
      return { success: false, message: 'Link inválido' };
  },

  leaveGroup: (groupId: string) => {},
  removeMember: (groupId: string, email: string) => {},
  banMember: (groupId: string, email: string) => {},
  promoteMember: (groupId: string, email: string) => {},
  getGroupMembers: (groupId: string): User[] => [],
  getPendingMembers: (groupId: string): User[] => [],
  approveMember: (groupId: string, email: string) => {},
  rejectMember: (groupId: string, email: string) => {},
  addGroupLink: (groupId: string, name: string, maxUses?: number, expiresAt?: string): GroupLink | null => {
      return null;
  },
  removeGroupLink: (groupId: string, id: string) => {}
};
