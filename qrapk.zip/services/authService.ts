
import { User, AuthError, VerificationSession, PaymentProviderConfig, UserProfile, NotificationSettings, SecuritySettings, UserSession } from '../types';
import { db } from '@/database'; // Mantido para fallback local/cache
import { emailService } from './emailService';
import { cryptoService } from './cryptoService';

// Declare google global
declare var google: any;

// Ajuste crítico para APK: Usar URL absoluta se disponível, senão relativa
const BASE_URL = process.env.VITE_API_URL || '';
const API_URL = `${BASE_URL}/api`;

// --- Public API ---

export const authService = {
  isValidEmail: (email: string) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  },

  // LOGIN REAL CONECTADO AO POSTGRES VIA API
  login: async (email: string, password: string): Promise<{ user: User; nextStep: string }> => {
    try {
        // 1. Tenta autenticar via Backend (Postgres)
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password })
        });

        if (response.ok) {
            const data = await response.json();
            // Atualiza estado local para a UI funcionar
            const user = data.user || db.users.get(email); // Fallback para local se backend retornar parcial
            
            if (!user) throw new Error(AuthError.USER_NOT_FOUND);

            // Salva sessão
            db.auth.setCurrentUserEmail(email);
            
            // Rastreamento de Sessão (Redis/Local)
            // trackNewSession(email); -> Movido para backend idealmente, mas mantido local para UI

            if (!user.isVerified) throw new Error(AuthError.EMAIL_NOT_VERIFIED);
            if (!user.isProfileCompleted) return { user, nextStep: '/complete-profile' };
            
            return { user, nextStep: '/feed' };
        } else {
            // Fallback para lógica local antiga (caso o backend não esteja rodando o Docker)
            throw new Error("Backend indisponível, tentando local...");
        }
    } catch (e) {
        // FALLBACK LOCAL (SQL.JS) PARA DESENVOLVIMENTO SEM DOCKER
        console.warn("Usando autenticação local (Fallback)", e);
        
        const user = db.users.get(email);
        if (!user) throw new Error(AuthError.USER_NOT_FOUND);

        if (!user.googleId) {
            const inputHash = await cryptoService.hashPassword(password);
            const isMatch = user.password === inputHash || user.password === password;
            if (!isMatch) throw new Error(AuthError.WRONG_PASSWORD);
        }

        db.auth.setCurrentUserEmail(email);
        user.lastSeen = Date.now();
        db.users.set(user);

        if (!user.isVerified) throw new Error(AuthError.EMAIL_NOT_VERIFIED);
        if (!user.isProfileCompleted) return { user, nextStep: '/complete-profile' };
        return { user, nextStep: '/feed' };
    }
  },

  loginWithGoogle: async (): Promise<{ user: User; nextStep: string }> => {
    return new Promise((resolve, reject) => {
      try {
        if (typeof google === 'undefined') {
            reject(new Error("Google services not loaded. Check internet connection."));
            return;
        }

        const client = google.accounts.oauth2.initTokenClient({
          client_id: process.env.GOOGLE_CLIENT_ID,
          scope: 'email profile openid',
          callback: async (response: any) => {
            if (response.error) {
              reject(new Error("Google Login failed: " + response.error));
              return;
            }
            
            try {
              const userInfoRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
                headers: { Authorization: `Bearer ${response.access_token}` }
              });
              
              const userInfo = await userInfoRes.json();
              const email = userInfo.email;
              
              // Aqui deveria chamar API do Backend para criar/logar usuário Google
              // Mantendo lógica local para garantir funcionamento da UI
              let user = db.users.get(email);

              if (!user) {
                 user = {
                   email,
                   isVerified: true, 
                   isProfileCompleted: false,
                   googleId: userInfo.sub,
                   profile: {
                     name: "", 
                     nickname: userInfo.name, 
                     photoUrl: userInfo.picture, 
                     isPrivate: false,
                     bio: ""
                   },
                   lastSeen: Date.now()
                 };
                 db.users.set(user);
                 db.auth.setCurrentUserEmail(email);
                 resolve({ user, nextStep: '/complete-profile' });
              } else {
                 if (!user.googleId) user.googleId = userInfo.sub;
                 user.lastSeen = Date.now();
                 db.users.set(user);
                 db.auth.setCurrentUserEmail(email);
                 
                 if (!user.isProfileCompleted || !user.profile?.name) {
                     resolve({ user, nextStep: '/complete-profile' });
                 } else {
                     resolve({ user, nextStep: '/feed' });
                 }
              }
            } catch (err: any) {
              reject(new Error(err.message || "Error processing Google login"));
            }
          },
        });
        
        client.requestAccessToken({ prompt: 'select_account' });

      } catch (err: any) {
        reject(new Error("Unexpected error initializing Google Login"));
      }
    });
  },

  // Get session list for Security page
  getUserSessions: (): UserSession[] => {
      const email = db.auth.currentUserEmail();
      if (!email) return [];
      const user = db.users.get(email);
      return user?.sessions || [];
  },

  getCurrentSessionId: (): string | null => {
      return localStorage.getItem('current_session_id');
  },

  register: async (email: string, password: string) => {
    if (db.users.exists(email)) throw new Error(AuthError.ALREADY_EXISTS);

    const hashedPassword = await cryptoService.hashPassword(password);

    const newUser: User = {
      email,
      password: hashedPassword,
      isVerified: false,
      isProfileCompleted: false,
      notificationSettings: {
          pauseAll: false,
          likes: true,
          comments: true,
          followers: true,
          mentions: true,
          messages: true,
          email: true,
          groups: true
      },
      securitySettings: {
          twoFactorEnabled: false,
          saveLoginInfo: true
      },
      lastSeen: Date.now(),
      changeHistory: {
          usernameChanges: [],
          nicknameChanges: []
      },
      sessions: []
    };
    db.users.set(newUser);
    db.auth.setCurrentUserEmail(email);
    await authService.sendVerificationCode(email);
  },

  sendVerificationCode: async (email: string, type: 'register' | 'reset' = 'register') => {
    await new Promise(resolve => setTimeout(resolve, 800)); 
    
    if (!email) throw new Error("Digite seu Gmail");
    if (!authService.isValidEmail(email)) throw new Error(AuthError.INVALID_FORMAT);
    
    const lockout = db.auth.getLockout(email);
    const now = Date.now();

    if (lockout.blockedUntil && now < lockout.blockedUntil) {
      throw new Error(AuthError.TOO_MANY_ATTEMPTS);
    }

    if (lockout.attempts >= 2) {
      db.auth.saveLockout(email, { attempts: lockout.attempts + 1, blockedUntil: now + 24 * 60 * 60 * 1000 });
      throw new Error(AuthError.TOO_MANY_ATTEMPTS);
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    
    db.auth.saveSession(email, {
      code,
      expiresAt: now + 5 * 60 * 1000,
      attempts: lockout.attempts + 1
    });

    db.auth.saveLockout(email, { attempts: lockout.attempts + 1, blockedUntil: null });

    if (type === 'register') {
        await emailService.sendVerificationCode(email, code);
    } else {
        await emailService.sendPasswordResetCode(email, code);
    }
  },

  verifyCode: async (email: string, code: string, isResetFlow: boolean = false) => {
    const session = db.auth.getSession(email);
    
    if (!session) throw new Error(AuthError.CODE_EXPIRED);
    if (Date.now() > session.expiresAt) throw new Error(AuthError.CODE_EXPIRED);
    if (session.code !== code) throw new Error(AuthError.CODE_INVALID);

    if (!isResetFlow) {
        const user = db.users.get(email);
        if (user) {
            user.isVerified = true;
            db.users.set(user);
        }
    }
    
    db.auth.saveLockout(email, { attempts: 0, blockedUntil: null });
    return true;
  },

  resetPassword: async (email: string, newPass: string) => {
    const user = db.users.get(email);
    if (!user) throw new Error(AuthError.USER_NOT_FOUND);
    user.password = await cryptoService.hashPassword(newPass);
    db.users.set(user);
  },

  checkUsernameAvailability: async (username: string): Promise<boolean> => {
    await new Promise(resolve => setTimeout(resolve, 200));
    const users = db.users.getAll();
    const nameLower = username.toLowerCase();
    const currentUserEmail = db.auth.currentUserEmail();
    const isTaken = Object.values(users).some(u => u.profile?.name === nameLower && u.email !== currentUserEmail);
    return !isTaken;
  },

  completeProfile: async (email: string, data: UserProfile) => {
    const users = db.users.getAll();
    const nameLower = data.name.toLowerCase();
    const nameTaken = Object.values(users).some(u => u.profile?.name === nameLower && u.email !== email);
    
    if (nameTaken) throw new Error(AuthError.NAME_TAKEN);

    const user = db.users.get(email);
    if (!user) throw new Error(AuthError.USER_NOT_FOUND);

    // --- ENFORCE LIMITS FOR EDITS ---
    if (user.isProfileCompleted) {
        const now = Date.now();
        const ONE_DAY = 24 * 60 * 60 * 1000;
        const THIRTY_DAYS = 30 * 24 * 60 * 60 * 1000;

        if (!user.changeHistory) {
            user.changeHistory = { usernameChanges: [], nicknameChanges: [] };
        }

        if (user.profile?.name !== nameLower) {
            const history = user.changeHistory.usernameChanges || [];
            const recentChanges = history.filter(t => t > now - ONE_DAY);
            
            if (recentChanges.length >= 3) {
                throw new Error("Você só pode alterar seu @ 3 vezes por dia.");
            }
            user.changeHistory.usernameChanges = [...recentChanges, now];
        }

        if (user.profile?.nickname !== data.nickname) {
            const history = user.changeHistory.nicknameChanges || [];
            const recentChanges = history.filter(t => t > now - THIRTY_DAYS);
            
            if (recentChanges.length >= 3) {
                throw new Error("Você só pode alterar seu Nome 3 vezes por mês.");
            }
            user.changeHistory.nicknameChanges = [...recentChanges, now];
        }
    }

    user.profile = {
        ...data,
        name: nameLower
    };
    user.isProfileCompleted = true;
    
    if (!user.notificationSettings) {
        user.notificationSettings = {
            pauseAll: false, likes: true, comments: true, followers: true, mentions: true, messages: true, email: true, groups: true
        };
    }
    if (!user.securitySettings) {
        user.securitySettings = { twoFactorEnabled: false, saveLoginInfo: true };
    }

    db.users.set(user);
  },

  updatePaymentConfig: (config: PaymentProviderConfig) => {
    const email = db.auth.currentUserEmail();
    if(!email) return;
    const user = db.users.get(email);
    if(user) {
        if (config.clientSecret) config.clientSecret = cryptoService.encryptData(config.clientSecret);
        if (config.clientId) config.clientId = cryptoService.encryptData(config.clientId);
        if (config.accessToken) config.accessToken = cryptoService.encryptData(config.accessToken);

        user.paymentConfig = config;
        db.users.set(user);
    }
  },

  updateNotificationSettings: (settings: NotificationSettings) => {
      const email = db.auth.currentUserEmail();
      if (!email) return;
      const user = db.users.get(email);
      if (user) {
          user.notificationSettings = settings;
          db.users.set(user);
      }
  },

  updateSecuritySettings: (settings: SecuritySettings) => {
      const email = db.auth.currentUserEmail();
      if (!email) return;
      const user = db.users.get(email);
      if (user) {
          user.securitySettings = settings;
          db.users.set(user);
      }
  },

  changePassword: async (currentPass: string, newPass: string) => {
      const email = db.auth.currentUserEmail();
      if (!email) throw new Error(AuthError.USER_NOT_FOUND);
      const user = db.users.get(email);
      if (!user) throw new Error(AuthError.USER_NOT_FOUND);

      const currentHash = await cryptoService.hashPassword(currentPass);
      const isMatch = user.password === currentHash || user.password === currentPass;

      if (!isMatch) {
          throw new Error("Senha atual incorreta");
      }
      
      user.password = await cryptoService.hashPassword(newPass);
      db.users.set(user);
  },

  updateHeartbeat: () => {
      const email = db.auth.currentUserEmail();
      if (email) {
          const user = db.users.get(email);
          if (user) {
              user.lastSeen = Date.now();
              db.users.set(user);
          }
      }
  },

  getUserByHandle: (handle: string): User | undefined => {
      if (!handle) return undefined;
      const cleanHandle = handle.replace('@', '').toLowerCase();
      const allUsers = db.users.getAll();
      return Object.values(allUsers).find(u => u.profile?.name === cleanHandle);
  },

  getCurrentUserEmail: () => db.auth.currentUserEmail(),
  
  getCurrentUser: (): User | null => {
    const email = db.auth.currentUserEmail();
    if (!email) return null;
    return db.users.get(email) || null;
  },

  getAllUsers: (): User[] => {
    const allUsers = db.users.getAll();
    const currentEmail = db.auth.currentUserEmail();
    return Object.values(allUsers).filter(u => 
        u.email !== currentEmail && u.isProfileCompleted
    );
  },

  // NEW: Server-side search for scalability (Replaces local filtering)
  searchUsers: async (query: string): Promise<User[]> => {
      try {
          const response = await fetch(`${API_URL}/search/users?q=${encodeURIComponent(query)}`);
          if (response.ok) {
              const result = await response.json();
              return result.data || [];
          }
      } catch (e) {
          console.warn("Using local search fallback");
      }
      
      // Fallback to local if offline/mock
      const all = Object.values(db.users.getAll());
      return all.filter(u => 
          u.profile?.name.toLowerCase().includes(query.toLowerCase()) || 
          u.profile?.nickname?.toLowerCase().includes(query.toLowerCase())
      );
  },
  
  logout: () => {
    db.auth.clearSession();
    localStorage.removeItem('current_session_id');
    localStorage.removeItem('reset_email');
    if (typeof google !== 'undefined' && google.accounts && google.accounts.id) {
        google.accounts.id.disableAutoSelect();
    }
  }
};