
import { db } from '@/database';
import { ChatMessage, ChatData } from '../types';
import { recommendationService } from './recommendationService';
import { authService } from './authService';

// Re-export for consumers (pages)
export type { ChatMessage, ChatData };

// Start with empty chats. Real chats are created via interactions.
const INITIAL_CHATS: Record<string, ChatData> = {};

export const chatService = {
    getAllChats: (): Record<string, ChatData> => {
        const chats = db.chats.getAll();
        // Initialize with mock data if empty ONLY if specifically requested, otherwise return empty
        if (Object.keys(chats).length === 0 && !localStorage.getItem('app_chats_seeded')) {
            db.chats.saveAll(INITIAL_CHATS);
            localStorage.setItem('app_chats_seeded', 'true');
            return INITIAL_CHATS;
        }
        return chats;
    },

    // Helper to generate a consistent ID for private chats between two users
    getPrivateChatId: (email1: string, email2: string): string => {
        const sorted = [email1, email2].sort();
        return `${sorted[0]}_${sorted[1]}`;
    },

    getChat: (id: string): ChatData => {
        let chat = db.chats.get(id);
        if (!chat) {
            // Create new empty chat if not exists (lazy creation)
            chat = {
                id,
                contactName: 'Novo Chat', // Placeholder, resolved dynamically in UI
                isBlocked: false,
                messages: []
            };
            db.chats.set(chat);
        }
        return chat;
    },

    getUnreadCount: (): number => {
        const allChats = chatService.getAllChats();
        let count = 0;
        const currentUserEmail = authService.getCurrentUserEmail();
        
        if (!currentUserEmail) return 0;

        Object.values(allChats).forEach(chat => {
            const chatIdStr = chat.id.toString();
            // Only count if user is participant
            if (chatIdStr.includes('@') && !chatIdStr.includes(currentUserEmail)) return;

            // Count messages received and not read
            const unreadInChat = chat.messages.filter(m => m.type === 'received' && m.status !== 'read').length;
            count += unreadInChat;
        });
        return count;
    },

    sendMessage: (chatId: string, message: ChatMessage) => {
        const chat = db.chats.get(chatId);
        let chatData = chat;

        if (!chatData) {
             chatData = {
                id: chatId,
                contactName: 'Chat',
                isBlocked: false,
                messages: []
            };
        }
        
        chatData.messages.push(message);
        db.chats.set(chatData);

        // --- ALGORITHM INTEGRATION ---
        // Analyze message if it's a text sent by the current user
        if (message.type === 'sent' && message.contentType === 'text') {
            const email = authService.getCurrentUserEmail();
            if (email) {
                // Run in background (don't await)
                setTimeout(() => {
                    recommendationService.analyzeMessage(email, message.text);
                }, 100);
            }
        }
    },

    clearChat: (chatId: string) => {
        const chat = db.chats.get(chatId);
        if (chat) {
            chat.messages = [];
            db.chats.set(chat);
        }
    },

    deleteMessages: (chatId: string, messageIds: number[]) => {
        const chat = db.chats.get(chatId);
        if (chat) {
            // Ensure strict filtering by ID
            chat.messages = chat.messages.filter(m => !messageIds.includes(m.id));
            db.chats.set(chat);
        }
    },

    toggleBlock: (chatId: string): boolean => {
        const chat = db.chats.get(chatId);
        if (chat) {
            chat.isBlocked = !chat.isBlocked;
            db.chats.set(chat);
            return chat.isBlocked;
        }
        return false;
    },

    // New methods for Profile integration
    toggleBlockByContactName: (contactName: string): boolean => {
        const chats = chatService.getAllChats();
        let chat = Object.values(chats).find(c => c.contactName === contactName);
        
        if (chat) {
            chat.isBlocked = !chat.isBlocked;
            db.chats.set(chat);
        } else {
            // Create new chat entry to store block status if chat didn't exist
            const newId = Date.now().toString();
            chat = {
                id: newId,
                contactName: contactName,
                isBlocked: true,
                messages: []
            };
            db.chats.set(chat);
        }
        
        return chat.isBlocked;
    },
    
    isUserBlocked: (contactName: string): boolean => {
        const chats = chatService.getAllChats();
        const chat = Object.values(chats).find(c => c.contactName === contactName);
        return chat ? chat.isBlocked : false;
    }
};
