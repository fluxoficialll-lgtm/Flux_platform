
import { db } from '@/database';
import { Post } from '../types';

// --- Configurações do Algoritmo "God Mode" ---
const WEIGHTS = {
    AUTHOR_AFFINITY: 500,   // Peso alto: Fideliza o usuário aos criadores que ele gosta
    VIRAL_BOOST: 5,         // Multiplicador para posts em alta (Gatilho de Prova Social)
    FRESHNESS_DECAY: 2.0,   // Decaimento agressivo: Conteúdo novo vale muito mais
    WATCH_TIME_WEIGHT: 50,  // Pontos por segundo assistido
    SKIP_PENALTY: 100       // Penalidade se pular em menos de 1.5s
};

// Cache de Sessão para Afinidades (Memória de Curto Prazo)
// Armazena pontuação de afinidade com autores baseado nas interações desta sessão
let sessionAffinityCache: Record<string, number> = {}; 

export const recommendationService = {
    
    isAnalysisEnabled: (email: string) => true,
    setAnalysisEnabled: (email: string, enabled: boolean) => {},

    /**
     * REGISTRA INTERAÇÃO (Input Sensorial do Algoritmo)
     * Alimenta o "cérebro" com sinais implícitos e explícitos.
     */
    recordInteraction: (userEmail: string, post: Post, type: 'view_time' | 'like' | 'comment' | 'share', value?: number) => {
        const authorKey = `author:${post.username}`;
        if (!sessionAffinityCache[authorKey]) sessionAffinityCache[authorKey] = 0;

        let scoreBoost = 0;

        switch (type) {
            case 'view_time':
                // O sinal mais honesto: Tempo de Tela.
                if (value) {
                    if (value < 1.5) {
                        // Rejeição Rápida: Sinal negativo forte
                        scoreBoost -= WEIGHTS.SKIP_PENALTY;
                    } else if (value > 10) {
                        // Super Engajamento (Loop ou vídeo longo)
                        scoreBoost += (value * WEIGHTS.WATCH_TIME_WEIGHT * 1.5);
                    } else {
                        // Interesse Normal
                        scoreBoost += (value * WEIGHTS.WATCH_TIME_WEIGHT);
                    }
                }
                break;
            case 'like':
                scoreBoost += 200; // Sinal explícito de aprovação
                break;
            case 'comment':
                scoreBoost += 400; // Alto esforço = Alta afinidade
                break;
            case 'share':
                scoreBoost += 800; // O "Santo Graal" da viralidade
                break;
        }

        // Atualiza a afinidade com o criador em tempo real
        sessionAffinityCache[authorKey] += scoreBoost;
        
        // console.log(`[Algo] Updated affinity for ${post.username}: ${sessionAffinityCache[authorKey]}`);
    },

    /**
     * CÁLCULO DE SCORE (Dopamine Prediction)
     * Prediz a probabilidade de satisfação do usuário para um post específico.
     */
    scorePost: (post: Post, userEmail: string): number => {
        let score = 1000; // Score base para evitar negativos
        const now = Date.now();

        // 1. Fator Afinidade (O "Crush")
        // Se o usuário já interagiu muito com esse autor, jogue o score lá no alto.
        const authorKey = `author:${post.username}`;
        const affinity = sessionAffinityCache[authorKey] || 0;
        if (affinity !== 0) {
            // Logarítmico para evitar que um único super-fã quebre a escala, mas linearmente impactante
            score += (affinity * 0.5); 
        }

        // 2. Fator Viralidade (FOMO - Fear Of Missing Out)
        // O que todo mundo está vendo, o usuário também quer ver.
        const engagementScore = (post.likes * 10) + (post.comments * 20) + (post.views * 0.5);
        // Boost multiplicativo para conteúdos que estão "explodindo"
        score += Math.log(engagementScore + 1) * 100 * WEIGHTS.VIRAL_BOOST;

        // 3. Fator Novidade (Freshness)
        // Decaimento exponencial. Posts de 1h atrás valem muito mais que posts de 24h atrás.
        const ageInHours = Math.max(0, (now - post.timestamp) / (1000 * 60 * 60));
        const freshnessPenalty = Math.pow(ageInHours + 1, WEIGHTS.FRESHNESS_DECAY);
        score = score / freshnessPenalty;

        // 4. Penalidade de Consumo (Já Visto)
        // Se já viu, enterra o post (reduz 95%), a menos que seja absurdamente viral ou favorito
        if (post.viewedBy && post.viewedBy.includes(userEmail)) {
            score = score * 0.05; 
        }

        return score;
    },

    /**
     * MOTOR DE REELS (Slot Machine Logic)
     * Gera um feed viciante misturando relevância pessoal com surpresas virais.
     */
    getRecommendedReels: (reels: Post[], userEmail: string): Post[] => {
        // Modo Visitante: Shuffle aleatório para exploração pura
        if (!userEmail) return reels.sort(() => 0.5 - Math.random());

        // 1. Calcular Score de Dopamina para cada Reel
        let scoredReels = reels.map(reel => {
            const score = recommendationService.scorePost(reel, userEmail);
            // Identifica "Super Virais" independentemente do gosto do usuário
            const isGlobalViral = (reel.views > 1000 || reel.likes > 100);
            return { reel, score, isGlobalViral };
        });

        // 2. Ordenar por Score (O que o usuário MAIS quer ver primeiro)
        scoredReels.sort((a, b) => b.score - a.score);

        // 3. Separação de Buckets
        const relevantContent = scoredReels; 
        // Pool de conteúdo viral para injeção (mesmo que score seja baixo por falta de afinidade ou idade)
        const viralInjectionPool = scoredReels.filter(i => i.isGlobalViral).sort(() => 0.5 - Math.random());

        const finalFeed: Post[] = [];
        let viralPoolIndex = 0;

        // 4. Construção do Feed com Padrão de Recompensa Variável (Variable Reward Schedule)
        // A cada 5-7 posts relevantes, injetamos algo inesperado (Viral) para quebrar o padrão e gerar pico de atenção.
        
        for (let i = 0; i < relevantContent.length; i++) {
            finalFeed.push(relevantContent[i].reel);

            // A cada 5 posts, joga a moeda
            if ((i + 1) % 5 === 0) {
                // 70% de chance de injetar um viral aleatório aqui
                if (Math.random() > 0.3 && viralPoolIndex < viralInjectionPool.length) {
                    const viralPick = viralInjectionPool[viralPoolIndex].reel;
                    
                    // Evita duplicata se o viral já estava na lista principal próxima
                    if (!finalFeed.includes(viralPick)) {
                        finalFeed.push(viralPick);
                    }
                    viralPoolIndex++;
                }
            }
        }

        // Remove duplicatas (Set) e retorna
        return [...new Set(finalFeed)];
    },

    /**
     * FEED PRINCIPAL (Texto/Foto)
     * Foca mais em cronologia ajustada por relevância.
     */
    getRecommendedFeed: (posts: Post[], userEmail: string): Post[] => {
        if (!userEmail) return posts.sort((a, b) => b.timestamp - a.timestamp);

        const scoredPosts = posts.map(post => ({
            post,
            score: recommendationService.scorePost(post, userEmail)
        }));

        scoredPosts.sort((a, b) => b.score - a.score);
        return scoredPosts.map(p => p.post);
    },

    analyzeMessage: (email: string, message: string) => {
        // Análise de sentimento de chat pode ser adicionada aqui para refinar afinidades
    }
};
