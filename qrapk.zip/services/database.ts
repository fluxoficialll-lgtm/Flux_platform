import { User, Post, Group, NotificationItem, Relationship, ChatData, VerificationSession, LockoutState, VipAccess } from '../types';

// --- State Store Reativa (Cache Local) ---
// Em produção (50M usuários), isso atua como Cache da Sessão (Redux-like).
// Em desenvolvimento local (sem backend), isso atua como Mock DB.

type TableName = 'users' | 'posts' | 'groups' | 'chats' | 'notifications' | 'relationships' | 'vip_access' | 'profile';
type Listener = () => void;

class MemoryStore {
  public data: {
    users: Record<string, User>;
    posts: Record<string, Post>;
    groups: Record<string, Group>;
    chats: Record<string, ChatData>;
    notifications: Record<number, NotificationItem>;
    relationships: Record<string, Relationship>;
    vip_access: Record<string, VipAccess>;
    session: { currentUserEmail: string | null; verification: Record<string, VerificationSession>; lockouts: Record<string, LockoutState> };
  };

  private listeners: Map<string, Set<Listener>> = new Map();

  constructor() {
    // Inicializa estado vazio ou recupera snapshot básico do localStorage para persistência leve
    const savedSession = localStorage.getItem('app_current_user_email');
    
    this.data = {
      users: {},
      posts: {},
      groups: {},
      chats: {},
      notifications: {},
      relationships: {},
      vip_access: {},
      session: {
          currentUserEmail: savedSession,
          verification: {},
          lockouts: {}
      }
    };
  }

  // --- Pub/Sub System (Mantém a UI reativa) ---
  public subscribe(table: TableName | 'all', callback: Listener) {
      if (!this.listeners.has(table)) {
          this.listeners.set(table, new Set());
      }
      this.listeners.get(table)!.add(callback);
      
      // Retorna função de unsubscribe
      return () => {
          const set = this.listeners.get(table);
          if (set) set.delete(callback);
      };
  }

  public notify(table: string) {
      if (this.listeners.has(table)) {
          this.listeners.get(table)!.forEach(cb => cb());
      }
      if (this.listeners.has('all')) {
          this.listeners.get('all')!.forEach(cb => cb());
      }
  }

  // --- CRUD Operations (In-Memory) ---
  
  public set<T>(table: keyof typeof this.data, key: string | number, item: T) {
      // @ts-ignore
      this.data[table][key] = item;
      this.notify(table);
  }

  public get<T>(table: keyof typeof this.data, key: string | number): T | undefined {
      // @ts-ignore
      return this.data[table][key];
  }

  public getAll<T>(table: keyof typeof this.data): T[] {
      // @ts-ignore
      return Object.values(this.data[table]);
  }

  public delete(table: keyof typeof this.data, key: string | number) {
      // @ts-ignore
      delete this.data[table][key];
      this.notify(table);
  }

  // --- Session Specifics ---
  public setSessionUser(email: string) {
      this.data.session.currentUserEmail = email;
      if(email) localStorage.setItem('app_current_user_email', email);
      else localStorage.removeItem('app_current_user_email');
  }

  public getSessionUser() {
      return this.data.session.currentUserEmail;
  }
}

const store = new MemoryStore();

// API Pública do Database (Compatível com o restante do app)
export const db = {
  refresh: async () => { /* No-op in memory */ },
  subscribe: (table: TableName | 'all', callback: () => void) => store.subscribe(table, callback),
  
  // Acesso público aos dados internos para debug ou uso direto se necessário
  store: store,

  users: {
    getAll: () => store.data.users,
    get: (email: string) => store.get<User>('users', email),
    set: (user: User) => store.set('users', user.email, user),
    exists: (email: string) => !!store.get('users', email),
    // Bulk update vindo da API
    saveAll: (users: User[]) => users.forEach(u => store.set('users', u.email, u))
  },
  posts: {
    getAll: () => Object.values(store.data.posts).sort((a, b) => b.timestamp - a.timestamp),
    // Paginação Local (Fallback quando API offline)
    getCursorPaginated: (limit: number, cursor?: number) => {
        const all = Object.values(store.data.posts).sort((a, b) => b.timestamp - a.timestamp);
        if (!cursor) return all.slice(0, limit);
        const idx = all.findIndex(p => p.timestamp === cursor);
        return all.slice(idx + 1, idx + 1 + limit);
    },
    add: (post: Post) => store.set('posts', post.id, post),
    update: (post: Post) => store.set('posts', post.id, post),
    delete: (id: string) => store.delete('posts', id),
    findById: (id: string) => store.get<Post>('posts', id),
    saveAll: (posts: Post[]) => posts.forEach(p => store.set('posts', p.id, p))
  },
  groups: {
    getAll: () => Object.values(store.data.groups),
    add: (group: Group) => store.set('groups', group.id, group),
    update: (group: Group) => store.set('groups', group.id, group),
    delete: (id: string) => store.delete('groups', id),
    findById: (id: string) => store.get<Group>('groups', id),
    saveAll: (groups: Group[]) => groups.forEach(g => store.set('groups', g.id, g))
  },
  chats: {
    getAll: () => store.data.chats,
    get: (id: string) => store.get<ChatData>('chats', id),
    set: (chat: ChatData) => store.set('chats', chat.id, chat),
    saveAll: (chats: Record<string, ChatData>) => {
        Object.values(chats).forEach(c => store.set('chats', c.id, c));
    }
  },
  notifications: {
    getAll: () => store.getAll<NotificationItem>('notifications'),
    add: (item: NotificationItem) => store.set('notifications', item.id, item)
  },
  relationships: {
    getAll: () => store.getAll<Relationship>('relationships'),
    add: (rel: Relationship) => store.set('relationships', `${rel.followerEmail}_${rel.followingUsername}`, rel),
    remove: (follower: string, following: string) => store.delete('relationships', `${follower}_${following}`)
  },
  vipAccess: {
      grant: (access: VipAccess) => store.set('vip_access', `${access.userId}_${access.groupId}`, access),
      check: (userId: string, groupId: string) => !!store.get('vip_access', `${userId}_${groupId}`)
  },
  profile: {
      get: (email: string) => null, // Mock
      update: (email: string, data: any) => {},
      isAnalysisEnabled: () => true,
      setAnalysisEnabled: () => {}
  },
  auth: {
    currentUserEmail: () => store.getSessionUser(),
    setCurrentUserEmail: (email: string) => store.setSessionUser(email),
    clearSession: () => {
        store.setSessionUser('');
    },
    getSession: (email: string) => store.data.session.verification[email] || null,
    saveSession: (email: string, session: VerificationSession) => { store.data.session.verification[email] = session; },
    getLockout: (email: string) => store.data.session.lockouts[email] || { attempts: 0, blockedUntil: null },
    saveLockout: (email: string, state: LockoutState) => { store.data.session.lockouts[email] = state; }
  }
};