
// Serviço de Criptografia usando Web Crypto API nativa do navegador.
// IMPORTANTE: Armazenamento no lado do cliente (LocalStorage/IndexedDB) nunca é 100% seguro contra ataques XSS.
// Este serviço fornece Hashing e Ofuscação para dificultar o acesso casual.

// Salt estático para dificultar Rainbow Tables em hashes locais (Em produção real, use salts únicos por usuário no backend)
const APP_SALT = "FLUX_SECURE_SALT_v1_";

export const cryptoService = {
  /**
   * Gera um Hash SHA-256 para senhas com SALT.
   * O Salt impede que atacantes usem tabelas pré-computadas para descobrir senhas comuns.
   */
  hashPassword: async (password: string): Promise<string> => {
    const saltedPassword = APP_SALT + password;
    const msgBuffer = new TextEncoder().encode(saltedPassword);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
  },

  /**
   * Ofusca dados sensíveis para armazenamento local.
   * ATENÇÃO: Isso NÃO é criptografia de nível militar (AES), pois a chave precisaria estar no cliente.
   * Isso serve para impedir leitura direta (olho nu) no LocalStorage.
   */
  encryptData: (data: string): string => {
    try {
        // Método XOR simples com base64 para ofuscação melhor que apenas base64
        // Isso quebra leitores automáticos de base64 simples
        const key = 123; // Simple constant key for obfuscation
        let result = '';
        for (let i = 0; i < data.length; i++) {
            result += String.fromCharCode(data.charCodeAt(i) ^ key);
        }
        return btoa(result);
    } catch (e) {
        console.error("Erro ao ofuscar dados", e);
        return data;
    }
  },

  decryptData: (encryptedData: string): string => {
    try {
        const data = atob(encryptedData);
        const key = 123;
        let result = '';
        for (let i = 0; i < data.length; i++) {
            result += String.fromCharCode(data.charCodeAt(i) ^ key);
        }
        return result;
    } catch (e) {
        // Fallback para dados antigos que possam estar apenas em base64 simples
        try {
            return atob(encryptedData).split('').reverse().join(''); 
        } catch {
            return encryptedData;
        }
    }
  }
};
