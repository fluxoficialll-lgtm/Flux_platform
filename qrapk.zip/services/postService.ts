
import { Post, Comment, PaginatedResponse } from '../types';
import { db } from '@/database';

// API URL configuration
const API_URL = '/api/posts';
const UPLOAD_URL = '/api/upload';

export const postService = {
  // O "Feed" agora busca do servidor, que é capaz de consultar ScyllaDB/Elasticsearch
  getFeedPaginated: async (options: { limit: number; cursor?: number | string; allowedTypes?: string[]; locationFilter?: string | null; allowAdultContent?: boolean }): Promise<PaginatedResponse<Post>> => {
    try {
        // Constrói query params para a API
        const params = new URLSearchParams();
        params.append('limit', options.limit.toString());
        if (options.cursor) params.append('cursor', options.cursor.toString());
        if (options.allowedTypes) params.append('types', options.allowedTypes.join(','));
        if (options.locationFilter) params.append('location', options.locationFilter || '');
        if (options.allowAdultContent !== undefined) params.append('adult', options.allowAdultContent.toString());

        // Fetch real do backend
        const response = await fetch(`${API_URL}?${params.toString()}`, {
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        if (!response.ok) throw new Error('Failed to fetch posts from API');

        const data: PaginatedResponse<Post> = await response.json();
        
        // Cache os posts recebidos na store local para que a UI funcione instantaneamente
        if (data.data && data.data.length > 0) {
            db.posts.saveAll(data.data);
        }

        return data;
    } catch (e) {
        // Fallback Silencioso: Usa dados locais se a API falhar (Modo Offline/Dev)
        console.warn("Modo Offline/Dev: Usando posts locais.", e);
        
        // Gera mocks locais se estiver vazio para não ficar tela branca no teste
        const cached = db.posts.getCursorPaginated(options.limit, typeof options.cursor === 'number' ? options.cursor : undefined);
        
        return { data: cached, nextCursor: undefined };
    }
  },

  // --- UPLOAD SERVICE ---
  // Faz upload de arquivo e retorna URL (Para não enviar Base64 gigante no JSON)
  uploadMedia: async (file: File): Promise<string> => {
      const formData = new FormData();
      formData.append('file', file);

      try {
          const response = await fetch(UPLOAD_URL, {
              method: 'POST',
              body: formData // Browser sets Content-Type: multipart/form-data; boundary=...
          });

          if (!response.ok) throw new Error('Falha no upload');
          
          const data = await response.json();
          // Retorna a URL do primeiro arquivo (suporta multiplos no futuro)
          return data.files[0].url;
      } catch (e) {
          console.error("Erro de upload:", e);
          throw new Error("Falha ao enviar mídia para o servidor.");
      }
  },

  // Métodos de escrita também enviam para a API (Optimistic UI)
  addPost: async (post: Post) => {
    // 1. Salva localmente para UI aparecer instantaneamente (Optimistic)
    db.posts.add(post);

    try {
        // 2. Envia para o servidor (Background Sync)
        await fetch(`${API_URL}/create`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(post)
        });
    } catch (e) {
        console.error("Background sync failed (Post saved locally only)", e);
    }
  },

  getPostById: (id: string): Post | undefined => {
    return db.posts.findById(id);
  },

  getUserPosts: (username: string): Post[] => {
    // Em produção, isso chamaria /api/users/:id/posts
    const posts = db.posts.getAll(); 
    return posts.filter(p => p.username.includes(username.replace('@','')) || p.username === username);
  },

  deletePost: (postId: string) => {
    db.posts.delete(postId);
    // Call API delete...
  },

  incrementView: (postId: string, userEmail?: string) => {
    const post = db.posts.findById(postId);
    if (post) {
        // Optimistic update
        post.views = (post.views || 0) + 1;
        db.posts.update(post);
        // Fire and forget API call
        fetch(`${API_URL}/${postId}/view`, { method: 'POST' }).catch(() => {});
    }
  },

  toggleLike: (postId: string): Post | undefined => {
    const post = db.posts.findById(postId);
    if (post) {
        const newLiked = !post.liked;
        const updatedPost = { ...post, liked: newLiked, likes: post.likes + (newLiked ? 1 : -1) };
        db.posts.update(updatedPost);
        return updatedPost;
    }
    return undefined;
  },

  addComment: (postId: string, commentText: string, username: string, avatar?: string): Comment | undefined => {
    const post = db.posts.findById(postId);
    if (post) {
        const newComment: Comment = {
            id: Date.now().toString(),
            username, text: commentText, avatar, timestamp: Date.now(), likes: 0, likedByMe: false, replies: []
        };
        const updatedPost = {
            ...post,
            comments: post.comments + 1,
            commentsList: [newComment, ...(post.commentsList || [])]
        };
        db.posts.update(updatedPost);
        return newComment;
    }
    return undefined;
  },

  addReply: (postId: string, parentCommentId: string, text: string, username: string, avatar?: string): Comment | undefined => {
    const post = db.posts.findById(postId);
    if(!post || !post.commentsList) return undefined;
    
    const newReply: Comment = {
        id: Date.now().toString(),
        username, text, avatar, timestamp: Date.now(), likes: 0, likedByMe: false
    };

    // Recursive finder/updater would be better, simplistic here for demo
    const updatedComments = post.commentsList.map(c => {
        if (c.id === parentCommentId) {
            return { ...c, replies: [...(c.replies || []), newReply] };
        }
        return c;
    });

    const updatedPost = { ...post, comments: post.comments + 1, commentsList: updatedComments };
    db.posts.update(updatedPost);
    return newReply;
  },

  toggleCommentLike: (postId: string, commentId: string): boolean => {
    return true; // Placeholder
  }
};
