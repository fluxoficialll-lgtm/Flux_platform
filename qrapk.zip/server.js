
import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import cluster from 'cluster';
import os from 'os';
import compression from 'compression';
import helmet from 'helmet';
import multer from 'multer';
import rateLimit from 'express-rate-limit';
import fs from 'fs';
import { dbManager } from './backend/databaseManager.js';

// Configuração de Caminhos
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 3000;
// Escala: Usa todos os núcleos da CPU em produção
const numCPUs = process.env.WEB_CONCURRENCY || (process.env.NODE_ENV === 'production' ? os.cpus().length : 1);

// URL REAL da API do SyncPay (Proxy)
const SYNCPAY_API_URL = 'https://api.syncpayments.com.br';

// Configuração de Pasta de Uploads
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, uploadDir),
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        const ext = path.extname(file.originalname);
        cb(null, file.fieldname + '-' + uniqueSuffix + ext);
    }
});

const upload = multer({ storage: storage, limits: { fileSize: 100 * 1024 * 1024 } });

// Inicializar Conexões de Banco (Async)
dbManager.init();

// --- MOCK GENERATORS (Fallback para Feed/Grupos caso DB local caia) ---
const generateMockPosts = (limit, startTimestamp) => {
    const baseTime = startTimestamp || Date.now();
    return Array.from({ length: limit }).map((_, i) => ({
        id: `post_${baseTime}_${i}`,
        username: `@user_${Math.floor(Math.random() * 100)}`,
        text: `[MOCK] Post simulado #${i}. O banco de dados ScyllaDB não foi detectado, usando fallback em memória.`,
        type: Math.random() > 0.7 ? 'photo' : 'text',
        image: Math.random() > 0.7 ? `https://picsum.photos/seed/${i + baseTime}/400/500` : undefined,
        likes: Math.floor(Math.random() * 500),
        comments: Math.floor(Math.random() * 50),
        views: Math.floor(Math.random() * 5000),
        timestamp: baseTime - (i * 100000), 
        liked: false,
        isAdultContent: false
    }));
};

const mockGroups = [
    { id: '1', name: 'Comunidade Tech (Mock)', description: 'Banco offline', isVip: false, members: [] },
    { id: '2', name: 'Investimentos VIP (Mock)', description: 'Exemplo', isVip: true, price: '49.90', currency: 'BRL' }
];

if (cluster.isPrimary && numCPUs > 1) {
    console.log(`🚀 Flux Master ${process.pid} running with ${numCPUs} workers`);
    for (let i = 0; i < numCPUs; i++) cluster.fork();
    cluster.on('exit', (worker) => {
        console.log(`Worker ${worker.process.pid} died. Replacing...`);
        cluster.fork();
    });
} else {
    const app = express();

    // --- HIGH SCALE MIDDLEWARES ---
    app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 500 })); // Proteção DDoS
    app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
    app.use(compression()); // GZIP essencial para 50M users
    app.use(cors({ origin: true, credentials: true }));
    app.use(express.json({ limit: '50kb' })); // Payload pequeno para evitar estouro de memória

    app.get('/health', (req, res) => res.status(200).json({ 
        status: 'ok', 
        db: dbManager.state 
    }));

    // --- STATIC FILES (Simulando CDN) ---
    app.use('/uploads', express.static(uploadDir, {
        maxAge: '30d', // Cache agressivo no navegador
        immutable: true
    }));

    // --- API ROUTES ---

    // 1. Posts (Try Scylla -> Fallback Mock)
    app.get('/api/posts', async (req, res) => {
        const limit = parseInt(req.query.limit) || 10;
        const cursor = req.query.cursor ? parseInt(req.query.cursor) : Date.now();
        
        // Tenta buscar do banco de produção
        let posts = await dbManager.posts.list(limit, cursor);
        
        // Se banco offline ou vazio, usa Mock
        if (!posts || posts.length === 0) {
            posts = generateMockPosts(limit, cursor);
        }

        const nextCursor = posts.length > 0 ? posts[posts.length - 1].timestamp : null;
        res.json({ data: posts, nextCursor });
    });

    app.post('/api/posts/create', async (req, res) => {
        const post = req.body;
        // Tenta salvar no Scylla (Fire and Forget para performance)
        dbManager.posts.create(post).catch(err => console.error("DB Save Error", err));
        res.status(201).json({ success: true });
    });

    // 2. Groups (Try Postgres -> Fallback Mock)
    app.get('/api/groups', async (req, res) => {
        let groups = await dbManager.groups.list();
        if (!groups || groups.length === 0) {
            groups = mockGroups;
        }
        res.json({ data: groups });
    });

    app.post('/api/groups/create', async (req, res) => {
        await dbManager.groups.create(req.body);
        res.status(201).json({ success: true });
    });

    // 3. Uploads
    app.post('/api/upload', upload.any(), (req, res) => {
        if (!req.files?.length) return res.status(400).json({ error: 'No file' });
        const urls = req.files.map(f => ({
            url: `/uploads/${f.filename}`,
            type: f.mimetype
        }));
        res.json({ success: true, files: urls });
    });

    // 4. Auth & Search Stub
    app.post('/api/auth/login', (req, res) => res.json({ user: { email: req.body.email, isVerified: true }, token: "jwt_placeholder" }));
    app.get('/api/search/users', (req, res) => res.json({ data: [] }));
    app.get('/api/rankings/top', (req, res) => res.json({ data: [] }));

    // 6. SyncPay PROXY REVERSO (Real Integration)
    // Encaminha as chamadas do frontend para a API real do SyncPay
    // Isso protege as chaves de API e evita problemas de CORS
    const proxyToSyncPay = async (endpoint, method, body, res) => {
        try {
            // Real API Call
            const response = await fetch(`${SYNCPAY_API_URL}${endpoint}`, {
                method: method,
                headers: {
                    'Content-Type': 'application/json',
                    // Se houver autenticação global, adicione aqui
                },
                body: body ? JSON.stringify(body) : undefined
            });

            const data = await response.json();
            res.status(response.status).json(data);
        } catch (error) {
            console.error(`Proxy Error [${endpoint}]:`, error);
            res.status(502).json({ error: "Falha na comunicação com o provedor de pagamentos." });
        }
    };

    app.get('/api/syncpay/fees', (req, res) => proxyToSyncPay('/fees', 'GET', null, res));
    
    app.post('/api/syncpay/auth-token', (req, res) => proxyToSyncPay('/auth/token', 'POST', req.body, res));
    
    app.post('/api/syncpay/balance', (req, res) => proxyToSyncPay('/balance', 'POST', req.body, res));
    
    app.post('/api/syncpay/transactions', (req, res) => proxyToSyncPay('/transactions', 'POST', req.body, res));
    
    app.post('/api/syncpay/cash-in', (req, res) => proxyToSyncPay('/cash-in', 'POST', req.body, res));
    
    app.post('/api/syncpay/cash-out', (req, res) => proxyToSyncPay('/cash-out', 'POST', req.body, res));
    
    app.post('/api/syncpay/check-status', (req, res) => proxyToSyncPay('/transactions/status', 'POST', req.body, res));


    // 5. Serve Frontend
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
        if (!req.path.startsWith('/api')) res.sendFile(path.join(__dirname, 'dist', 'index.html'));
        else res.status(404).json({ error: 'Not Found' });
    });

    app.listen(PORT, '0.0.0.0', () => {
        console.log(`🚀 Server running on port ${PORT} (Env: ${process.env.NODE_ENV})`);
        console.log(`💳 Payment Gateway: ${SYNCPAY_API_URL}`);
    });
}
