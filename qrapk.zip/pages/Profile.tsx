
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { authService } from '../services/authService';
import { postService } from '../services/postService';
import { relationshipService } from '../services/relationshipService';
import { notificationService } from '../services/notificationService';
import { chatService } from '../services/chatService';
import { Post, User } from '../types';
import { db } from '@/database';

// --- Carousel Component (Inline for Profile) ---
const ImageCarousel: React.FC<{ images: string[] }> = ({ images }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const scrollRef = useRef<HTMLDivElement>(null);

    const handleScroll = () => {
        if (scrollRef.current) {
            const scrollLeft = scrollRef.current.scrollLeft;
            const width = scrollRef.current.offsetWidth;
            const index = Math.round(scrollLeft / width);
            setCurrentIndex(index);
        }
    };

    return (
        <div className="relative w-full mb-2.5 overflow-hidden rounded-xl bg-black">
            <div className="absolute top-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded-full z-10 backdrop-blur-sm">
                {currentIndex + 1}/{images.length}
            </div>
            <div 
                ref={scrollRef}
                className="flex overflow-x-auto snap-x snap-mandatory no-scrollbar w-full aspect-[4/5]"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                onScroll={handleScroll}
            >
                {images.map((img, idx) => (
                    <img 
                        key={idx} 
                        src={img} 
                        alt={`Slide ${idx}`} 
                        className="w-full h-full flex-shrink-0 snap-center object-cover" 
                    />
                ))}
            </div>
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
                {images.map((_, idx) => (
                    <div 
                        key={idx} 
                        className={`w-1.5 h-1.5 rounded-full transition-all ${currentIndex === idx ? 'bg-[#00c2ff] scale-125' : 'bg-white/50'}`}
                    ></div>
                ))}
            </div>
        </div>
    );
};

interface SimpleUserList {
    name: string;
    username: string;
    avatar?: string;
}

export const Profile: React.FC = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('posts');
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
  const [myPosts, setMyPosts] = useState<Post[]>([]);
  const [user, setUser] = useState<User | null>(null);
  
  // Followers/Following States
  const [followersCount, setFollowersCount] = useState(0);
  const [followingCount, setFollowingCount] = useState(0);
  const [followListType, setFollowListType] = useState<'followers' | 'following' | null>(null);
  const [followListData, setFollowListData] = useState<SimpleUserList[]>([]);

  // Notification Badges
  const [unreadNotifs, setUnreadNotifs] = useState(0);
  const [unreadMsgs, setUnreadMsgs] = useState(0);

  useEffect(() => {
    const userEmail = authService.getCurrentUserEmail();
    if (!userEmail) {
      navigate('/');
      return;
    }
    
    const currentUser = authService.getCurrentUser();
    setUser(currentUser);

    const handleClickOutside = () => setActiveMenuId(null);
    document.addEventListener('click', handleClickOutside);

    const username = currentUser?.profile?.name ? `@${currentUser.profile.name}` : "@usuario";
    
    // Load Posts
    const storedPosts = postService.getUserPosts(username);
    setMyPosts(storedPosts.sort((a, b) => b.timestamp - a.timestamp));

    // Load Follow Stats
    if (currentUser && currentUser.profile && currentUser.profile.name) {
        const followers = relationshipService.getFollowers(currentUser.profile.name);
        setFollowersCount(followers.length);
    }
    if (currentUser && currentUser.email) {
        const following = relationshipService.getFollowing(currentUser.email);
        setFollowingCount(following.length);
    }

    return () => document.removeEventListener('click', handleClickOutside);
  }, [navigate]);

  // Notification Badges Effect
  useEffect(() => {
      const updateCounts = () => {
          setUnreadNotifs(notificationService.getUnreadCount());
          setUnreadMsgs(chatService.getUnreadCount());
      };
      updateCounts();
      const unsubNotif = db.subscribe('notifications', updateCounts);
      const unsubChat = db.subscribe('chats', updateCounts);
      
      return () => { unsubNotif(); unsubChat(); };
  }, []);

  const toggleMenu = (e: React.MouseEvent, menuId: string) => {
    e.stopPropagation();
    setActiveMenuId(activeMenuId === menuId ? null : menuId);
  };

  const deletePost = (postId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if(window.confirm("Tem certeza que deseja excluir este post permanentemente?")) {
        postService.deletePost(postId);
        // Remove from local state immediately
        setMyPosts(prev => prev.filter(p => p.id !== postId));
        setActiveMenuId(null);
    }
  };

  const handleShowFollowList = (type: 'followers' | 'following') => {
      if (!user) return;
      
      let list: SimpleUserList[] = [];
      if (type === 'followers' && user.profile?.name) {
          list = relationshipService.getFollowers(user.profile.name);
      } else if (type === 'following' && user.email) {
          list = relationshipService.getFollowing(user.email);
      }
      
      setFollowListData(list);
      setFollowListType(type);
  };

  const closeFollowList = () => {
      setFollowListType(null);
      setFollowListData([]);
  };

  const navigateToUserProfile = (username: string) => {
      closeFollowList();
      const clean = username.replace('@', '');
      navigate(`/user/${clean}`);
  };

  // Display Name Logic
  const username = user?.profile?.name ? `@${user.profile.name}` : "@usuario";
  const nickname = user?.profile?.nickname || user?.profile?.name; // Fallback to name if no nickname
  const displayBio = user?.profile?.bio || "Sem biografia definida.";
  const displayAvatar = user?.profile?.photoUrl;
  const displayWebsite = user?.profile?.website;

  // --- CATEGORIZATION LOGIC ---
  const textPosts = myPosts.filter(p => p.type === 'text' || p.type === 'poll');
  const photoPosts = myPosts.filter(p => p.type === 'photo' && (p.image || (p.images && p.images.length > 0)));
  const reelPosts = myPosts.filter(p => p.type === 'video');

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-x-hidden">
      <style>{`
        /* CSS Styles (Maintained) */
        header {
            display: flex; align-items: center; justify-content: space-between; padding: 16px 32px;
            background: #0c0f14; position: fixed; width: 100%; z-index: 10; border-bottom: 1px solid rgba(255,255,255,0.1);
            top: 0; height: 80px;
        }
        header button {
            background: none; border: none; color: #00c2ff; font-size: 18px; cursor: pointer; transition: 0.3s;
        }
        header button:hover { color: #fff; }

        .profile-header {
            display: flex; flex-direction: column; align-items: center; padding: 0 30px 20px 30px; 
            margin-bottom: 20px; border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .profile-avatar {
            width: 100px; height: 100px; border-radius: 50%; border: 3px solid #00c2ff;
            object-fit: cover; margin-bottom: 15px; box-shadow: 0 0 15px rgba(0,194,255,0.4);
        }
        .profile-avatar-placeholder {
            width: 100px; height: 100px; border-radius: 50%; border: 3px solid #00c2ff;
            margin-bottom: 15px; box-shadow: 0 0 15px rgba(0,194,255,0.4);
            background: rgba(255,255,255,0.1);
            display: flex; align-items: center; justify-content: center;
            font-size: 40px; color: #00c2ff;
        }
        .profile-nickname { font-size: 24px; font-weight: 800; color: #fff; margin-bottom: 2px; text-transform: capitalize; }
        .profile-handle { font-size: 14px; color: #aaa; font-weight: 600; margin-bottom: 10px; }
        
        .profile-bio {
            font-size: 14px; color: rgba(255,255,255,0.8); text-align: center; max-width: 90%; margin-bottom: 15px; white-space: pre-wrap;
        }
        
        .profile-link {
            display: inline-flex; align-items: center; gap: 6px;
            color: #00c2ff; font-size: 14px; font-weight: 600;
            margin-bottom: 20px; text-decoration: none;
            background: rgba(0,194,255,0.1); padding: 6px 12px; border-radius: 20px;
            transition: 0.3s; border: 1px solid transparent;
        }
        .profile-link:hover {
            background: rgba(0,194,255,0.2); border-color: #00c2ff;
        }

        .profile-stats {
            display: flex; justify-content: space-around; margin-bottom: 30px; width: 100%; max-width: 350px;
        }
        .stat-item { 
            display: flex; flex-direction: column; align-items: center; font-size: 16px; cursor: pointer; transition: opacity 0.2s;
        }
        .stat-item:hover { opacity: 0.8; }
        .stat-number { font-weight: 700; color: #00c2ff; font-size: 20px; }
        
        .profile-actions {
            display: flex; gap: 10px; justify-content: center; width: 100%; max-width: 350px; margin-bottom: 20px;
        }
        .profile-actions button {
            flex-grow: 1; padding: 8px 15px; border-radius: 8px; font-size: 14px; cursor: pointer; transition: 0.3s; font-weight: 600;
        }
        #editProfileBtn { background: #00c2ff; color: #0c0f14; border: none; }
        #editProfileBtn:hover { background: #007bff; }
        #shareProfileBtn { background: none; color: #00c2ff; border: 1px solid #00c2ff; }
        #shareProfileBtn:hover { background: rgba(0,194,255,0.2); }

        .profile-tabs-container { width: 100%; }
        .tab-nav {
            display: flex; justify-content: space-around; border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 10px; padding: 0 5px; 
        }
        .tab-nav button {
            background: none; border: none; color: rgba(255,255,255,0.5); padding: 10px 0; font-size: 14px; font-weight: 600;
            cursor: pointer; flex-grow: 1; transition: color 0.3s; position: relative;
        }
        .tab-nav button:hover { color: rgba(255,255,255,0.8); }
        .tab-nav button.active { color: #00c2ff; }
        .tab-nav button.active::after {
            content: ''; position: absolute; bottom: -1px; left: 0; width: 100%; height: 3px; background: #00c2ff;
        }

        /* Post List (Used for Text & Photo Tabs) */
        .post-list {
            display: flex; flex-direction: column; gap: 15px; padding: 0 15px; width: 100%;
        }
        .post-card {
            background: #14171d; border-radius: 12px; padding: 15px; border: 1px solid rgba(255,255,255,0.05);
            box-shadow: 0 4px 10px rgba(0,0,0,0.3); cursor: pointer; transition: transform 0.2s, border-color 0.2s; position: relative; 
        }
        .post-card:hover { border-color: #00c2ff; }
        .post-header { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
        .post-avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 2px solid #00c2ff; }
        .post-avatar-icon { width: 40px; height: 40px; border-radius: 50%; border: 2px solid #00c2ff; background: #1e2531; display: flex; align-items: center; justify-content: center; color: #00c2ff; font-size: 18px; }
        .post-info { display: flex; flex-direction: column; }
        .post-username { font-size: 14px; font-weight: 700; color: #fff; }
        .post-time { font-size: 12px; color: rgba(255,255,255,0.6); }
        .post-content {
            font-size: 16px; color: rgba(255,255,255,0.9); line-height: 1.4; margin-bottom: 15px;
        }
        .post-image-container { width: 100%; margin-bottom: 15px; border-radius: 10px; overflow: hidden; background: #000; display: flex; justify-content: center; }
        .post-image-container img { width: 100%; height: auto; max-height: 650px; object-fit: contain; display: block; }
        
        .post-actions {
            display: flex; justify-content: space-around; padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.05);
        }
        .post-actions button {
            background: none; border: none; color: rgba(255,255,255,0.7); font-size: 14px; cursor: pointer; transition: color 0.3s; display: flex; align-items: center; gap: 6px;
        }
        .post-actions button:hover { color: #00c2ff; }

        /* Grid Layout (Reels only now) */
        .gallery-grid {
            display: grid; grid-template-columns: repeat(3, 1fr); gap: 3px; padding: 3px; width: 100%;
        }
        .gallery-item {
            position: relative; width: 100%; cursor: pointer; background: #111;
        }
        .gallery-item.reel-item {
             aspect-ratio: 9/16;
        }
        
        .gallery-item img { width: 100%; height: 100%; object-fit: cover; display: block; }
        
        .reel-icon {
            position: absolute; top: 5px; right: 5px; color: white; font-size: 14px; text-shadow: 0 0 2px black;
        }
        
        /* Hide Scrollbar for Carousel */
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .no-scrollbar {
            -ms-overflow-style: none;  /* IE and Edge */
            scrollbar-width: none;  /* Firefox */
        }

        .menu-options-btn {
            position: absolute; top: 10px; right: 10px; background: none; border: none; color: rgba(255, 255, 255, 0.7); font-size: 18px; cursor: pointer; z-index: 10; line-height: 1; transition: color 0.2s; padding: 5px;
        }
        .menu-options-btn:hover { color: #00c2ff; }
        .grid-menu {
            position: absolute; top: 40px; right: 10px; background: #1f2129; border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5); z-index: 15; width: 120px; display: none; overflow: hidden;
        }
        .grid-menu.active { display: block; }
        .grid-menu button {
            display: block; width: 100%; padding: 10px; text-align: left; background: none; border: none; color: #fff; font-size: 14px; cursor: pointer; transition: background 0.2s;
        }
        .grid-menu button:hover { background: #00c2ff20; }
        .grid-menu button.delete { color: #ff4d4d; }

        /* Footer Styling */
        footer button {
            position: relative; background: none; border: none; padding: 10px; cursor: pointer; transition: color 0.3s;
        }
        
        .no-content {
             text-align: center; padding: 50px 0; color: rgba(255,255,255,0.5); font-size: 16px;
        }

        /* Follow List Modal */
        .follow-modal-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.8); z-index: 50;
            display: flex; align-items: center; justify-content: center;
            backdrop-filter: blur(5px);
        }
        .follow-modal {
            background: #1a1e26; width: 90%; max-width: 400px;
            border-radius: 16px; border: 1px solid rgba(255,255,255,0.1);
            box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            display: flex; flex-direction: column; max-height: 70vh;
        }
        .follow-header {
            padding: 15px 20px; border-bottom: 1px solid rgba(255,255,255,0.1);
            display: flex; justify-content: space-between; align-items: center;
        }
        .follow-header h3 { font-size: 18px; font-weight: 700; color: #fff; }
        .close-modal-btn { background: none; border: none; color: #aaa; font-size: 20px; cursor: pointer; }
        .follow-list {
            overflow-y: auto; padding: 10px 0;
        }
        .follow-item {
            display: flex; align-items: center; padding: 10px 20px;
            cursor: pointer; transition: background 0.2s;
        }
        .follow-item:hover { background: rgba(255,255,255,0.05); }
        .f-avatar {
            width: 40px; height: 40px; border-radius: 50%; object-fit: cover;
            margin-right: 12px; background: #333; border: 1px solid #555;
            display: flex; align-items: center; justify-content: center;
        }
        .f-info { display: flex; flex-direction: column; }
        .f-name { font-weight: 600; color: #fff; font-size: 14px; }
        .f-username { font-size: 12px; color: #aaa; }

        /* Badge */
        .nav-badge {
            position: absolute; top: 2px; right: 2px;
            width: 10px; height: 10px; background: #ff4d4d;
            border-radius: 50%; border: 1px solid #0c0f14;
        }
      `}</style>

      <header>
        <button onClick={() => navigate('/rank')}><i className="fa-solid fa-trophy"></i></button>
        
        {/* Standardized Logo */}
        <div 
            className="absolute left-1/2 -translate-x-1/2 w-[60px] h-[60px] bg-white/5 rounded-2xl flex justify-center items-center z-20 cursor-pointer shadow-[0_0_20px_rgba(0,194,255,0.3),inset_0_0_20px_rgba(0,194,255,0.08)]"
            onClick={() => navigate('/feed')}
        >
             <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] rotate-[25deg]"></div>
             <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] -rotate-[25deg]"></div>
        </div>

        <button style={{marginLeft:'auto'}} onClick={() => navigate('/settings')}>
            <i className="fa-solid fa-gear"></i>
        </button>
      </header>

      <main className="flex-grow flex flex-col items-center w-full pt-[100px] pb-[100px]">
        <div style={{width:'100%', maxWidth:'600px', padding:'20px 0'}}>
            <div className="profile-header">
                {displayAvatar ? (
                    <img src={displayAvatar} className="profile-avatar" alt="Avatar do Usuário" />
                ) : (
                    <div className="profile-avatar-placeholder">
                        <i className="fa-solid fa-user"></i>
                    </div>
                )}
                
                {/* Display Name (Apelido) */}
                <h1 className="profile-nickname">{nickname}</h1>
                
                {/* Handle (@username) */}
                <p className="profile-handle">{username}</p>
                
                <p className="profile-bio">
                    {displayBio}
                </p>

                {/* Link/Website - Visible if exists */}
                {displayWebsite && (
                    <a 
                        href={displayWebsite} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="profile-link"
                    >
                        <i className="fa-solid fa-link"></i> {displayWebsite.replace(/^https?:\/\//, '').replace(/\/$/, '')}
                    </a>
                )}

                <div className="profile-stats">
                    <div className="stat-item">
                        <span className="stat-number">{myPosts.length}</span> <span>Posts</span>
                    </div>
                    <div className="stat-item" onClick={() => handleShowFollowList('followers')}>
                        <span className="stat-number">{followersCount}</span>
                        <span>Seguidores</span>
                    </div>
                    <div className="stat-item" onClick={() => handleShowFollowList('following')}>
                        <span className="stat-number">{followingCount}</span>
                        <span>Seguindo</span>
                    </div>
                </div>
                
                <div className="profile-actions">
                    <button id="editProfileBtn" onClick={() => navigate('/edit-profile')}>
                        <i className="fa-solid fa-pen"></i> Editar Perfil
                    </button>
                    <button id="shareProfileBtn" onClick={() => alert('Compartilhar o perfil do usuário')}>
                        <i className="fa-solid fa-share-nodes"></i> Compartilhar
                    </button>
                </div>
            </div>

            <div className="profile-tabs-container">
                <div className="tab-nav">
                    <button 
                        className={activeTab === 'posts' ? 'active' : ''} 
                        onClick={() => setActiveTab('posts')}
                    >
                        <i className="fa-solid fa-list-ul"></i> Posts
                    </button>
                    <button 
                        className={activeTab === 'fotos' ? 'active' : ''} 
                        onClick={() => setActiveTab('fotos')}
                    >
                        <i className="fa-solid fa-camera"></i> Fotos
                    </button>
                    <button 
                        className={activeTab === 'reels' ? 'active' : ''} 
                        onClick={() => setActiveTab('reels')}
                    >
                        <i className="fa-solid fa-video"></i> Reels
                    </button>
                </div>

                <div className="tab-content">
                    {/* TAB: POSTS DE TEXTO */}
                    {activeTab === 'posts' && (
                        <div className="post-list animate-fade-in">
                            {textPosts.length > 0 ? textPosts.map(post => (
                                <div key={post.id} className="post-card" onClick={() => navigate(`/post/${post.id}`)}>
                                    <div className="post-header">
                                        {post.avatar ? (
                                            <img src={post.avatar} className="post-avatar" alt="Avatar" />
                                        ) : (
                                            <div className="post-avatar-icon">
                                                <i className="fa-solid fa-user"></i>
                                            </div>
                                        )}
                                        <div className="post-info">
                                            <span className="post-username">{post.username}</span>
                                            <span className="post-time">{post.time}</span>
                                        </div>
                                    </div>
                                    
                                    <button className="menu-options-btn" onClick={(e) => toggleMenu(e, `post-${post.id}`)}>
                                        <i className="fa-solid fa-ellipsis"></i>
                                    </button>
                                    
                                    <div className={`grid-menu ${activeMenuId === `post-${post.id}` ? 'active' : ''}`} onClick={(e) => e.stopPropagation()}>
                                        <button className="delete" onClick={(e) => deletePost(post.id, e)}>
                                            <i className="fa-solid fa-trash-can"></i> Excluir
                                        </button>
                                    </div>

                                    <p className="post-content">{post.text}</p>
                                    
                                    <div className="post-actions">
                                        <button><i className="fa-solid fa-heart"></i> {post.likes}</button>
                                        <button><i className="fa-solid fa-comment"></i> {post.comments}</button>
                                        <button><i className="fa-solid fa-share"></i></button>
                                    </div>
                                </div>
                            )) : (
                                <div className="no-content">Você ainda não tem posts de texto.</div>
                            )}
                        </div>
                    )}

                    {/* TAB: FOTOS */}
                    {activeTab === 'fotos' && (
                         <div className="post-list animate-fade-in">
                             {photoPosts.length > 0 ? photoPosts.map(post => {
                                 const hasCarousel = post.images && post.images.length > 1;
                                 return (
                                     <div key={post.id} className="post-card">
                                         <div className="post-header" onClick={() => navigate(`/post/${post.id}`)}>
                                             {post.avatar ? (
                                                 <img src={post.avatar} className="post-avatar" alt="Avatar" />
                                             ) : (
                                                 <div className="post-avatar-icon"><i className="fa-solid fa-user"></i></div>
                                             )}
                                             <div className="post-info">
                                                 <span className="post-username">{post.username}</span>
                                                 <span className="post-time">{post.time}</span>
                                             </div>
                                         </div>

                                         <button className="menu-options-btn" onClick={(e) => toggleMenu(e, `post-${post.id}`)}>
                                             <i className="fa-solid fa-ellipsis"></i>
                                         </button>
                                         
                                         <div className={`grid-menu ${activeMenuId === `post-${post.id}` ? 'active' : ''}`} onClick={(e) => e.stopPropagation()}>
                                             <button className="delete" onClick={(e) => deletePost(post.id, e)}>
                                                 <i className="fa-solid fa-trash-can"></i> Excluir
                                             </button>
                                         </div>

                                         <p className="post-content" onClick={() => navigate(`/post/${post.id}`)}>{post.text}</p>

                                         {/* Render Image or Carousel */}
                                         {hasCarousel ? (
                                             <ImageCarousel images={post.images!} />
                                         ) : (
                                             <div className="post-image-container" onClick={() => navigate(`/post/${post.id}`)}>
                                                 <img src={post.image || post.images?.[0]} alt="Post" />
                                             </div>
                                         )}

                                         <div className="post-actions">
                                             <button><i className="fa-solid fa-heart"></i> {post.likes}</button>
                                             <button onClick={() => navigate(`/post/${post.id}`)}><i className="fa-solid fa-comment"></i> {post.comments}</button>
                                             <button><i className="fa-solid fa-share"></i></button>
                                         </div>
                                     </div>
                                 );
                             }) : (
                                 <div className="no-content">Você ainda não tem fotos.</div>
                             )}
                         </div>
                    )}

                    {/* TAB: REELS (Grid) */}
                    {activeTab === 'reels' && (
                        <div className="gallery-grid animate-fade-in">
                            {reelPosts.length > 0 ? reelPosts.map(post => (
                                <div key={post.id} className="gallery-item reel-item" onClick={() => navigate(`/post/${post.id}`)}>
                                    <img src={post.image || 'https://via.placeholder.com/150'} alt="Reel Thumbnail" />
                                    <div className="reel-icon"><i className="fa-solid fa-video"></i> {post.views}</div>
                                </div>
                            )) : (
                                <div className="no-content" style={{gridColumn: '1/-1'}}>Você ainda não tem reels.</div>
                            )}
                        </div>
                    )}
                </div>
            </div>
        </div>
      </main>

      {/* FOLLOW LIST MODAL */}
      {followListType && (
          <div className="follow-modal-overlay" onClick={closeFollowList}>
              <div className="follow-modal" onClick={(e) => e.stopPropagation()}>
                  <div className="follow-header">
                      <h3>{followListType === 'followers' ? 'Seguidores' : 'Seguindo'}</h3>
                      <button className="close-modal-btn" onClick={closeFollowList}>
                          <i className="fa-solid fa-xmark"></i>
                      </button>
                  </div>
                  <div className="follow-list">
                      {followListData.length > 0 ? (
                          followListData.map((u, idx) => (
                              <div key={idx} className="follow-item" onClick={() => navigateToUserProfile(u.username)}>
                                  {u.avatar ? (
                                      <img src={u.avatar} className="f-avatar" alt={u.name} />
                                  ) : (
                                      <div className="f-avatar"><i className="fa-solid fa-user"></i></div>
                                  )}
                                  <div className="f-info">
                                      <span className="f-name">{u.name}</span>
                                      <span className="f-username">@{u.username}</span>
                                  </div>
                              </div>
                          ))
                      ) : (
                          <div className="p-5 text-center text-gray-500">Nenhum usuário encontrado.</div>
                      )}
                  </div>
              </div>
          </div>
      )}

      <footer style={{
          position:'fixed', bottom:0, left:0, width:'100%', background:'#0c0f14',
          display:'flex', justifyContent:'space-around', padding:'14px 0',
          borderTopLeftRadius:'20px', borderTopRightRadius:'20px', zIndex:20,
          boxShadow:'0 -2px 10px rgba(0,0,0,0.5)'
      }}>
        <button onClick={() => navigate('/feed')} className="text-[#00c2ff] text-[22px] cursor-pointer p-2 hover:text-white transition-all">
            <i className="fa-solid fa-newspaper"></i>
        </button>
        <button onClick={() => navigate('/messages')} className="text-[#00c2ff] text-[22px] cursor-pointer p-2 hover:text-white transition-all">
            <i className="fa-solid fa-comments"></i>
            {unreadMsgs > 0 && <div className="nav-badge"></div>}
        </button>
        <button onClick={() => navigate('/notifications')} className="text-[#00c2ff] text-[22px] cursor-pointer p-2 hover:text-white transition-all">
            <i className="fa-solid fa-bell"></i>
            {unreadNotifs > 0 && <div className="nav-badge"></div>}
        </button>
        <button onClick={() => navigate('/profile')} className="text-white text-[22px] cursor-pointer p-2 transition-all">
            <i className="fa-solid fa-user"></i>
        </button>
      </footer>
    </div>
  );
};
