
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { authService } from '../services/authService';
import { relationshipService } from '../services/relationshipService';
import { chatService } from '../services/chatService';
import { notificationService } from '../services/notificationService';
import { db } from '@/database';

interface Contact {
  id: string;
  name: string; // Display Name (Apelido or @username)
  avatar?: string; // Real Avatar
  lastMessage: string;
  time: string;
  status: 'online' | string; // Status Text
  isOnline: boolean; // Boolean for green dot
}

interface MutualFriend {
    id: number | string; // Updated to handle email as ID
    name: string;
    username: string;
    avatar: string;
}

export const Messages: React.FC = () => {
  const navigate = useNavigate();
  const [uiVisible, setUiVisible] = useState(true);
  const lastScrollY = useRef(0);
  
  // Logic states
  const [contacts, setContacts] = useState<Contact[]>([]);

  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // New Chat State
  const [isNewChatOpen, setIsNewChatOpen] = useState(false);
  const [newChatSearch, setNewChatSearch] = useState('');
  const [mutualFriends, setMutualFriends] = useState<MutualFriend[]>([]);

  // Notification Badges
  const [unreadNotifs, setUnreadNotifs] = useState(0);
  const [unreadMsgs, setUnreadMsgs] = useState(0);

  const menuRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);

  // Helper to format last seen
  const formatLastSeen = (timestamp?: number) => {
      if (!timestamp) return "Offline";
      const diff = Date.now() - timestamp;
      if (diff < 2 * 60 * 1000) return "online"; // < 2 mins = Online
      
      // Simple formatter
      const date = new Date(timestamp);
      const hours = date.getHours().toString().padStart(2, '0');
      const minutes = date.getMinutes().toString().padStart(2, '0');
      return `Visto por último às ${hours}:${minutes}`;
  };

  // Function to load chats - memoized for reuse
  const loadChats = useCallback(() => {
      const currentUserEmail = authService.getCurrentUserEmail();
      if (!currentUserEmail) return;

      const rawChats = chatService.getAllChats();
      
      const formatted: Contact[] = Object.values(rawChats).map(chat => {
          const chatIdStr = chat.id.toString();
          // Only show chats where the current user is a participant or creator
          // Check if chat.id is composite (email1_email2)
          if (chatIdStr.includes('@')) {
              if (!chatIdStr.includes(currentUserEmail)) return null;
          } else {
              // Fallback logic for old non-email IDs (e.g. groups, though groups usually have numeric IDs)
              // If you have a way to distinguish groups from chats, add it here.
              // For now assuming all non-@ chats are accessible (legacy)
          }

          const lastMsg = chat.messages.length > 0 ? chat.messages[chat.messages.length - 1] : null;
          
          let previewText = '';
          if (lastMsg) {
              if (lastMsg.type === 'sent') {
                  previewText = `Você: ${lastMsg.contentType === 'text' ? lastMsg.text : (lastMsg.contentType === 'image' ? '📷 Foto' : (lastMsg.contentType === 'video' ? '🎥 Vídeo' : '🎤 Áudio'))}`;
              } else {
                  previewText = lastMsg.contentType === 'text' ? lastMsg.text : (lastMsg.contentType === 'image' ? '📷 Foto' : (lastMsg.contentType === 'video' ? '🎥 Vídeo' : '🎤 Áudio'));
              }
          }

          // --- DYNAMIC PARTNER RESOLUTION ---
          let displayName = chat.contactName;
          let avatarUrl: string | undefined = undefined;
          let targetUser = undefined;

          if (chatIdStr.includes('_') && chatIdStr.includes('@')) {
              // It's a private chat: emailA_emailB
              const parts = chatIdStr.split('_');
              const otherEmail = parts.find(p => p !== currentUserEmail);
              
              if (otherEmail) {
                  // Get user by email from DB (need a helper or iterate all)
                  const allUsers = authService.getAllUsers();
                  // Includes current user too just in case getAllUsers filters
                  const user = allUsers.find(u => u.email === otherEmail) || (authService.getCurrentUser()?.email === otherEmail ? authService.getCurrentUser() : undefined);
                  
                  if (user) {
                      targetUser = user;
                      // Priority: Nickname > Handle > Email
                      displayName = user.profile?.nickname || user.profile?.name || otherEmail;
                      avatarUrl = user.profile?.photoUrl;
                  } else {
                      displayName = otherEmail; // Fallback
                  }
              }
          } else {
              // Try to resolve by contactName if it's a handle
              targetUser = authService.getUserByHandle(chat.contactName);
              if (targetUser) {
                  displayName = targetUser.profile?.nickname || targetUser.profile?.name || chat.contactName;
                  avatarUrl = targetUser.profile?.photoUrl;
              }
          }

          const statusText = formatLastSeen(targetUser?.lastSeen);
          const isOnline = statusText === 'online';

          const contact: Contact = {
              id: chat.id.toString(),
              name: displayName,
              avatar: avatarUrl,
              lastMessage: previewText,
              time: lastMsg ? lastMsg.timestamp : '',
              status: statusText,
              isOnline: isOnline
          };
          return contact;
      }).filter((c): c is Contact => c !== null && c.lastMessage !== '').sort((a, b) => {
          // Sort by time
          return b.time.localeCompare(a.time); 
      });

      setContacts(formatted);
  }, []);

  useEffect(() => {
    const userEmail = authService.getCurrentUserEmail();
    if (!userEmail) {
      navigate('/');
      return;
    }

    // Initial Load
    loadChats();

    // Subscribe to Chat Updates AND User Updates (for status/avatar)
    const unsubscribeChats = db.subscribe('chats', () => loadChats());
    const unsubscribeUsers = db.subscribe('users', () => loadChats()); // For Online status

    const handleScroll = () => {
      const currentScroll = window.scrollY;
      if (currentScroll > lastScrollY.current && currentScroll > 80) {
        setUiVisible(false);
      } else {
        setUiVisible(true);
      }
      lastScrollY.current = currentScroll;
    };

    const handleClickOutside = (event: MouseEvent) => {
        if (
            menuRef.current && 
            !menuRef.current.contains(event.target as Node) &&
            buttonRef.current &&
            !buttonRef.current.contains(event.target as Node)
        ) {
            setIsMenuOpen(false);
        }
    };

    window.addEventListener("scroll", handleScroll);
    document.addEventListener("mousedown", handleClickOutside);
    
    return () => {
        unsubscribeChats();
        unsubscribeUsers();
        window.removeEventListener("scroll", handleScroll);
        document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [navigate, loadChats]);

  // Notification Badges Effect
  useEffect(() => {
      const updateCounts = () => {
          setUnreadNotifs(notificationService.getUnreadCount());
          setUnreadMsgs(chatService.getUnreadCount());
      };
      updateCounts();
      const unsubNotif = db.subscribe('notifications', updateCounts);
      const unsubChat = db.subscribe('chats', updateCounts);
      
      return () => { unsubNotif(); unsubChat(); };
  }, []);

  // Load mutuals when opening the modal
  useEffect(() => {
      if (isNewChatOpen) {
          relationshipService.getMutualFriends().then(friends => {
              setMutualFriends(friends);
          });
      }
  }, [isNewChatOpen]);

  // Handlers
  const handleContactClick = (id: string) => {
      if (isSelectionMode) {
          toggleSelection(id);
      } else {
          navigate(`/chat/${id}`);
      }
  };

  const toggleSelection = (id: string) => {
      if (selectedIds.includes(id)) {
          setSelectedIds(prev => prev.filter(item => item !== id));
      } else {
          setSelectedIds(prev => [...prev, id]);
      }
  };

  const startSelectionMode = () => {
      setIsMenuOpen(false);
      setIsSelectionMode(true);
      setSelectedIds([]);
  };

  const cancelSelectionMode = () => {
      setIsSelectionMode(false);
      setSelectedIds([]);
  };

  const deleteSelected = () => {
      if (selectedIds.length === 0) return;
      
      if (window.confirm(`Deseja apagar ${selectedIds.length} conversa(s)?`)) {
          // In a real app, call delete on service
          // chatService.deleteChats(selectedIds);
          // For now update local state
          setContacts(prev => prev.filter(c => !selectedIds.includes(c.id)));
          setIsSelectionMode(false);
          setSelectedIds([]);
      }
  };

  // Handle starting a new chat from the mutuals list
  const handleStartNewChat = (friendId: string | number) => {
      const currentUserEmail = authService.getCurrentUserEmail();
      const friendEmail = friendId.toString(); // Assuming friendId is email for mutuals
      
      if (currentUserEmail) {
          const chatId = chatService.getPrivateChatId(currentUserEmail, friendEmail);
          setIsNewChatOpen(false);
          navigate(`/chat/${chatId}`);
      }
  };

  const filteredMutuals = mutualFriends.filter(f => 
      f.name.toLowerCase().includes(newChatSearch.toLowerCase()) || 
      f.username.toLowerCase().includes(newChatSearch.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-x-hidden">
        <style>{`
            /* Dropdown Menu */
            .msg-dropdown {
                position: absolute;
                top: 60px;
                left: 20px;
                background: #1a1e26;
                border: 1px solid rgba(255,255,255,0.1);
                border-radius: 8px;
                box-shadow: 0 4px 15px rgba(0,0,0,0.5);
                z-index: 50;
                min-width: 180px;
                overflow: hidden;
                animation: fadeIn 0.2s ease-out;
            }
            .msg-dropdown button {
                display: flex; align-items: center; width: 100%;
                padding: 12px 15px; background: none; border: none;
                color: #fff; font-size: 14px; cursor: pointer;
                transition: background 0.2s; text-align: left;
            }
            .msg-dropdown button:hover { background: rgba(0,194,255,0.1); color: #00c2ff; }
            .msg-dropdown button i { margin-right: 10px; width: 20px; text-align: center; }

            @keyframes fadeIn { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }

            /* Checkbox Animation */
            .select-checkbox {
                width: 22px; height: 22px; border-radius: 50%;
                border: 2px solid #555; margin-right: 15px;
                display: flex; align-items: center; justify-content: center;
                transition: all 0.2s; flex-shrink: 0;
            }
            .select-checkbox.selected {
                background: #00c2ff; border-color: #00c2ff;
            }
            .select-checkbox.selected::after {
                content: '✔'; font-size: 12px; color: #000; font-weight: bold;
            }
            
            /* Header Transition */
            header { transition: background 0.3s; }
            header.selection-active { background: #0f2b38; } /* Darker blue tone */

            /* NEW CHAT MODAL */
            .new-chat-overlay {
                position: fixed; top: 0; left: 0; width: 100%; height: 100%;
                background: #0c0f14; z-index: 100;
                display: flex; flex-direction: column;
                animation: slideIn 0.3s ease-out;
            }
            @keyframes slideIn { from { transform: translateY(100%); } to { transform: translateY(0); } }
            
            .nc-header {
                display: flex; align-items: center; padding: 16px;
                border-bottom: 1px solid rgba(255,255,255,0.1);
                gap: 15px;
            }
            .nc-back-btn {
                background: none; border: none; color: #00c2ff; font-size: 20px; cursor: pointer;
            }
            .nc-title { font-size: 18px; font-weight: 600; }
            
            .nc-search {
                padding: 15px; border-bottom: 1px solid rgba(255,255,255,0.05);
            }
            .nc-search input {
                width: 100%; background: #1a1e26; border: 1px solid rgba(255,255,255,0.1);
                border-radius: 8px; padding: 10px 15px; color: #fff; outline: none;
            }
            .nc-search input:focus { border-color: #00c2ff; }
            
            /* GLOBAL SEARCH ENTRY POINT */
            .global-find-btn {
                display: flex; align-items: center; justify-content: center; gap: 10px;
                width: 90%; margin: 10px auto; padding: 12px;
                background: rgba(0,194,255,0.1); border: 1px solid rgba(0,194,255,0.3);
                border-radius: 10px; color: #00c2ff; font-weight: 600; font-size: 14px;
                cursor: pointer; transition: 0.3s;
            }
            .global-find-btn:hover {
                background: rgba(0,194,255,0.2);
            }

            .nc-list { flex: 1; overflow-y: auto; padding: 10px 0; }
            .nc-item {
                display: flex; align-items: center; padding: 12px 20px;
                border-bottom: 1px solid rgba(255,255,255,0.05); cursor: pointer;
                transition: background 0.2s;
            }
            .nc-item:hover { background: rgba(255,255,255,0.05); }
            .nc-avatar {
                width: 45px; height: 45px; border-radius: 50%; margin-right: 15px;
                background: #333; display: flex; align-items: center; justify-content: center;
                color: #888; object-fit: cover;
            }
            .nc-info { display: flex; flex-direction: column; }
            .nc-name { font-weight: 600; font-size: 15px; color: #fff; }
            .nc-username { font-size: 13px; color: #888; }
            
            .empty-contacts {
                text-align: center; padding: 40px 20px; color: #777;
            }

            /* Badge */
            .nav-badge {
                position: absolute; top: 2px; right: 2px;
                width: 10px; height: 10px; background: #ff4d4d;
                border-radius: 50%; border: 1px solid #0c0f14;
            }
            footer button { 
                position: relative; 
                background: none; border: none; 
                padding: 10px; 
                cursor: pointer;
                transition: color 0.3s;
            }

            /* Online Status Dot */
            .status-dot {
                width: 10px; height: 10px; background: #00ff82; border-radius: 50%;
                position: absolute; bottom: 0; right: 0; border: 2px solid #0c0f14;
            }
        `}</style>

        {/* HEADER */}
        <header className={`flex items-center justify-between p-[16px_32px] fixed w-full z-10 border-b border-white/10 top-0 h-[80px] ${isSelectionMode ? 'selection-active' : 'bg-[#0c0f14]'}`}>
            
            {isSelectionMode ? (
                <>
                    <button 
                        onClick={cancelSelectionMode}
                        className="bg-none border-none text-white text-lg cursor-pointer hover:text-[#00c2ff]"
                    >
                        <i className="fa-solid fa-xmark"></i>
                    </button>
                    
                    <span className="text-lg font-bold">{selectedIds.length} selecionada(s)</span>

                    <button 
                        onClick={deleteSelected}
                        disabled={selectedIds.length === 0}
                        className={`bg-none border-none text-lg cursor-pointer transition-colors ${selectedIds.length > 0 ? 'text-[#ff4d4d] hover:text-red-400' : 'text-gray-600'}`}
                    >
                        <i className="fa-solid fa-trash"></i>
                    </button>
                </>
            ) : (
                <>
                    <div className="relative">
                        <button 
                            ref={buttonRef}
                            onClick={() => setIsMenuOpen(!isMenuOpen)}
                            className="bg-none border-none text-[#00c2ff] text-lg cursor-pointer hover:text-white"
                        >
                            <i className="fa-solid fa-ellipsis-vertical"></i>
                        </button>
                        
                        {isMenuOpen && (
                            <div ref={menuRef} className="msg-dropdown">
                                <button onClick={startSelectionMode}>
                                    <i className="fa-solid fa-check-double"></i> Selecionar conversas
                                </button>
                                <button onClick={() => { setIsMenuOpen(false); alert('Configurações de mensagens (Em breve)'); }}>
                                    <i className="fa-solid fa-gear"></i> Configurações
                                </button>
                            </div>
                        )}
                    </div>

                    {/* Logo - Matched to Login Page Style */}
                    <div 
                        className="absolute left-1/2 -translate-x-1/2 w-[60px] h-[60px] bg-white/5 rounded-2xl flex justify-center items-center z-20 cursor-pointer shadow-[0_0_20px_rgba(0,194,255,0.3),inset_0_0_20px_rgba(0,194,255,0.08)]"
                        onClick={() => navigate('/feed')}
                    >
                        <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] rotate-[25deg]"></div>
                        <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] -rotate-[25deg]"></div>
                    </div>

                    <button 
                        onClick={() => navigate('/groups')}
                        className="bg-none border-none text-[#00c2ff] text-lg cursor-pointer hover:text-white"
                    >
                        <i className="fa-solid fa-users"></i>
                    </button>
                </>
            )}
        </header>

        {/* MAIN CONTENT */}
        <main className="flex-grow flex flex-col items-start justify-start w-full transition-all pt-[80px] pb-[100px]">
            <div className="w-full">
                {contacts.length > 0 ? contacts.map(contact => (
                    <div 
                        key={contact.id} 
                        className={`flex items-center p-3 border-b border-white/5 cursor-pointer transition-colors ${isSelectionMode && selectedIds.includes(contact.id) ? 'bg-[#00c2ff]/10' : 'hover:bg-[#00c2ff]/10'}`}
                        onClick={() => handleContactClick(contact.id)}
                    >
                        {isSelectionMode && (
                            <div className={`select-checkbox ${selectedIds.includes(contact.id) ? 'selected' : ''}`}></div>
                        )}

                        {/* Avatar */}
                        <div className="relative w-[50px] h-[50px] mr-[15px] flex-shrink-0">
                            {contact.avatar ? (
                                <img src={contact.avatar} alt={contact.name} className="w-full h-full rounded-full object-cover border-2 border-[#00c2ff]" />
                            ) : (
                                <div className="w-full h-full rounded-full border-2 border-[#00c2ff] bg-[linear-gradient(45deg,_#00c2ff,_#007bff)] flex items-center justify-center text-2xl text-white">
                                    <i className="fa-solid fa-user"></i>
                                </div>
                            )}
                            {/* Online Indicator */}
                            {contact.isOnline && <div className="status-dot"></div>}
                        </div>

                        {/* Info */}
                        <div className="flex flex-col flex-grow min-w-0 mr-2.5">
                            <div className="font-semibold text-base mb-0.5 whitespace-nowrap overflow-hidden text-ellipsis">
                                {contact.name}
                            </div>
                            <div className="text-sm text-[#aaa] whitespace-nowrap overflow-hidden text-ellipsis">
                                {contact.lastMessage}
                            </div>
                        </div>

                        {/* Time */}
                        <div className="flex flex-col items-end flex-shrink-0">
                             <div className="text-xs text-[#777] mt-0.5">{contact.time}</div>
                        </div>
                    </div>
                )) : (
                    <div className="text-center text-gray-500 mt-10">
                        <i className="fa-regular fa-comment-dots text-4xl mb-2"></i>
                        <p>Nenhuma mensagem ainda.</p>
                        <p style={{fontSize: '12px', marginTop: '5px'}}>Inicie uma nova conversa no botão abaixo.</p>
                    </div>
                )}
            </div>
        </main>

        {/* FAB (Only visible if NOT in selection mode) */}
        {!isSelectionMode && (
             <button 
                onClick={() => setIsNewChatOpen(true)}
                className={`fixed bottom-[80px] right-[20px] w-[60px] h-[60px] bg-[#00c2ff] border-none rounded-full text-white text-[28px] cursor-pointer shadow-[0_4px_12px_rgba(0,194,255,0.3)] z-15 flex items-center justify-center hover:bg-[#007bff] transition-transform duration-300 ${uiVisible ? 'scale-100' : 'scale-0'}`}
            >
                <i className="fa-solid fa-user-plus"></i>
            </button>
        )}

        {/* FOOTER (Only visible if NOT in selection mode) */}
        <footer className={`fixed bottom-0 left-0 w-full bg-[#0c0f14] flex justify-around py-3.5 rounded-t-2xl z-20 shadow-[0_-2px_10px_rgba(0,0,0,0.5)] transition-transform duration-300 ${uiVisible && !isSelectionMode ? 'translate-y-0' : 'translate-y-full'}`}>
            <button onClick={() => navigate('/feed')} className="text-[#00c2ff] text-[22px] cursor-pointer p-2 transition-all hover:text-white">
                <i className="fa-solid fa-newspaper"></i>
            </button>
            <button className="text-white text-[22px] cursor-pointer p-2 transition-all">
                <i className="fa-solid fa-comments"></i>
                {unreadMsgs > 0 && <div className="nav-badge"></div>}
            </button>
            <button onClick={() => navigate('/notifications')} className="text-[#00c2ff] text-[22px] cursor-pointer p-2 transition-all hover:text-white">
                <i className="fa-solid fa-bell"></i>
                {unreadNotifs > 0 && <div className="nav-badge"></div>}
            </button>
            <button onClick={() => navigate('/profile')} className="text-[#00c2ff] text-[22px] cursor-pointer p-2 transition-all hover:text-white">
                <i className="fa-solid fa-user"></i>
            </button>
        </footer>

        {/* NEW CHAT OVERLAY */}
        {isNewChatOpen && (
            <div className="new-chat-overlay">
                <div className="nc-header">
                    <button className="nc-back-btn" onClick={() => setIsNewChatOpen(false)}>
                        <i className="fa-solid fa-arrow-left"></i>
                    </button>
                    <div className="nc-title">Nova Conversa</div>
                </div>
                
                <div className="nc-search">
                    <input 
                        type="text" 
                        placeholder="Pesquisar contatos (Mútuos)..." 
                        value={newChatSearch}
                        onChange={(e) => setNewChatSearch(e.target.value)}
                        autoFocus
                    />
                </div>

                {/* GLOBAL SEARCH ENTRY POINT */}
                <button className="global-find-btn" onClick={() => navigate('/global-search')}>
                    <i className="fa-solid fa-globe"></i> Encontrar novas pessoas
                </button>

                <div className="nc-list">
                    {filteredMutuals.length > 0 ? (
                        filteredMutuals.map(friend => (
                            <div key={friend.id} className="nc-item" onClick={() => handleStartNewChat(friend.id)}>
                                {friend.avatar ? (
                                    <img src={friend.avatar} alt={friend.name} className="nc-avatar" />
                                ) : (
                                    <div className="nc-avatar">
                                        <i className="fa-solid fa-user"></i>
                                    </div>
                                )}
                                <div className="nc-info">
                                    <span className="nc-name">{friend.name}</span>
                                    <span className="nc-username">@{friend.username}</span>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="empty-contacts">
                            <p>Nenhum contato mútuo encontrado.</p>
                            <p style={{fontSize:'12px', marginTop:'5px'}}>Siga pessoas que te seguem para iniciar uma conversa.</p>
                        </div>
                    )}
                </div>
            </div>
        )}
    </div>
  );
};
