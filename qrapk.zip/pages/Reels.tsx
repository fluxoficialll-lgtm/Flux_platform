
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { reelsService } from '../services/reelsService';
import { postService } from '../services/postService';
import { authService } from '../services/authService';
import { recommendationService } from '../services/recommendationService'; // Import Recommendation
import { notificationService } from '../services/notificationService';
import { chatService } from '../services/chatService';
import { Post, Comment } from '../types';
import { db } from '@/database';

export const Reels: React.FC = () => {
  const navigate = useNavigate();
  const containerRef = useRef<HTMLDivElement>(null);
  
  // State
  const [reels, setReels] = useState<Post[]>([]);
  const [expandedReels, setExpandedReels] = useState<Set<string>>(new Set());

  // Comments Modal State
  const [isCommentModalOpen, setIsCommentModalOpen] = useState(false);
  const [activeReelId, setActiveReelId] = useState<string | null>(null);
  const [currentComments, setCurrentComments] = useState<Comment[]>([]);
  const [commentText, setCommentText] = useState('');
  const [replyingTo, setReplyingTo] = useState<{ id: string, username: string } | null>(null);

  // Notification Badges
  const [unreadNotifs, setUnreadNotifs] = useState(0);
  const [unreadMsgs, setUnreadMsgs] = useState(0);

  // --- ALGORITHM SIGNALS ---
  const viewedReels = useRef<Set<string>>(new Set());
  const startTimeRef = useRef<number>(0); // Track start time of current reel
  const currentReelRef = useRef<string | null>(null); // Track ID of currently playing

  // Load Reels
  useEffect(() => {
    const userEmail = authService.getCurrentUserEmail();
    // Check 18+ setting
    const allowAdult = localStorage.getItem('settings_18_plus') === 'true';
    
    const videoPosts = reelsService.getReels(userEmail || undefined, allowAdult);
    setReels(videoPosts);
  }, []);

  // Notification Badges
  useEffect(() => {
      const updateCounts = () => {
          setUnreadNotifs(notificationService.getUnreadCount());
          setUnreadMsgs(chatService.getUnreadCount());
      };
      updateCounts();
      const unsubNotif = db.subscribe('notifications', updateCounts);
      const unsubChat = db.subscribe('chats', updateCounts);
      return () => { unsubNotif(); unsubChat(); };
  }, []);

  // Report Watch Time Logic
  const reportWatchTime = (reelId: string | null) => {
      const userEmail = authService.getCurrentUserEmail();
      if (!reelId || !startTimeRef.current || !userEmail) return;

      const duration = (Date.now() - startTimeRef.current) / 1000; // seconds
      
      // Send signal to algorithm
      const reel = reels.find(r => r.id === reelId);
      if (reel) {
          recommendationService.recordInteraction(userEmail, reel, 'view_time', duration);
          // console.log(`[Algo] Watch Time Recorded: ${duration.toFixed(1)}s for ${reel.username}`);
      }
      
      startTimeRef.current = 0;
  };

  // Scroll & Autoplay & View Count Logic
  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleScroll = () => {
      playVisibleReel();
    };

    const playVisibleReel = () => {
      const videos = container.querySelectorAll("video");
      const currentUserEmail = authService.getCurrentUserEmail();

      videos.forEach((v: HTMLVideoElement) => {
        const rect = v.getBoundingClientRect();
        const reelId = v.getAttribute('data-reel-id');

        // Check if video is fully visible
        if (rect.top >= -150 && rect.bottom <= window.innerHeight + 150) {
          if (v.paused) {
             // START PLAYING
             const playPromise = v.play();
             if (playPromise !== undefined) {
                playPromise.then(() => {
                    // 1. View Count Logic
                    if (reelId && !viewedReels.current.has(reelId)) {
                        viewedReels.current.add(reelId);
                        if(currentUserEmail) reelsService.incrementView(reelId, currentUserEmail);
                        else reelsService.incrementView(reelId);
                        
                        setReels(prev => prev.map(r => {
                            if (r.id === reelId) return { ...r, views: r.views + 1 };
                            return r;
                        }));
                    }

                    // 2. Watch Time Logic (Algorithm)
                    if (currentReelRef.current !== reelId) {
                        // Changed reel: report previous one
                        if (currentReelRef.current) reportWatchTime(currentReelRef.current);
                        
                        // Start tracking new one
                        currentReelRef.current = reelId;
                        startTimeRef.current = Date.now();
                    }

                }).catch(error => {});
             }
          }
        } else {
          if (!v.paused) {
             v.pause();
          }
        }
      });
    };

    container.addEventListener("scroll", handleScroll);
    setTimeout(playVisibleReel, 500);

    return () => {
        container.removeEventListener("scroll", handleScroll);
        // Report final reel on unmount
        reportWatchTime(currentReelRef.current);
    };
  }, [reels]);

  // Toggle Read More
  const toggleReadMore = (id: string, e: React.MouseEvent) => {
      e.stopPropagation();
      const newSet = new Set(expandedReels);
      if (newSet.has(id)) newSet.delete(id);
      else newSet.add(id);
      setExpandedReels(newSet);
  };

  const handleLike = (id: string) => {
    const updatedPost = reelsService.toggleLike(id);
    if (updatedPost) {
        setReels(prev => prev.map(p => p.id === id ? updatedPost : p));
        
        // ALGO SIGNAL: Like
        const userEmail = authService.getCurrentUserEmail();
        if(userEmail) recommendationService.recordInteraction(userEmail, updatedPost, 'like');
    }
  };

  // --- Comments Logic (Standard) ---
  const handleCommentClick = (id: string) => {
    const post = postService.getPostById(id);
    if (post) {
        setActiveReelId(id);
        setCurrentComments(post.commentsList || []);
        setIsCommentModalOpen(true);
        setReplyingTo(null);
    }
  };

  const handleSendComment = () => {
      if (!activeReelId || !commentText.trim()) return;
      const currentUser = authService.getCurrentUser();
      const username = currentUser?.profile?.name ? `@${currentUser.profile.name}` : 'Você';
      const userAvatar = currentUser?.profile?.photoUrl;

      if (replyingTo) {
          const savedReply = postService.addReply(activeReelId, replyingTo.id, commentText.trim(), username, userAvatar);
          if (savedReply) {
              setCurrentComments(prev => prev.map(c => {
                  if (c.id === replyingTo.id) return { ...c, replies: [...(c.replies || []), savedReply] };
                  return c;
              }));
              setCommentText('');
              setReplyingTo(null);
          }
      } else {
          const newComment = postService.addComment(activeReelId, commentText.trim(), username, userAvatar);
          if (newComment) {
              setCurrentComments(prev => [newComment, ...prev]);
              setCommentText('');
              setReels(prev => prev.map(r => r.id === activeReelId ? { ...r, comments: r.comments + 1 } : r));
              
              // ALGO SIGNAL: Comment
              const post = reels.find(r => r.id === activeReelId);
              if(post && currentUser?.email) recommendationService.recordInteraction(currentUser.email, post, 'comment');
          }
      }
  };

  const handleCommentLike = (commentId: string) => {
      if (!activeReelId) return;
      const success = postService.toggleCommentLike(activeReelId, commentId);
      if (success) {
          const toggle = (list: Comment[]): Comment[] => {
              return list.map(c => {
                  if (c.id === commentId) {
                      const newLiked = !c.likedByMe;
                      return { ...c, likedByMe: newLiked, likes: (c.likes || 0) + (newLiked ? 1 : -1) };
                  }
                  if (c.replies) return { ...c, replies: toggle(c.replies) };
                  return c;
              });
          };
          setCurrentComments(prev => toggle(prev));
      }
  };

  const handleReplyClick = (comment: Comment) => {
      setReplyingTo({ id: comment.id, username: comment.username });
      document.getElementById('reelCommentInput')?.focus();
  };

  const handleUserClick = (username: string) => {
      const cleanName = username.startsWith('@') ? username.substring(1) : username;
      navigate(`/user/${cleanName}`);
  };

  const closeCommentModal = () => {
      setIsCommentModalOpen(false);
      setActiveReelId(null);
      setCommentText('');
      setReplyingTo(null);
  };

  const getDisplayName = (usernameOrHandle: string) => {
      const user = authService.getUserByHandle(usernameOrHandle);
      return user?.profile?.nickname || user?.profile?.name || usernameOrHandle;
  };

  const getUserAvatar = (usernameOrHandle: string) => {
      const user = authService.getUserByHandle(usernameOrHandle);
      return user?.profile?.photoUrl;
  }

  const renderComment = (comment: Comment, isReply = false) => {
      const displayName = getDisplayName(comment.username);
      const avatarUrl = comment.avatar || getUserAvatar(comment.username);
      return (
      <div key={comment.id} className={`comment-item ${isReply ? 'reply' : ''}`}>
          {avatarUrl ? (
              <img src={avatarUrl} className="comment-avatar" alt={displayName} onClick={() => handleUserClick(comment.username)} />
          ) : (
              <div className="comment-avatar-placeholder" onClick={() => handleUserClick(comment.username)}><i className="fa-solid fa-user"></i></div>
          )}
          <div className="comment-content">
              <div className="comment-user" onClick={() => handleUserClick(comment.username)}>{displayName}</div>
              <div className="comment-text">{comment.text}</div>
              <div className="comment-footer">
                  <button className={`action-link ${comment.likedByMe ? 'liked' : ''}`} onClick={() => handleCommentLike(comment.id)}>
                      {comment.likedByMe ? <i className="fa-solid fa-heart"></i> : <i className="fa-regular fa-heart"></i>}
                      {comment.likes && comment.likes > 0 && <span style={{marginLeft:'2px'}}>{comment.likes}</span>}
                  </button>
                  {!isReply && <button className="action-link" onClick={() => handleReplyClick(comment)}>Responder</button>}
              </div>
              {comment.replies && comment.replies.length > 0 && (
                  <div className="replies-list">{comment.replies.map(reply => renderComment(reply, true))}</div>
              )}
          </div>
      </div>
      );
  };

  return (
    <div className="bg-black text-white h-screen overflow-hidden font-['Inter']">
      <style>{`
        #searchIcon { position: fixed; top: 40px; right: 16px; z-index: 20; font-size: 20px; color: #fff; padding: 8px; background: rgba(0,0,0,0.4); border-radius: 50%; backdrop-filter: blur(10px); cursor: pointer; width: 44px; height: 44px; display: flex; align-items: center; justify-content: center; }
        #viewButtons { position:fixed; top:40px; left:50%; transform:translateX(-50%); display:flex; gap:20px; z-index:20; background:rgba(0,0,0,0.2); padding:8px 16px; border-radius:12px; backdrop-filter:blur(10px); }
        #viewButtons button { background:transparent; border:1px solid rgba(255,255,255,0.4); color:#fff; padding:6px 16px; border-radius:8px; cursor:pointer; font-size:16px; }
        #viewButtons button.active { background:rgba(255,255,255,0.2); color:#00c2ff; border-color: #00c2ff; }
        #reelsContent { width:100%; height:100vh; overflow-y:auto; scroll-snap-type:y mandatory; padding-bottom:80px; scrollbar-width: none; }
        #reelsContent::-webkit-scrollbar { display: none; }
        .reel { position:relative; width:100%; height:100vh; scroll-snap-align:start; display:flex; justify-content:center; align-items:center; background:#111; }
        .reel video { width:100%; height:100%; object-fit:cover; }
        @media (min-width: 768px) { .reel video { width: auto; aspect-ratio: 9/16; } }
        .reel-actions { position:absolute; right:16px; bottom:120px; display:flex; flex-direction:column; gap:20px; z-index:10; }
        .reel-actions button { background: rgba(0,0,0,0.2); border: none; color: #fff; font-size: 28px; padding: 12px; border-radius: 50%; cursor: pointer; display: flex; align-items: center; justify-content: center; position: relative; width: 50px; height: 50px; }
        .reel-actions button span { position:absolute; top:-8px; right:-8px; background:#00c2ff; color:#000; font-size:10px; padding:2px 6px; border-radius:12px; font-weight:bold; min-width: 20px; }
        .liked-heart { color: #ff4d4d !important; }
        .reel-desc-overlay { position: absolute; bottom: 100px; left: 20px; z-index: 10; max-width: 70%; text-shadow: 0 1px 2px rgba(0,0,0,0.8); }
        .reel-username { font-weight: 700; margin-bottom: 5px; font-size: 16px; cursor: pointer; display: flex; align-items: center; gap: 8px; }
        .reel-user-avatar { width: 30px; height: 30px; border-radius: 50%; border: 2px solid #fff; object-fit: cover; }
        .reel-title { font-size: 15px; margin-bottom: 4px; color: #fff; line-height: 1.3; }
        .reel-read-more { color: #00c2ff; font-weight: 600; cursor: pointer; margin-left: 5px; font-size: 14px; }
        
        /* Adult Badge */
        .adult-badge {
            background: #ff4d4d; color: #fff; font-size: 10px; font-weight: bold;
            padding: 2px 6px; border-radius: 4px; margin-left: 10px; border: 1px solid #fff;
        }

        /* Comments Styles */
        .comments-modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); z-index: 40; backdrop-filter: blur(3px); opacity: 0; visibility: hidden; transition: opacity 0.3s; }
        .comments-modal-overlay.open { opacity: 1; visibility: visible; }
        .comments-sheet { position: fixed; bottom: 0; left: 0; width: 100%; height: 70vh; background: #121212; border-radius: 20px 20px 0 0; z-index: 50; box-shadow: 0 -5px 20px rgba(0,0,0,0.5); transform: translateY(100%); transition: transform 0.3s ease-out; display: flex; flex-direction: column; border-top: 1px solid rgba(255,255,255,0.1); }
        .comments-sheet.open { transform: translateY(0); }
        .sheet-header { padding: 15px 20px; border-bottom: 1px solid rgba(255,255,255,0.1); display: flex; justify-content: space-between; align-items: center; }
        .comments-list { flex: 1; overflow-y: auto; padding: 15px; }
        .comment-item { margin-bottom: 15px; border-bottom: 1px solid rgba(255,255,255,0.05); padding-bottom: 10px; display: flex; align-items: flex-start; gap: 12px; }
        .comment-item.reply { margin-top: 10px; border-left: 2px solid #333; padding-left: 10px; margin-bottom: 0; border-bottom: none; }
        .comment-avatar { width: 32px; height: 32px; border-radius: 50%; object-fit: cover; border: 1px solid #00c2ff; flex-shrink: 0; }
        .comment-avatar-placeholder { width: 32px; height: 32px; border-radius: 50%; background: #333; border: 1px solid #00c2ff; display: flex; align-items: center; justify-content: center; color: #aaa; flex-shrink: 0; font-size: 12px; }
        .comment-content { display: flex; flex-direction: column; flex-grow: 1; }
        .comment-user { font-weight: 700; color: #fff; font-size: 13px; margin-bottom: 2px; }
        .comment-text { color: #ddd; font-size: 14px; line-height: 1.4; }
        .comment-footer { display: flex; align-items: center; gap: 12px; margin-top: 4px; }
        .action-link { background: none; border: none; color: #888; cursor: pointer; display: flex; align-items: center; gap: 4px; padding: 0; font-size: 11px; font-weight: 600; }
        .action-link.liked { color: #ff4d4d; }
        .comment-input-wrapper { padding: 10px 15px 20px 15px; border-top: 1px solid rgba(255,255,255,0.1); background: #1a1a1a; display: flex; flex-direction: column; gap: 5px; }
        .input-row { display: flex; gap: 10px; align-items: center; }
        .comment-input-wrapper input { flex: 1; background: #333; border: none; border-radius: 20px; padding: 10px 15px; color: #fff; font-size: 14px; outline: none; }
        .send-comment-btn { background: #00c2ff; color: #000; border: none; border-radius: 50%; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
        .replying-to { font-size: 12px; color: #aaa; display: flex; justify-content: space-between; padding: 0 10px; }
        
        footer { position:fixed; bottom:0; left:0; width:100%; background:#000; display:flex; justify-content:space-around; padding:14px 0; z-index:20; border-top: 1px solid rgba(255,255,255,0.1); }
        footer button { background:none; border:none; color:#fff; font-size:24px; cursor:pointer; transition:0.3s; position: relative; padding: 5px; }
        footer button:hover { color:#00c2ff; }
        .nav-badge { position: absolute; top: 2px; right: 2px; width: 10px; height: 10px; background: #ff4d4d; border-radius: 50%; border: 1px solid #000; }
      `}</style>

      <div id="searchIcon" onClick={() => navigate('/reels-search')}>
        <i className="fa-solid fa-magnifying-glass"></i>
      </div>

      <div id="viewButtons">
        <button onClick={() => navigate('/feed')}>Feed</button>
        <button className="active">Reels</button>
      </div>

      <div id="reelsContent" ref={containerRef}>
        {reels.map((reel) => {
            const displayName = getDisplayName(reel.username);
            const avatar = getUserAvatar(reel.username);
            return (
                <div key={reel.id} className="reel">
                    <video 
                        data-reel-id={reel.id}
                        src={reel.video} 
                        loop 
                        muted={false} 
                        playsInline 
                        onClick={(e) => e.currentTarget.paused ? e.currentTarget.play() : e.currentTarget.pause()}
                    />
                    
                    <div className="reel-actions">
                        <button onClick={() => handleLike(reel.id)}>
                            <i className={`fa-solid fa-heart ${reel.liked ? 'liked-heart' : ''}`}></i>
                            <span>{reel.likes}</span>
                        </button>
                        <button onClick={() => handleCommentClick(reel.id)}>
                            <i className="fa-solid fa-comment-dots"></i>
                            <span>{reel.comments}</span>
                        </button>
                        <button onClick={() => {
                            if (navigator.share) navigator.share({ title: 'Confira este Reel!', url: window.location.href });
                            else alert("Link copiado!");
                        }}>
                            <i className="fa-solid fa-share"></i>
                        </button>
                    </div>

                    <div className="reel-desc-overlay">
                        <div className="reel-username" onClick={() => handleUserClick(reel.username)}>
                            {avatar ? <img src={avatar} className="reel-user-avatar" /> : <i className="fa-solid fa-circle-user" style={{fontSize:'30px'}}></i>}
                            {displayName}
                            {reel.isAdultContent && <span className="adult-badge">18+</span>}
                        </div>
                        {reel.title && <div style={{fontWeight:'bold', marginBottom:'5px'}}>{reel.title}</div>}
                        <div className="reel-title">
                            {expandedReels.has(reel.id) ? reel.text : (
                                <>{reel.text.slice(0, 60)}{reel.text.length > 60 && <span className="reel-read-more" onClick={(e) => toggleReadMore(reel.id, e)}>mais</span>}</>
                            )}
                        </div>
                        <div style={{fontSize:'12px', color:'#aaa', marginTop:'5px', display:'flex', alignItems:'center', gap:'4px'}}>
                             <i className="fa-solid fa-play"></i> {reel.views} visualizações
                        </div>
                    </div>
                </div>
            );
        })}
        {reels.length === 0 && <div className="flex items-center justify-center h-full"><p className="text-gray-500">Nenhum reel disponível.</p></div>}
      </div>

      {/* Comments Sheet */}
      <div className={`comments-modal-overlay ${isCommentModalOpen ? 'open' : ''}`} onClick={closeCommentModal}></div>
      <div className={`comments-sheet ${isCommentModalOpen ? 'open' : ''}`}>
          <div className="sheet-header">
              <h3>Comentários</h3>
              <button className="close-sheet-btn" style={{background:'none', border:'none', color:'#fff', fontSize:'20px'}} onClick={closeCommentModal}>&times;</button>
          </div>
          <div className="comments-list">
              {currentComments.length > 0 ? currentComments.map(c => renderComment(c)) : <div style={{textAlign:'center', color:'#666', marginTop:'40px'}}>Seja o primeiro a comentar!</div>}
          </div>
          <div className="comment-input-wrapper">
              {replyingTo && (
                  <div className="replying-to">
                      <span>Respondendo a {replyingTo.username}</span>
                      <button onClick={() => setReplyingTo(null)} style={{background:'none',border:'none',color:'#ff4d4d'}}>Cancelar</button>
                  </div>
              )}
              <div className="input-row">
                  <input id="reelCommentInput" type="text" placeholder={replyingTo ? "Sua resposta..." : "Adicione um comentário..."} value={commentText} onChange={(e) => setCommentText(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && handleSendComment()} />
                  <button className="send-comment-btn" onClick={handleSendComment}><i className="fa-solid fa-paper-plane"></i></button>
              </div>
          </div>
      </div>

      <footer>
        <button onClick={() => navigate('/feed')}><i className="fa-solid fa-newspaper"></i></button>
        <button onClick={() => navigate('/messages')}><i className="fa-solid fa-comments"></i>{unreadMsgs > 0 && <div className="nav-badge"></div>}</button>
        <button onClick={() => navigate('/notifications')}><i className="fa-solid fa-bell"></i>{unreadNotifs > 0 && <div className="nav-badge"></div>}</button>
        <button onClick={() => navigate('/profile')}><i className="fa-solid fa-user"></i></button>
      </footer>
    </div>
  );
};
