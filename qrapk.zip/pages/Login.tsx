
import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { authService } from '../services/authService';
import { db } from '@/database'; // Import DB for maintenance injection

export const Login: React.FC = () => {
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const result = await authService.login(email, password);
      navigate(result.nextStep);
    } catch (err: any) {
      setError(err.message || 'Ocorreu um erro');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setError('');
    setLoading(true);
    try {
      const result = await authService.loginWithGoogle();
      navigate(result.nextStep);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleMaintenanceLogin = async () => {
      setLoading(true);
      try {
          const maintenanceEmail = 'admin@maintenance.com';
          
          // Check if maintenance user exists, if not create one to avoid crashes
          if (!db.users.exists(maintenanceEmail)) {
              const maintenanceUser = {
                  email: maintenanceEmail,
                  password: '123',
                  isVerified: true,
                  isProfileCompleted: true,
                  profile: {
                      name: 'admin_maintenance',
                      bio: 'Conta de Manutenção do Sistema',
                      photoUrl: 'https://cdn-icons-png.flaticon.com/512/906/906343.png',
                      isPrivate: true
                  }
              };
              db.users.set(maintenanceUser);
          }

          // Force session set
          db.auth.setCurrentUserEmail(maintenanceEmail);
          
          // Slight delay for UX
          setTimeout(() => {
              navigate('/feed');
          }, 500);
      } catch (e) {
          setError("Erro ao acessar modo manutenção");
          setLoading(false);
      }
  };

  return (
    <div 
      className="min-h-screen flex flex-col items-center justify-center p-5 text-white font-['Inter'] overflow-x-hidden"
      style={{ background: 'radial-gradient(circle at top left, #0c0f14, #0a0c10)' }}
    >
      
      {/* Logo */}
      <div className="relative w-[70px] h-[70px] bg-white/5 rounded-2xl flex items-center justify-center mb-[30px] transition-transform duration-500 shadow-[0_0_20px_rgba(0,194,255,0.3),inset_0_0_20px_rgba(0,194,255,0.08)] hover:shadow-[0_0_30px_rgba(0,194,255,0.6),inset_0_0_30px_rgba(0,194,255,0.1)]">
         <div className="absolute w-[45px] h-[24px] rounded-[50%] border-[3px] border-[#00c2ff] rotate-[25deg]"></div>
         <div className="absolute w-[45px] h-[24px] rounded-[50%] border-[3px] border-[#00c2ff] -rotate-[25deg]"></div>
      </div>

      {/* Container */}
      <div className="w-full max-w-[360px] bg-white/5 backdrop-blur-md rounded-[20px] p-[30px_25px] shadow-[0_10px_30px_rgba(0,0,0,0.5)] border border-white/10 text-center">
        <h1 className="text-2xl font-extrabold mb-[25px] text-white drop-shadow-[0_0_5px_rgba(0,194,255,0.5)]">
          Bem-vindo(a) de volta
        </h1>

        <form onSubmit={handleLogin}>
           <div className="relative mb-5 text-left group">
             <i className="fa-solid fa-user absolute left-[15px] top-1/2 -translate-y-1/2 text-[#00c2ff] text-lg"></i>
             <input 
               type="email" 
               value={email}
               onChange={(e) => setEmail(e.target.value)}
               placeholder="Email"
               required
               className="w-full p-[12px_12px_12px_40px] bg-white/10 border border-[#00c2ff] rounded-[10px] text-white text-base focus:bg-[rgba(0,194,255,0.1)] focus:shadow-[0_0_8px_rgba(0,194,255,0.8)] outline-none transition-all placeholder-gray-400"
             />
           </div>

           <div className="relative mb-5 text-left group">
             <i className="fa-solid fa-lock absolute left-[15px] top-1/2 -translate-y-1/2 text-[#00c2ff] text-lg"></i>
             <input 
               type="password" 
               value={password}
               onChange={(e) => setPassword(e.target.value)}
               placeholder="Senha"
               required
               className="w-full p-[12px_12px_12px_40px] bg-white/10 border border-[#00c2ff] rounded-[10px] text-white text-base focus:bg-[rgba(0,194,255,0.1)] focus:shadow-[0_0_8px_rgba(0,194,255,0.8)] outline-none transition-all placeholder-gray-400"
             />
           </div>

           {error && (
            <div className="mb-4 p-2 bg-red-500/20 border border-red-500/50 rounded text-red-200 text-sm font-medium">
                {error}
            </div>
           )}

           <button 
             type="submit"
             disabled={loading}
             className="w-full p-[14px] bg-[#00c2ff] border-none rounded-[10px] text-black text-lg font-semibold cursor-pointer transition-all shadow-[0_4px_10px_rgba(0,194,255,0.4)] hover:bg-[#0099cc] hover:shadow-[0_6px_15px_rgba(0,194,255,0.6)] active:translate-y-[1px] active:shadow-none disabled:opacity-70 disabled:cursor-not-allowed mb-[15px]"
           >
             {loading ? (
                <i className="fa-solid fa-circle-notch fa-spin"></i>
             ) : 'Entrar'}
           </button>
        </form>

        <div className="flex items-center text-center text-white/50 mt-5 mb-0 before:flex-1 before:border-b before:border-white/10 before:mr-2 after:flex-1 after:border-b after:border-white/10 after:ml-2">
            OU
        </div>

        <button 
            type="button"
            onClick={handleGoogleLogin} 
            disabled={loading}
            className="w-full p-[14px] bg-white border-none rounded-[10px] text-black text-lg font-semibold cursor-pointer transition-all shadow-[0_4px_10px_rgba(0,0,0,0.2)] flex items-center justify-center gap-[10px] mt-[15px] mb-[25px] hover:bg-[#f0f0f0] hover:shadow-[0_6px_15px_rgba(0,0,0,0.3)] active:translate-y-[1px] active:shadow-none disabled:opacity-70 disabled:cursor-not-allowed"
        >
           <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path
                d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                fill="#4285F4"
              />
              <path
                d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                fill="#34A853"
              />
              <path
                d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.66.81-.18z"
                fill="#FBBC05"
              />
              <path
                d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                fill="#EA4335"
              />
           </svg>
           Entrar com Google
        </button>

        <div className="mt-5 text-sm flex flex-col gap-[10px]">
           <Link to="/register" className="text-[#00c2ff] no-underline hover:text-white hover:underline transition-colors">
             Não tem conta? <span className="text-white">Criar conta</span>
           </Link>
           <Link to="/forgot-password" className="text-[#00c2ff] no-underline hover:text-white hover:underline transition-colors">
             Esqueceu a senha?
           </Link>
        </div>
      </div>

      {/* Botão de Manutenção Temporário */}
      <button
        onClick={handleMaintenanceLogin}
        className="mt-10 py-2 px-4 bg-transparent border border-gray-700 text-gray-500 rounded-lg text-xs font-mono hover:bg-gray-800 hover:text-white transition-all"
      >
        🛠️ Acesso Manutenção
      </button>

      {/* Footer */}
      <footer className="pt-[20px] text-center text-xs text-white/60 w-full">
         <a href="#" className="text-[#00c2ff] mx-2 no-underline hover:underline">Política de Privacidade</a> |
         <a href="#" className="text-[#00c2ff] mx-2 no-underline hover:underline">Termos de Uso</a>
      </footer>
    </div>
  );
};
