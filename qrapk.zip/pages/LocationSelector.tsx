
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

// Mock data for manual fallback
const LOCATIONS = {
    "Brasil": {
        "Ceará": ["Fortaleza", "Eusébio", "Aquiraz", "Sobral"],
        "São Paulo": ["São Paulo", "Campinas", "Santos", "Guarulhos"],
        "Rio de Janeiro": ["Rio de Janeiro", "Niterói", "Cabo Frio"],
        "Minas Gerais": ["Belo Horizonte", "Uberlândia", "Ouro Preto"]
    },
    "Estados Unidos": {
        "California": ["Los Angeles", "San Francisco", "San Diego"],
        "New York": ["New York City", "Buffalo"],
        "Florida": ["Miami", "Orlando"]
    },
    "Portugal": {
        "Lisboa": ["Lisboa", "Sintra", "Cascais"],
        "Porto": ["Porto", "Vila Nova de Gaia"]
    }
};

interface DetectedLocation {
    city: string;
    region: string; // Estado
    country_name: string;
    ip: string;
}

export const LocationSelector: React.FC = () => {
  const navigate = useNavigate();
  
  // Manual Selection States
  const [selectedCountry, setSelectedCountry] = useState('');
  const [selectedState, setSelectedState] = useState('');
  const [selectedCity, setSelectedCity] = useState('');
  
  // Auto Detection States
  const [isLoadingIP, setIsLoadingIP] = useState(false);
  const [detectedLocation, setDetectedLocation] = useState<DetectedLocation | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Handlers Manual
  const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      setSelectedCountry(e.target.value);
      setSelectedState('');
      setSelectedCity('');
  };

  const handleStateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      setSelectedState(e.target.value);
      setSelectedCity('');
  };

  const applyManualFilter = () => {
      let filter = '';
      if (selectedCity) filter = selectedCity;
      else if (selectedState) filter = selectedState;
      else if (selectedCountry) filter = selectedCountry;

      if (filter) {
          localStorage.setItem('feed_location_filter', filter);
      } else {
          localStorage.removeItem('feed_location_filter');
      }
      navigate('/feed');
  };

  const clearFilter = () => {
      localStorage.removeItem('feed_location_filter');
      navigate('/feed');
  };

  // --- LÓGICA DE DETECÇÃO DE IP ROBUSTA ---
  const detectLocation = async () => {
      setIsLoadingIP(true);
      setErrorMsg('');
      setDetectedLocation(null);

      try {
          let data;
          
          // 1. Tenta API Principal (ipapi.co)
          try {
              const response = await fetch('https://ipapi.co/json/');
              if (!response.ok) throw new Error('Network response was not ok');
              data = await response.json();
              if (data.error) throw new Error('API Error');
          } catch (e) {
              console.warn("ipapi.co falhou ou bloqueado, tentando fallback ipwho.is...");
              
              // 2. Tenta API Fallback (ipwho.is) - Ótima para evitar erros de CORS/AdBlock
              const response = await fetch('https://ipwho.is/');
              if (!response.ok) throw new Error('Backup API failed');
              const fallbackData = await response.json();
              
              if (!fallbackData.success) throw new Error('GeoIP lookup failed');

              // Normaliza para o formato padrão
              data = {
                  city: fallbackData.city,
                  region: fallbackData.region,
                  country_name: fallbackData.country,
                  ip: fallbackData.ip
              };
          }

          if (!data || !data.country_name) {
              throw new Error("Dados de localização incompletos.");
          }

          setDetectedLocation({
              city: data.city,
              region: data.region, 
              country_name: data.country_name,
              ip: data.ip
          });

      } catch (error) {
          console.error("Erro na detecção:", error);
          setErrorMsg("Não foi possível detectar sua localização automaticamente. Por favor, use a seleção manual abaixo.");
      } finally {
          setIsLoadingIP(false);
      }
  };

  const selectDetectedLevel = (level: 'city' | 'region' | 'country') => {
      if (!detectedLocation) return;

      let filterValue = '';
      
      switch (level) {
          case 'city':
              filterValue = detectedLocation.city;
              break;
          case 'region':
              filterValue = detectedLocation.region;
              break;
          case 'country':
              filterValue = detectedLocation.country_name;
              break;
      }

      localStorage.setItem('feed_location_filter', filterValue);
      navigate('/feed');
  };

  // Derived lists for manual
  const countries = Object.keys(LOCATIONS);
  // @ts-ignore
  const states = selectedCountry ? Object.keys(LOCATIONS[selectedCountry]) : [];
  // @ts-ignore
  const cities = (selectedCountry && selectedState) ? LOCATIONS[selectedCountry][selectedState] : [];

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-x-hidden">
      <style>{`
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        
        header {
            display:flex; align-items:center; padding:16px 32px;
            background: #0c0f14; position:fixed; width:100%; z-index:10;
            border-bottom:1px solid rgba(255,255,255,0.1); top: 0; height: 65px;
        }
        header button {
            background:none; border:none; color:#fff; font-size:22px; cursor:pointer;
            transition:0.3s; padding-right: 15px;
        }
        header h1 { font-size:18px; font-weight:600; color: #00c2ff; }
        
        main {
            padding-top: 90px; padding-bottom: 40px;
            width: 100%; max-width: 500px; margin: 0 auto; padding-left: 20px; padding-right: 20px;
            display: flex; flex-direction: column; gap: 25px;
        }

        .location-card {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 16px;
            padding: 24px;
            display: flex; flex-direction: column; gap: 15px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        }

        h2 { font-size: 16px; color: #fff; margin-bottom: 5px; font-weight: 600; }
        p.desc { font-size: 13px; color: #aaa; margin-bottom: 10px; line-height: 1.4; }

        .auto-location-btn {
            background: rgba(0, 194, 255, 0.1);
            border: 1px solid #00c2ff;
            color: #00c2ff;
            padding: 14px;
            border-radius: 12px;
            font-weight: 600;
            cursor: pointer;
            display: flex; align-items: center; justify-content: center; gap: 10px;
            transition: 0.3s;
        }
        .auto-location-btn:hover { background: rgba(0, 194, 255, 0.2); }
        
        /* DETECTED OPTIONS */
        .detected-options-grid {
            display: grid; grid-template-columns: 1fr; gap: 10px; margin-top: 10px;
            animation: fadeIn 0.5s ease;
        }
        
        .level-btn {
            background: #1a1e26; border: 1px solid rgba(255,255,255,0.1);
            padding: 15px; border-radius: 12px; text-align: left;
            cursor: pointer; transition: 0.3s; display: flex; align-items: center;
            justify-content: space-between;
        }
        .level-btn:hover { border-color: #00c2ff; background: rgba(0,194,255,0.05); }
        
        .level-label { font-size: 11px; color: #888; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 4px; }
        .level-value { font-size: 16px; font-weight: 700; color: #fff; }
        .level-icon { font-size: 18px; color: #00c2ff; }

        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        /* MANUAL SELECT */
        .select-group { display: flex; flex-direction: column; gap: 8px; }
        .select-group label { font-size: 13px; color: #ccc; }
        .select-group select {
            background: #111;
            border: 1px solid #333;
            color: #fff;
            padding: 12px;
            border-radius: 8px;
            outline: none;
            font-size: 15px;
        }
        .select-group select:focus { border-color: #00c2ff; }

        .apply-btn {
            background: #00c2ff; color: #000; border: none;
            padding: 15px; border-radius: 12px; font-weight: 700;
            font-size: 16px; cursor: pointer; transition: 0.3s;
            margin-top: 10px; box-shadow: 0 4px 15px rgba(0,194,255,0.3);
        }
        .apply-btn:hover { background: #0099cc; transform: translateY(-2px); }
        
        .clear-btn {
            background: transparent; color: #aaa; border: 1px solid #333;
            padding: 12px; border-radius: 12px; font-weight: 600;
            font-size: 14px; cursor: pointer; transition: 0.3s; text-align: center;
        }
        .clear-btn:hover { border-color: #fff; color: #fff; }
      `}</style>

      <header>
        <button onClick={() => navigate('/feed')} aria-label="Voltar">
            <i className="fa-solid fa-xmark"></i>
        </button>
        <h1>Explorar por Localização</h1>
      </header>

      <main>
        {/* Auto Location */}
        <div className="location-card">
            <div>
                <h2><i className="fa-solid fa-satellite-dish" style={{color:'#00c2ff', marginRight:'8px'}}></i> Detecção Automática</h2>
                <p className="desc">Identifique seu IP e escolha o nível de alcance que deseja ver.</p>
            </div>
            
            {!detectedLocation ? (
                <>
                    <button className="auto-location-btn" onClick={detectLocation} disabled={isLoadingIP}>
                        {isLoadingIP ? <i className="fa-solid fa-circle-notch fa-spin"></i> : <i className="fa-solid fa-location-crosshairs"></i>}
                        {isLoadingIP ? 'Detectando...' : 'Detectar Minha Localização'}
                    </button>
                    {errorMsg && <p style={{color:'#ff4d4d', fontSize:'12px', marginTop:'10px', textAlign:'center'}}>{errorMsg}</p>}
                </>
            ) : (
                <div className="detected-options-grid">
                    <p style={{fontSize:'14px', color:'#00ff82', marginBottom:'5px', textAlign:'center'}}>
                        <i className="fa-solid fa-check-circle"></i> Localização Identificada!
                    </p>
                    
                    {/* Opção 1: Município */}
                    <div className="level-btn" onClick={() => selectDetectedLevel('city')}>
                        <div>
                            <div className="level-label">Município</div>
                            <div className="level-value">Ver só {detectedLocation.city}</div>
                        </div>
                        <i className="fa-solid fa-city level-icon"></i>
                    </div>

                    {/* Opção 2: Estado */}
                    <div className="level-btn" onClick={() => selectDetectedLevel('region')}>
                        <div>
                            <div className="level-label">Estado / Região</div>
                            <div className="level-value">Ver todo {detectedLocation.region}</div>
                        </div>
                        <i className="fa-solid fa-map level-icon"></i>
                    </div>

                    {/* Opção 3: País */}
                    <div className="level-btn" onClick={() => selectDetectedLevel('country')}>
                        <div>
                            <div className="level-label">País</div>
                            <div className="level-value">Ver {detectedLocation.country_name} inteiro</div>
                        </div>
                        <i className="fa-solid fa-globe level-icon"></i>
                    </div>

                    <button 
                        onClick={() => setDetectedLocation(null)} 
                        style={{background:'none', border:'none', color:'#aaa', fontSize:'12px', marginTop:'10px', cursor:'pointer'}}
                    >
                        Detectar novamente
                    </button>
                </div>
            )}
        </div>

        <div style={{display: 'flex', alignItems: 'center', gap: '10px', color: '#555'}}>
            <div style={{height:'1px', background:'#333', flex:1}}></div>
            <span style={{fontSize:'12px', fontWeight:'bold'}}>OU SELECIONE MANUALMENTE</span>
            <div style={{height:'1px', background:'#333', flex:1}}></div>
        </div>

        {/* Manual Selection */}
        <div className="location-card">
            <div>
                <h2>Seleção Manual</h2>
                <p className="desc">Escolha uma região específica da lista.</p>
            </div>

            <div className="select-group">
                <label>País</label>
                <select value={selectedCountry} onChange={handleCountryChange}>
                    <option value="">Selecione o País</option>
                    {countries.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
            </div>

            <div className="select-group">
                <label>Estado</label>
                <select value={selectedState} onChange={handleStateChange} disabled={!selectedCountry}>
                    <option value="">Selecione o Estado</option>
                    {states.map((s: string) => <option key={s} value={s}>{s}</option>)}
                </select>
            </div>

            <div className="select-group">
                <label>Município</label>
                <select value={selectedCity} onChange={(e) => setSelectedCity(e.target.value)} disabled={!selectedState}>
                    <option value="">Selecione a Cidade</option>
                    {cities.map((c: string) => <option key={c} value={c}>{c}</option>)}
                </select>
            </div>

            <button className="apply-btn" onClick={applyManualFilter} disabled={!selectedCountry}>
                Aplicar Filtro
            </button>
        </div>

        <button className="clear-btn" onClick={clearFilter}>
            Ver Tudo (Sem Filtros)
        </button>

      </main>
    </div>
  );
};
