
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { chatService, ChatMessage } from '../services/chatService';
import { authService } from '../services/authService';
import { db } from '@/database';

export const Chat: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const chatId = id || '1';

  // --- ESTADOS ---
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [contactName, setContactName] = useState('');
  const [contactAvatar, setContactAvatar] = useState<string | undefined>(undefined);
  const [contactStatus, setContactStatus] = useState('Offline');
  const [isBlocked, setIsBlocked] = useState(false);

  // Pagination
  const [displayLimit, setDisplayLimit] = useState(20);
  const [totalMessages, setTotalMessages] = useState(0);

  const [inputText, setInputText] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  // Seleção de Mensagens
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);

  // Pesquisa
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Gravação de Áudio
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const recordingInterval = useRef<any>(null);

  // Reprodução de Áudio
  const [playingAudioId, setPlayingAudioId] = useState<number | null>(null);
  const audioTimeoutRef = useRef<any>(null);

  // Refs para UI
  const menuRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentUserEmail = authService.getCurrentUserEmail();

  // --- CARREGAR DADOS INICIAIS ---
  useEffect(() => {
      loadChatData();
  }, [chatId]);

  // --- REAL TIME SUBSCRIPTION ---
  useEffect(() => {
      // Listen for updates in 'chats' table
      const unsubscribeChat = db.subscribe('chats', () => {
          loadChatData(true);
      });
      // Listen for status updates
      const unsubscribeUser = db.subscribe('users', () => {
          loadChatData(true);
      });
      
      return () => { unsubscribeChat(); unsubscribeUser(); };
  }, [chatId, displayLimit]);

  const loadChatData = (isSilent = false) => {
      const chatData = chatService.getChat(chatId);
      const allMsgs = chatData.messages;
      
      setTotalMessages(allMsgs.length);
      setIsBlocked(chatData.isBlocked);

      // --- DYNAMIC HEADER RESOLUTION ---
      // Resolve who we are talking to based on the Chat ID (email1_email2)
      let targetUser = undefined;
      let displayName = chatData.contactName;
      let displayAvatar = undefined;

      if (chatId.includes('_') && chatId.includes('@') && currentUserEmail) {
          const parts = chatId.split('_');
          const otherEmail = parts.find(p => p !== currentUserEmail);
          
          if (otherEmail) {
              // Fetch the OTHER user's data
              const allUsers = db.users.getAll(); // Get raw from DB to be sure
              const userRecord = allUsers[otherEmail];
              
              if (userRecord) {
                  targetUser = userRecord;
                  displayName = userRecord.profile?.nickname || userRecord.profile?.name || otherEmail;
                  displayAvatar = userRecord.profile?.photoUrl;
              } else {
                  displayName = otherEmail; // Fallback
              }
          }
      } else {
          // Fallback for legacy chats or non-standard IDs
          targetUser = authService.getUserByHandle(chatData.contactName);
          if (targetUser) {
              displayName = targetUser.profile?.nickname || targetUser.profile?.name || chatData.contactName;
              displayAvatar = targetUser.profile?.photoUrl;
          }
      }

      setContactName(displayName);
      setContactAvatar(displayAvatar);

      // Get Status
      if (targetUser?.lastSeen) {
          const diff = Date.now() - targetUser.lastSeen;
          if (diff < 2 * 60 * 1000) {
              setContactStatus('Online');
          } else {
              const date = new Date(targetUser.lastSeen);
              const hours = date.getHours().toString().padStart(2, '0');
              const minutes = date.getMinutes().toString().padStart(2, '0');
              setContactStatus(`Visto por último às ${hours}:${minutes}`);
          }
      } else {
          setContactStatus('Offline');
      }

      // Apply pagination logic
      let visibleMsgs = allMsgs;
      if (allMsgs.length > displayLimit) {
          visibleMsgs = allMsgs.slice(allMsgs.length - displayLimit);
      }
      
      setMessages(visibleMsgs);
  };

  const handleLoadMore = () => {
      setDisplayLimit(prev => prev + 20);
      setTimeout(() => loadChatData(), 0);
  };

  // --- EFEITOS ---

  // Scroll para o fim ao chegar mensagem
  useEffect(() => {
      if (!isSearchOpen && messages.length > 0) {
          messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
      }
  }, [messages.length, isRecording, isSearchOpen]);

  // Fechar menu ao clicar fora
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        menuRef.current && 
        !menuRef.current.contains(event.target as Node) && 
        buttonRef.current && 
        !buttonRef.current.contains(event.target as Node)
      ) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Timer de gravação
  useEffect(() => {
      if (isRecording) {
          recordingInterval.current = setInterval(() => {
              setRecordingTime(prev => prev + 1);
          }, 1000);
      } else {
          clearInterval(recordingInterval.current);
          setRecordingTime(0);
      }
      return () => clearInterval(recordingInterval.current);
  }, [isRecording]);

  // --- FUNÇÕES ---

  const getCurrentUserInfo = () => {
      const user = authService.getCurrentUser();
      return {
          name: user?.profile?.nickname || user?.profile?.name || 'Você',
          avatar: user?.profile?.photoUrl,
          email: user?.email
      };
  };

  const handleSendMessage = () => {
    if (inputText.trim()) {
      const userInfo = getCurrentUserInfo();
      const newMessage: ChatMessage = {
          id: Date.now(),
          text: inputText,
          type: 'sent',
          contentType: 'text',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: 'sent',
          senderEmail: userInfo.email,
          senderAvatar: userInfo.avatar,
          senderName: userInfo.name
      };
      
      chatService.sendMessage(chatId, newMessage);
      setInputText('');
    }
  };

  const handleAttachmentClick = () => {
      fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (ev) => {
          const mediaUrl = ev.target?.result as string;
          const isVideo = file.type.startsWith('video/');
          const userInfo = getCurrentUserInfo();
          
          const newMessage: ChatMessage = {
              id: Date.now(),
              text: isVideo ? 'Vídeo' : 'Foto',
              type: 'sent',
              contentType: isVideo ? 'video' : 'image',
              mediaUrl: mediaUrl,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              status: 'sent',
              senderEmail: userInfo.email,
              senderAvatar: userInfo.avatar,
              senderName: userInfo.name
          };

          chatService.sendMessage(chatId, newMessage);
      };
      reader.readAsDataURL(file);
      if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleAudioAction = () => {
      if (inputText.length > 0) {
          handleSendMessage();
      } else {
          if (isRecording) {
              setIsRecording(false);
              const durationStr = formatTime(recordingTime);
              const userInfo = getCurrentUserInfo();
              
              const newMessage: ChatMessage = {
                  id: Date.now(),
                  text: 'Mensagem de Voz',
                  type: 'sent',
                  contentType: 'audio',
                  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                  status: 'sent',
                  duration: durationStr,
                  senderEmail: userInfo.email,
                  senderAvatar: userInfo.avatar,
                  senderName: userInfo.name
              };
              chatService.sendMessage(chatId, newMessage);
          } else {
              setIsRecording(true);
          }
      }
  };

  const cancelRecording = () => {
      setIsRecording(false);
  };

  const toggleSelectionMode = () => {
      setIsSelectionMode(!isSelectionMode);
      setSelectedIds([]);
      setIsMenuOpen(false);
      setIsSearchOpen(false); 
  };

  const toggleMessageSelection = (id: number) => {
      if (selectedIds.includes(id)) {
          setSelectedIds(selectedIds.filter(sid => sid !== id));
      } else {
          setSelectedIds([...selectedIds, id]);
      }
  };

  const deleteSelectedMessages = () => {
      if (selectedIds.length === 0) return;

      if (window.confirm(`Excluir ${selectedIds.length} mensagens?`)) {
          chatService.deleteMessages(chatId, selectedIds);
          setIsSelectionMode(false);
          setSelectedIds([]);
      }
  };

  const toggleSearchMode = () => {
      setIsSearchOpen(!isSearchOpen);
      setSearchTerm('');
      setIsMenuOpen(false);
      setIsSelectionMode(false); 
  };

  const filteredMessages = messages.filter(m => 
      m.text.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleClearChat = () => {
      if (window.confirm("Tem certeza que deseja limpar toda a conversa?")) {
          chatService.clearChat(chatId);
          setIsMenuOpen(false);
      }
  };

  const toggleBlockUser = () => {
      const action = isBlocked ? "desbloquear" : "bloquear";
      if (window.confirm(`Deseja realmente ${action} este contato?`)) {
          const newStatus = chatService.toggleBlock(chatId);
          setIsBlocked(newStatus);
          setIsMenuOpen(false);
      }
  };

  const handlePlayAudio = (id: number, durationStr?: string) => {
      if (playingAudioId === id) {
          setPlayingAudioId(null);
          if (audioTimeoutRef.current) clearTimeout(audioTimeoutRef.current);
      } else {
          setPlayingAudioId(id);
          
          let durationMs = 3000; 
          if (durationStr) {
              const parts = durationStr.split(':');
              if (parts.length === 2) {
                  const min = parseInt(parts[0]);
                  const sec = parseInt(parts[1]);
                  durationMs = (min * 60 + sec) * 1000;
              }
          }

          if (audioTimeoutRef.current) clearTimeout(audioTimeoutRef.current);
          audioTimeoutRef.current = setTimeout(() => {
              setPlayingAudioId(null);
          }, durationMs);
      }
  };

  const formatTime = (seconds: number) => {
      const mins = Math.floor(seconds / 60);
      const secs = seconds % 60;
      return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const renderStatusIcon = (status: string) => {
      if (status === 'sent') return <i className="fa-solid fa-check" style={{ color: 'rgba(255,255,255,0.6)' }}></i>; 
      if (status === 'delivered') return <i className="fa-solid fa-check-double" style={{ color: 'rgba(255,255,255,0.6)' }}></i>; 
      if (status === 'read') return <i className="fa-solid fa-check-double" style={{ color: '#00c2ff' }}></i>; 
      return null;
  };

  return (
    <div className="min-h-screen flex flex-col overflow-x-hidden" style={{ background: 'radial-gradient(circle at top left, #0c0f14, #0a0c10)', color: '#fff', fontFamily: "'Roboto', sans-serif", fontWeight: 500, textShadow: '0 0 3px rgba(0, 194, 255, 0.1)' }}>
      <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet" />
      <style>{`
        /* Estilos globais e resets */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Roboto', sans-serif; } 
        
        /* HEADER */
        header {
            display:flex; align-items:center; padding:12px 16px;
            background: #0c0f14; position:fixed; width:100%; z-index:10; 
            border-bottom:1px solid rgba(255,255,255,0.1);
            top: 0; height: 60px;
        }
        
        /* Modos do Header */
        header.selection-mode {
            background: #0a2a38; /* Fundo diferente para seleção */
            justify-content: space-between;
        }
        header.search-mode {
            background: #15191e;
        }

        /* Ícones do Header */
        header .back-button, header .selection-action {
            background:none; border:none; color:#00c2ff; font-size:18px; 
            cursor:pointer; transition:0.3s; padding: 0 10px;
            text-shadow: none; 
        }
        header .back-button:hover { color:#fff; transform:scale(1.05); }
        header .delete-btn { color: #ff4d4d; }

        /* Input de Pesquisa no Header */
        .header-search-input {
            flex-grow: 1;
            background: rgba(255,255,255,0.1);
            border: none;
            border-radius: 20px;
            padding: 8px 15px;
            color: #fff;
            margin: 0 10px;
            font-size: 14px;
            outline: none;
        }

        /* Info Chat */
        .chat-info { display: flex; align-items: center; flex-grow: 1; margin-left: 10px; }
        .chat-avatar {
            width: 36px; height: 36px; border-radius: 50%; 
            background: #00c2ff; 
            display: flex; justify-content: center; align-items: center;
            font-size: 16px; font-weight: 700; margin-right: 10px; 
            text-shadow: none; object-fit: cover; overflow: hidden;
        }
        .chat-avatar img { width: 100%; height: 100%; object-fit: cover; }
        .chat-details h2 { font-size: 16px; color: #fff; line-height: 1.2; font-weight: 700; }
        .chat-details p { font-size: 12px; color: #00c2ff; opacity: 0.8; font-weight: 500; }

        /* Dropdown */
        .options-container { position: relative; margin-left: 15px; }
        .options-container .options-button {
            background:none; border:none; color:#00c2ff; font-size:20px; 
            cursor:pointer; transition:0.3s; text-shadow: none; padding: 5px;
        }
        .dropdown-menu {
            position: absolute; top: 40px; right: 0;
            background: #1a1e26; border: 1px solid rgba(0, 194, 255, 0.2);
            border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.5);
            width: 200px; z-index: 20; display: none; overflow: hidden;
        }
        .dropdown-menu.active { display: block; }
        .dropdown-menu a {
            display: flex; align-items: center; padding: 12px 15px;
            color: #fff; text-decoration: none; font-size: 14px;
            font-weight: 500; transition: background-color 0.2s;
        }
        .dropdown-menu a:hover { background-color: #00c2ff; color: #0c0f14; }
        .dropdown-menu a i { margin-right: 10px; font-size: 16px; width: 20px; text-align: center; }

        /* Área de Mensagens */
        main { flex-grow:1; width:100%; padding: 70px 10px 90px 10px; overflow-y: auto; display: flex; flex-direction: column; }
        
        .load-more-btn {
            align-self: center; background: rgba(255,255,255,0.1); border: none;
            color: #00c2ff; padding: 8px 16px; border-radius: 20px; font-size: 12px;
            cursor: pointer; margin-bottom: 15px; transition: 0.3s;
        }
        .load-more-btn:hover { background: rgba(255,255,255,0.2); }

        .message-container { display: flex; margin-bottom: 8px; align-items: flex-end; }
        .message-container.sent { justify-content: flex-end; }
        .message-container.received { justify-content: flex-start; }
        
        /* Checkbox de Seleção */
        .select-checkbox {
            margin-right: 10px; width: 20px; height: 20px; border-radius: 50%;
            border: 2px solid #555; flex-shrink: 0; cursor: pointer;
            display: flex; align-items: center; justify-content: center;
        }
        .select-checkbox.selected { background: #00c2ff; border-color: #00c2ff; }
        .select-checkbox.selected::after { content: '✔'; font-size: 12px; color: #000; }

        /* Bolha da Mensagem */
        .message-bubble {
            max-width: 75%; padding: 8px 12px; border-radius: 12px;
            font-size: 15px; line-height: 1.4; position: relative;
            min-width: 80px; /* Espaço para hora/status */
        }
        .message-container.sent .message-bubble {
            background-color: #0088cc; color: #ffffff; 
            border-bottom-right-radius: 2px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.3); text-shadow: none;
        }
        .message-container.received .message-bubble {
            background-color: #2e3646; color: #fff; 
            border-bottom-left-radius: 2px;
        }

        /* Highlight do Search */
        .message-highlight {
            background: rgba(0, 194, 255, 0.3);
            color: #fff;
            padding: 0 2px;
            border-radius: 2px;
        }

        /* Mídia dentro da mensagem */
        .media-content {
            width: 100%; border-radius: 8px; margin-bottom: 5px;
            overflow: hidden; background: #000;
        }
        .media-content img, .media-content video {
            max-width: 240px; max-height: 300px; width: 100%; height: auto; object-fit: cover; display: block;
        }

        /* Info da Mensagem (Hora e Status) */
        .message-meta {
            display: flex; justify-content: flex-end; align-items: center;
            font-size: 10px; margin-top: 4px; gap: 4px; opacity: 0.8;
        }

        /* Áudio Bubble Atualizado */
        .audio-player { 
            display: flex; align-items: center; gap: 12px; width: 260px; 
            padding: 10px 8px; background: rgba(0,0,0,0.2); border-radius: 10px;
        }
        .audio-control { 
            width: 45px; height: 45px; background: rgba(255,255,255,0.2); 
            border-radius: 50%; display: flex; align-items: center; justify-content: center;
            cursor: pointer; transition: background 0.2s; font-size: 18px; flex-shrink: 0;
        }
        .audio-control:hover { background: rgba(255,255,255,0.3); }
        .audio-control.playing { background: #00c2ff; color: #000; }
        
        .audio-info { display: flex; flex-direction: column; flex-grow: 1; justify-content: center; }
        .audio-waveform { 
            height: 6px; background: rgba(255,255,255,0.3); border-radius: 3px; 
            width: 100%; margin-top: 6px; position: relative; overflow: hidden;
        }
        .audio-progress { height: 100%; background: #00c2ff; width: 0%; border-radius: 3px; transition: width 0.2s linear; }
        .audio-player.playing .audio-progress { width: 100%; transition: width 3s linear; }

        /* Input Area */
        .chat-input-area {
            position: fixed; bottom: 70px; width: 100%; background: #0c0f14;
            padding: 8px 10px; display: flex; align-items: center;
            border-top: 1px solid rgba(255,255,255,0.1); z-index: 15;
        }
        
        /* Bloqueado Footer */
        .blocked-footer {
            position: fixed; bottom: 70px; width: 100%; background: #1a1a1a;
            padding: 15px; text-align: center; color: #ff4d4d; font-weight: bold;
            border-top: 1px solid rgba(255,255,255,0.1); z-index: 15;
            display: flex; justify-content: center; align-items: center;
        }

        .chat-input-area button {
            background: none; border: none; color: #00c2ff; 
            font-size: 20px; cursor: pointer; padding: 8px;
            transition: all 0.3s; text-shadow: none;
        }
        .chat-input-area button:hover { color: #fff; }
        
        .chat-input-area input[type="text"] {
            flex-grow: 1; padding: 10px 15px;
            border: 2px solid rgba(0,194,255,0.2); border-radius: 25px;
            background: rgba(255,255,255,0.05); color: #fff; font-size: 16px;
            margin: 0 8px; transition: all 0.3s; text-shadow: none;
        }
        .chat-input-area input:focus { border-color: #00c2ff; outline: none; }

        /* Gravação UI */
        .recording-ui {
            flex-grow: 1; display: flex; align-items: center; padding: 0 10px; color: #ff4d4d;
        }
        .recording-dot {
            width: 10px; height: 10px; background: #ff4d4d; border-radius: 50%;
            margin-right: 10px; animation: pulse 1s infinite;
        }
        @keyframes pulse { 0% { opacity: 1; } 50% { opacity: 0.5; } 100% { opacity: 1; } }

        /* Footer Nav */
        footer.nav-footer {
            position:fixed; bottom:0; left:0; width:100%; background:#0c0f14;
            display:flex; justify-content:space-around; padding:14px 0;
            z-index:20; box-shadow:0 0 10px rgba(0,0,0,0.5);
        }
        footer.nav-footer button {
            background:none; border:none; color:#00c2ff; font-size:22px; 
            cursor:pointer; padding:8px; border-radius:10px;
        }
        footer.nav-footer button.active { color:#fff; background:rgba(0,194,255,0.3); }
      `}</style>

      {/* HEADER DINÂMICO */}
      {isSelectionMode ? (
          <header className="selection-mode">
              <div className="flex items-center">
                  <button className="selection-action" onClick={toggleSelectionMode}>
                      <i className="fa-solid fa-xmark"></i>
                  </button>
                  <span style={{ fontSize: '18px', fontWeight: 'bold', marginLeft: '10px' }}>
                      {selectedIds.length} selecionada(s)
                  </span>
              </div>
              <button className="selection-action delete-btn" onClick={deleteSelectedMessages} disabled={selectedIds.length === 0}>
                  <i className="fa-solid fa-trash"></i>
              </button>
          </header>
      ) : isSearchOpen ? (
          <header className="search-mode">
              <button className="back-button" onClick={toggleSearchMode}>
                  <i className="fa-solid fa-arrow-left"></i>
              </button>
              <input 
                autoFocus
                type="text" 
                className="header-search-input" 
                placeholder="Pesquisar na conversa..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <button className="back-button" onClick={() => setSearchTerm('')}>
                  <i className="fa-solid fa-xmark"></i>
              </button>
          </header>
      ) : (
          <header>
            <button className="back-button" onClick={() => navigate('/messages')}>
                <i className="fa-solid fa-arrow-left"></i>
            </button>
            
            <div className="chat-info" onClick={() => navigate(`/user/${contactName}`)}>
                <div className="chat-avatar">
                    {contactAvatar ? (
                        <img src={contactAvatar} alt="Avatar" />
                    ) : (
                        contactName.charAt(0) || 'C'
                    )}
                </div>
                <div className="chat-details">
                    <h2>{contactName}</h2>
                    <p>{isBlocked ? 'Bloqueado' : contactStatus}</p>
                </div>
            </div>
            
            <div className="options-container">
                <button 
                    id="optionsButton" 
                    ref={buttonRef}
                    className="options-button" 
                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                >
                    <i className="fa-solid fa-ellipsis-vertical"></i>
                </button>

                <div id="optionsMenu" ref={menuRef} className={`dropdown-menu ${isMenuOpen ? 'active' : ''}`}>
                    <a href="#" onClick={(e) => { e.preventDefault(); toggleSearchMode(); }}>
                        <i className="fa-solid fa-magnifying-glass"></i> Pesquisar
                    </a>
                    <a href="#" onClick={(e) => { e.preventDefault(); toggleSelectionMode(); }}>
                        <i className="fa-solid fa-check-double"></i> Selecionar
                    </a>
                    <a href="#" onClick={(e) => { e.preventDefault(); toggleBlockUser(); }}>
                        <i className="fa-solid fa-ban"></i> {isBlocked ? 'Desbloquear' : 'Bloquear'}
                    </a>
                    <a href="#" onClick={(e) => { e.preventDefault(); handleClearChat(); }} style={{ color: '#ff4d4d' }}>
                        <i className="fa-solid fa-trash"></i> Limpar conversa
                    </a>
                </div>
            </div>
          </header>
      )}

      {/* ÁREA DE MENSAGENS */}
      <main>
        {/* Load More Button */}
        {totalMessages > displayLimit && !searchTerm && (
            <button className="load-more-btn" onClick={handleLoadMore}>
                Carregar mensagens anteriores
            </button>
        )}

        {/* Empty State */}
        {messages.length === 0 && !searchTerm && (
            <div className="flex flex-col items-center justify-center h-full opacity-50 mt-20 animate-fade-in">
                <div className="w-24 h-24 bg-gray-800 rounded-full flex items-center justify-center mb-4 border border-gray-700 shadow-[0_0_20px_rgba(0,194,255,0.1)]">
                    <i className="fa-regular fa-comments text-4xl text-[#00c2ff]"></i>
                </div>
                <p className="text-lg font-bold text-white mb-1">Chat Limpo</p>
                <p className="text-sm text-gray-400 text-center max-w-xs">
                    Envie uma mensagem para começar a conversa.
                </p>
            </div>
        )}

        {filteredMessages.length === 0 && searchTerm && (
            <div className="text-center text-gray-500 mt-10">Nenhuma mensagem encontrada para "{searchTerm}".</div>
        )}

        {filteredMessages.map((msg) => {
            // IMPORTANT: Rely on senderEmail comparison, fallback to type if email is missing (legacy)
            const isMe = msg.senderEmail ? msg.senderEmail === currentUserEmail : msg.type === 'sent';

            return (
            <div key={msg.id} className={`message-container ${isMe ? 'sent' : 'received'}`}>
                
                {/* Checkbox de Seleção (Só aparece no modo seleção) */}
                {isSelectionMode && (
                    <div 
                        className={`select-checkbox ${selectedIds.includes(msg.id) ? 'selected' : ''}`}
                        onClick={() => toggleMessageSelection(msg.id)}
                    ></div>
                )}

                <div className="message-bubble" onClick={() => isSelectionMode && toggleMessageSelection(msg.id)}>
                    {/* Audio Content */}
                    {msg.contentType === 'audio' && (
                        <div className={`audio-player ${playingAudioId === msg.id ? 'playing' : ''}`}>
                            <div 
                                className={`audio-control ${playingAudioId === msg.id ? 'playing' : ''}`}
                                onClick={(e) => { e.stopPropagation(); handlePlayAudio(msg.id, msg.duration); }}
                            >
                                <i className={`fa-solid ${playingAudioId === msg.id ? 'fa-pause' : 'fa-play'}`}></i>
                            </div>
                            <div className="audio-info">
                                <span style={{fontSize:'13px', fontWeight: 'bold'}}>Áudio ({msg.duration})</span>
                                <div className="audio-waveform">
                                    <div className="audio-progress"></div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* Image Content */}
                    {msg.contentType === 'image' && msg.mediaUrl && (
                        <div className="media-content">
                            <img src={msg.mediaUrl} alt="Imagem" />
                        </div>
                    )}

                    {/* Video Content */}
                    {msg.contentType === 'video' && msg.mediaUrl && (
                        <div className="media-content">
                            <video src={msg.mediaUrl} controls />
                        </div>
                    )}

                    {/* Text Content */}
                    {msg.contentType === 'text' && msg.text}
                    
                    <div className="message-meta">
                        <span>{msg.timestamp}</span>
                        {isMe && renderStatusIcon(msg.status)}
                    </div>
                </div>
            </div>
            );
        })}
        <div ref={messagesEndRef} />
        <div style={{ height: '20px' }}></div> 
      </main>

      {/* ÁREA DE INPUT OU BLOQUEIO */}
      {isBlocked ? (
          <div className="blocked-footer">
              Você bloqueou este contato.
          </div>
      ) : (
          <div className="chat-input-area">
            {isRecording ? (
                // UI DE GRAVAÇÃO
                <>
                    <div className="recording-ui">
                        <div className="recording-dot"></div>
                        <span>Gravando {formatTime(recordingTime)}</span>
                    </div>
                    <button onClick={cancelRecording} style={{color: '#ff4d4d', fontSize: '14px', fontWeight: 'bold'}}>
                        Cancelar
                    </button>
                </>
            ) : (
                // UI DE TEXTO NORMAL
                <>
                    <input 
                        type="text" 
                        placeholder="Digite sua mensagem..." 
                        value={inputText}
                        onChange={(e) => setInputText(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                        disabled={isSelectionMode}
                    />
                    
                    {inputText.length === 0 && (
                        <>
                            <input 
                                type="file" 
                                ref={fileInputRef} 
                                accept="image/*,video/*" 
                                style={{display:'none'}} 
                                onChange={handleFileChange}
                            />
                            <button 
                                className="attachment-button" 
                                title="Anexar Mídia" 
                                disabled={isSelectionMode}
                                onClick={handleAttachmentClick}
                            >
                                <i className="fa-solid fa-paperclip"></i>
                            </button>
                        </>
                    )}
                </>
            )}
            
            <button 
                id="sendButton" 
                title={inputText.length > 0 ? "Enviar" : (isRecording ? "Enviar Áudio" : "Gravar")}
                onClick={handleAudioAction}
                disabled={isSelectionMode}
            >
                <i className={`fa-solid ${inputText.length > 0 ? 'fa-paper-plane' : (isRecording ? 'fa-paper-plane' : 'fa-microphone')}`}></i>
            </button>
          </div>
      )}

      {/* FOOTER NAVEGAÇÃO */}
      <footer className="nav-footer">
        <button onClick={() => navigate('/feed')}><i className="fa-solid fa-newspaper"></i></button>
        <button className="active"><i className="fa-solid fa-comments"></i></button>
        <button onClick={() => navigate('/notifications')}><i className="fa-solid fa-bell"></i></button>
        <button onClick={() => navigate('/profile')}><i className="fa-solid fa-user"></i></button>
      </footer>
    </div>
  );
};
