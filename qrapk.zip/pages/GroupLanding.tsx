

import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { groupService } from '../services/groupService';
import { authService } from '../services/authService';
import { Group } from '../types';

export const GroupLanding: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [group, setGroup] = useState<Group | null>(null);
  const [requestSent, setRequestSent] = useState(false);
  const [creatorName, setCreatorName] = useState('Desconhecido');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      const foundGroup = groupService.getGroupById(id);
      if (foundGroup) {
        setGroup(foundGroup);
        
        // Check if already pending
        const currentUserEmail = authService.getCurrentUserEmail();
        if (currentUserEmail && foundGroup.pendingMembers?.includes(currentUserEmail)) {
            setRequestSent(true);
        }
        
        // Mock fetching creator name
        if (foundGroup.creatorEmail) {
            const users = authService.getAllUsers();
            const creator = users.find(u => u.email === foundGroup.creatorEmail);
            if (creator?.profile?.name) {
                setCreatorName(creator.profile.name);
            } else if (foundGroup.creatorEmail.includes('@')) {
                setCreatorName(foundGroup.creatorEmail.split('@')[0]);
            }
        } else {
            setCreatorName('Admin Flux');
        }
      } else {
        // Fallback mock if not in DB (for demo consistency)
        setGroup({
            id: id,
            name: 'Grupo Exemplo',
            description: 'Descrição do grupo não encontrada.',
            isVip: false,
            isPrivate: true,
            time: 'Agora',
            lastMessage: ''
        });
      }
      setLoading(false);
    }
  }, [id, navigate]);

  const handleJoinAction = () => {
      if (!group || !id) return;
      
      const result = groupService.joinGroup(id);
      
      if (result === 'joined') {
          navigate(`/group-chat/${id}`);
      } else if (result === 'pending') {
          setRequestSent(true);
          // alert('Solicitação enviada ao administrador do grupo.');
      } else if (result === 'full') {
          alert('Este grupo atingiu o limite máximo de membros.');
      } else {
          alert('Ocorreu um erro ao tentar entrar no grupo.');
      }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center bg-[#0c0f14] text-white">Carregando...</div>;
  if (!group) return <div className="min-h-screen flex items-center justify-center bg-[#0c0f14] text-white">Grupo não encontrado.</div>;

  const isPrivate = group.isPrivate;

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-x-hidden">
      <style>{`
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        
        header {
            display:flex; align-items:center; justify-content:space-between; padding:16px 32px;
            background: #0c0f14; position:fixed; width:100%; z-index:10; border-bottom:1px solid rgba(255,255,255,0.1);
            top: 0; height: 80px;
        }
        header button {
            background:none; border:none; color:#00c2ff; font-size:18px; cursor:pointer; transition:0.3s;
        }
        header button:hover { color:#fff; }

        main {
            flex-grow: 1; display: flex; flex-direction: column; align-items: center;
            width: 100%; padding-top: 120px; padding-bottom: 100px;
        }

        .group-cover-large {
            width: 140px; height: 140px; border-radius: 50%;
            border: 4px solid ${isPrivate ? '#ff5722' : '#00c2ff'};
            object-fit: cover; margin-bottom: 20px;
            box-shadow: 0 0 30px ${isPrivate ? 'rgba(255,87,34,0.3)' : 'rgba(0,194,255,0.3)'};
            background: rgba(255,255,255,0.05);
            display: flex; align-items: center; justify-content: center;
            font-size: 50px; color: ${isPrivate ? '#ff5722' : '#00c2ff'};
        }
        .group-cover-large img { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; }

        .group-title {
            font-size: 26px; font-weight: 800; text-align: center; margin-bottom: 10px;
            color: #fff; padding: 0 20px;
        }
        
        .group-badge {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 6px 12px; border-radius: 20px; font-size: 12px; font-weight: 700;
            margin-bottom: 20px; text-transform: uppercase; letter-spacing: 1px;
        }
        .badge-public { background: rgba(0,194,255,0.15); color: #00c2ff; border: 1px solid rgba(0,194,255,0.3); }
        .badge-private { background: rgba(255,87,34,0.15); color: #ff5722; border: 1px solid rgba(255,87,34,0.3); }

        .info-box {
            background: rgba(255,255,255,0.05); border-radius: 16px; padding: 20px;
            width: 90%; max-width: 400px; border: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 30px; text-align: center;
        }
        
        .creator-info {
            font-size: 14px; color: #aaa; margin-bottom: 15px; display: flex; align-items: center; justify-content: center; gap: 8px;
        }
        .creator-info i { color: #00c2ff; }
        
        .description {
            font-size: 15px; line-height: 1.5; color: rgba(255,255,255,0.9); margin-bottom: 20px;
        }
        
        .stats {
            display: flex; justify-content: center; gap: 20px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 15px;
        }
        .stat-item { display: flex; flex-direction: column; align-items: center; }
        .stat-val { font-size: 18px; font-weight: 700; color: #fff; }
        .stat-label { font-size: 12px; color: #aaa; }

        .join-btn {
            width: 90%; max-width: 350px; padding: 16px; border: none; border-radius: 12px;
            font-size: 18px; font-weight: 700; cursor: pointer; transition: 0.3s;
            display: flex; align-items: center; justify-content: center; gap: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.4);
        }
        .btn-public { background: #00c2ff; color: #000; }
        .btn-public:hover { background: #0099cc; transform: translateY(-2px); }
        
        .btn-private { background: #ff5722; color: #fff; }
        .btn-private:hover { background: #e64a19; transform: translateY(-2px); }
        
        .btn-disabled { 
            background: #333; color: #777; cursor: not-allowed; 
            box-shadow: none; border: 1px solid #444;
        }
        .btn-disabled:hover { transform: none; }

      `}</style>

      <header>
        <button onClick={() => navigate('/groups')}><i className="fa-solid fa-arrow-left"></i></button>
        
        <div 
            className="absolute left-1/2 -translate-x-1/2 w-[60px] h-[60px] bg-white/5 rounded-2xl flex justify-center items-center z-20 cursor-pointer shadow-[0_0_20px_rgba(0,194,255,0.3),inset_0_0_20px_rgba(0,194,255,0.08)]"
            onClick={() => navigate('/feed')}
        >
             <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] rotate-[25deg]"></div>
             <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] -rotate-[25deg]"></div>
        </div>

        <div style={{width:'24px'}}></div>
      </header>

      <main>
        <div className="group-cover-large">
            {group.coverImage ? (
                <img src={group.coverImage} alt={group.name} />
            ) : (
                <i className={`fa-solid ${isPrivate ? 'fa-lock' : 'fa-users'}`}></i>
            )}
        </div>

        <h1 className="group-title">{group.name}</h1>
        
        <div className={`group-badge ${isPrivate ? 'badge-private' : 'badge-public'}`}>
            <i className={`fa-solid ${isPrivate ? 'fa-lock' : 'fa-globe'}`}></i>
            {isPrivate ? 'Grupo Privado' : 'Grupo Público'}
        </div>

        <div className="info-box">
            <div className="creator-info">
                <i className="fa-solid fa-crown"></i> Criado por <strong>{creatorName}</strong>
            </div>
            
            <div className="description">
                {group.description || "Bem-vindo! Este grupo é um espaço para compartilhar ideias e conectar pessoas."}
            </div>

            <div className="stats">
                <div className="stat-item">
                    <span className="stat-val">{group.members?.length || 0}</span>
                    <span className="stat-label">Membros</span>
                </div>
                <div className="stat-item">
                    <span className="stat-val">12</span>
                    <span className="stat-label">Online</span>
                </div>
            </div>
        </div>

        <button 
            className={`join-btn ${requestSent ? 'btn-disabled' : (isPrivate ? 'btn-private' : 'btn-public')}`}
            onClick={handleJoinAction}
            disabled={requestSent}
        >
            {requestSent ? (
                <>
                    <i className="fa-solid fa-check"></i> Solicitação Enviada
                </>
            ) : (
                isPrivate ? (
                    <>
                        <i className="fa-solid fa-user-plus"></i> Pedir para Entrar
                    </>
                ) : (
                    <>
                        <i className="fa-solid fa-arrow-right-to-bracket"></i> Entrar no Grupo
                    </>
                )
            )}
        </button>

        {isPrivate && !requestSent && (
            <p style={{marginTop:'15px', fontSize:'12px', color:'#777', maxWidth:'300px', textAlign:'center'}}>
                Este grupo é fechado. Sua entrada depende da aprovação de um administrador.
            </p>
        )}

      </main>
    </div>
  );
};