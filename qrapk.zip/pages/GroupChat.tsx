
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { groupService } from '../services/groupService';
import { chatService } from '../services/chatService'; // Use Chat Service for persistence
import { authService } from '../services/authService';
import { db } from '@/database';
import { Group, ChatMessage } from '../types';

export const GroupChat: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [group, setGroup] = useState<Group | null>(null);
  const [isCreator, setIsCreator] = useState(false);
  
  // Messages State
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  // Gravação de Áudio
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const recordingInterval = useRef<any>(null);

  // Reprodução de Áudio
  const [playingAudioId, setPlayingAudioId] = useState<number | null>(null);
  const audioTimeoutRef = useRef<any>(null);

  const menuRef = useRef<HTMLDivElement>(null);
  const buttonRef = useRef<HTMLButtonElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const currentUserEmail = authService.getCurrentUserEmail();

  // Load Group and Messages
  useEffect(() => {
      if (id) {
          const loadedGroup = groupService.getGroupById(id);

          if (loadedGroup) {
              setGroup(loadedGroup);
              setIsCreator(loadedGroup.creatorEmail === currentUserEmail);

              // VIP Check
              if (loadedGroup.isVip && loadedGroup.creatorEmail !== currentUserEmail && currentUserEmail) {
                  const hasAccess = db.vipAccess.check(currentUserEmail, loadedGroup.id);
                  if (!hasAccess) {
                      navigate(`/vip-group-sales/${loadedGroup.id}`, { replace: true });
                      return;
                  }
              }
              
              // Load Messages from ChatService (using group ID)
              loadMessages();

          } else {
              navigate('/groups');
          }
      }
  }, [id, navigate]);

  const loadMessages = () => {
      if (!id) return;
      const chatData = chatService.getChat(id); // Treat group ID as chat ID
      setMessages(chatData.messages || []);
  };

  // --- REAL TIME SUBSCRIPTION ---
  useEffect(() => {
      // Subscribe to 'chats' to update messages in real-time
      const unsubscribe = db.subscribe('chats', () => {
          loadMessages();
      });
      return () => unsubscribe();
  }, [id]);

  useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
          if (menuRef.current && !menuRef.current.contains(event.target as Node) && 
              buttonRef.current && !buttonRef.current.contains(event.target as Node)) {
              setIsMenuOpen(false);
          }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, isRecording]);

  // Timer de gravação
  useEffect(() => {
      if (isRecording) {
          recordingInterval.current = setInterval(() => {
              setRecordingTime(prev => prev + 1);
          }, 1000);
      } else {
          clearInterval(recordingInterval.current);
          setRecordingTime(0);
      }
      return () => clearInterval(recordingInterval.current);
  }, [isRecording]);

  const getCurrentUserInfo = () => {
      const user = authService.getCurrentUser();
      return {
          name: user?.profile?.nickname || user?.profile?.name || 'Você',
          avatar: user?.profile?.photoUrl,
          email: user?.email
      };
  };

  const saveMessage = (msg: ChatMessage) => {
      if (!id) return;
      chatService.sendMessage(id, msg);
      // Local state update happens via db subscription or optimistic logic if needed
      setMessages(prev => [...prev, msg]); 
  };

  const handleSendMessage = () => {
      if (inputText.trim()) {
          const userInfo = getCurrentUserInfo();
          const newMessage: ChatMessage = {
              id: Date.now(),
              senderName: userInfo.name,
              senderAvatar: userInfo.avatar,
              senderEmail: userInfo.email,
              text: inputText,
              type: 'sent', // For the sender it is 'sent'
              contentType: 'text',
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              status: 'sent'
          };
          saveMessage(newMessage);
          setInputText('');
      }
  };

  const handleAttachmentClick = () => {
      fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (ev) => {
          const mediaUrl = ev.target?.result as string;
          const isVideo = file.type.startsWith('video/');
          const userInfo = getCurrentUserInfo();
          
          const newMessage: ChatMessage = {
              id: Date.now(),
              senderName: userInfo.name,
              senderAvatar: userInfo.avatar,
              senderEmail: userInfo.email,
              text: isVideo ? 'Vídeo' : 'Foto',
              type: 'sent',
              contentType: isVideo ? 'video' : 'image',
              mediaUrl: mediaUrl,
              timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              status: 'sent'
          };

          saveMessage(newMessage);
      };
      reader.readAsDataURL(file);
      if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleAudioAction = () => {
      if (inputText.length > 0) {
          handleSendMessage();
      } else {
          if (isRecording) {
              // Parar e Enviar Áudio
              setIsRecording(false);
              const userInfo = getCurrentUserInfo();
              const durationStr = formatTime(recordingTime);
              
              const newMessage: ChatMessage = {
                  id: Date.now(),
                  senderName: userInfo.name,
                  senderAvatar: userInfo.avatar,
                  senderEmail: userInfo.email,
                  text: 'Mensagem de Voz',
                  type: 'sent',
                  contentType: 'audio',
                  duration: durationStr,
                  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
                  status: 'sent'
              };
              saveMessage(newMessage);
          } else {
              // Iniciar Gravação
              setIsRecording(true);
          }
      }
  };

  const cancelRecording = () => {
      setIsRecording(false);
  };

  const handlePlayAudio = (id: number, durationStr?: string) => {
      if (playingAudioId === id) {
          // Pause
          setPlayingAudioId(null);
          if (audioTimeoutRef.current) clearTimeout(audioTimeoutRef.current);
      } else {
          // Play
          setPlayingAudioId(id);
          
          let durationMs = 3000; 
          if (durationStr) {
              const parts = durationStr.split(':');
              if (parts.length === 2) {
                  const min = parseInt(parts[0]);
                  const sec = parseInt(parts[1]);
                  durationMs = (min * 60 + sec) * 1000;
              }
          }

          if (audioTimeoutRef.current) clearTimeout(audioTimeoutRef.current);
          audioTimeoutRef.current = setTimeout(() => {
              setPlayingAudioId(null);
          }, durationMs);
      }
  };

  const formatTime = (seconds: number) => {
      const mins = Math.floor(seconds / 60);
      const secs = seconds % 60;
      return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const handleCopyGroupLink = () => {
      if (!id) return;
      const link = group?.isVip 
        ? `${window.location.origin}/#/vip-group-sales/${id}`
        : `${window.location.origin}/#/group-landing/${id}`;
        
      navigator.clipboard.writeText(link).then(() => {
          alert('Link do grupo copiado!');
      });
      setIsMenuOpen(false);
  };

  const getGroupCover = () => {
      if (group?.coverImage) return <img src={group.coverImage} alt="Group" className="w-full h-full object-cover" />;
      return <i className="fa-solid fa-users text-gray-400 text-xl"></i>;
  };

  return (
    <div className="min-h-screen flex flex-col bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] overflow-hidden">
      <style>{`
        header {
            display: flex; align-items: center; padding: 10px 16px;
            background: #0c0f14; position: fixed; width: 100%; z-index: 20;
            border-bottom: 1px solid rgba(255,255,255,0.1); top: 0; height: 60px;
        }
        header .back-btn {
            background: none; border: none; color: #00c2ff; font-size: 18px; cursor: pointer; padding-right: 10px;
        }
        .group-info { display: flex; align-items: center; flex-grow: 1; cursor: pointer; }
        .group-avatar {
            width: 36px; height: 36px; border-radius: 50%; overflow: hidden;
            background: #1e2531; display: flex; align-items: center; justify-content: center;
            border: 1px solid #00c2ff; margin-right: 10px;
        }
        .group-name { font-size: 15px; font-weight: 700; color: #fff; }
        .group-status { font-size: 11px; color: #00ff82; }

        .options-btn { background: none; border: none; color: #fff; font-size: 18px; cursor: pointer; }
        
        .dropdown {
            position: absolute; top: 50px; right: 10px; background: #1a1e26;
            border: 1px solid rgba(255,255,255,0.1); border-radius: 8px;
            width: 180px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.5);
        }
        .dropdown button {
            width: 100%; text-align: left; padding: 12px; background: none; border: none;
            color: #fff; font-size: 14px; cursor: pointer; transition: 0.2s; border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        .dropdown button:hover { background: rgba(0,194,255,0.1); color: #00c2ff; }
        
        main {
            flex-grow: 1; padding: 70px 10px 80px 10px; overflow-y: auto; display: flex; flex-direction: column;
        }
        
        .message-row { display: flex; margin-bottom: 8px; }
        .message-row.sent { justify-content: flex-end; }
        .message-bubble {
            max-width: 75%; padding: 8px 12px; border-radius: 12px; font-size: 14px; line-height: 1.4; position: relative;
        }
        .message-row.sent .message-bubble {
            background: #00c2ff; color: #000; border-bottom-right-radius: 2px;
        }
        .message-row.received .message-bubble {
            background: #1e2531; color: #fff; border-bottom-left-radius: 2px;
        }
        .sender-name {
            font-size: 10px; font-weight: 700; margin-bottom: 2px; color: rgba(255,255,255,0.6); display: flex; align-items: center; gap: 5px;
        }
        .sender-avatar { width: 16px; height: 16px; border-radius: 50%; object-fit: cover; }
        .message-row.sent .sender-name { display: none; }
        
        /* Media Styles */
        .media-content { border-radius: 8px; overflow: hidden; margin-top: 4px; max-width: 240px; background: #000; }
        .media-content img, .media-content video { width: 100%; height: auto; display: block; }
        
        /* Audio Player */
        .audio-player { display: flex; align-items: center; gap: 8px; min-width: 180px; padding: 5px 0; }
        .play-btn { 
            width: 30px; height: 30px; border-radius: 50%; background: rgba(0,0,0,0.2); 
            display: flex; align-items: center; justify-content: center; cursor: pointer; 
        }
        .play-btn i { font-size: 12px; }
        
        .input-area {
            position: fixed; bottom: 0; left: 0; width: 100%; background: #0c0f14;
            padding: 10px; border-top: 1px solid rgba(255,255,255,0.1);
            display: flex; align-items: center; gap: 10px; z-index: 20;
        }
        .input-area input {
            flex-grow: 1; background: #1e2531; border: none; border-radius: 20px;
            padding: 10px 15px; color: #fff; outline: none;
        }
        .icon-btn {
            background: none; border: none; color: #00c2ff; font-size: 20px; cursor: pointer;
        }
        
        .recording-status {
            flex-grow: 1; color: #ff4d4d; font-weight: bold; display: flex; align-items: center; gap: 10px;
        }
        .rec-dot { width: 10px; height: 10px; background: #ff4d4d; border-radius: 50%; animation: blink 1s infinite; }
        @keyframes blink { 0% {opacity: 1;} 50% {opacity: 0.5;} 100% {opacity: 1;} }
        
        /* Footer Badge - Tighter positioning */
        .nav-badge {
            position: absolute; top: 0px; right: 0px;
            width: 10px; height: 10px; background: #ff4d4d;
            border-radius: 50%; border: 1px solid #0c0f14;
        }
      `}</style>

      <header>
          <button className="back-btn" onClick={() => navigate('/groups')}>
              <i className="fa-solid fa-arrow-left"></i>
          </button>
          
          <div className="group-info" onClick={() => isCreator && id && navigate(`/group-settings/${id}`)}>
              <div className="group-avatar">{getGroupCover()}</div>
              <div>
                  <div className="group-name">{group?.name || 'Carregando...'}</div>
                  <div className="group-status">{messages.length} mensagens</div>
              </div>
          </div>

          <div style={{position: 'relative'}} ref={menuRef}>
              <button className="options-btn" ref={buttonRef} onClick={() => setIsMenuOpen(!isMenuOpen)}>
                  <i className="fa-solid fa-ellipsis-vertical"></i>
              </button>
              
              {isMenuOpen && (
                  <div className="dropdown">
                      <button onClick={handleCopyGroupLink}>
                          <i className="fa-solid fa-link"></i> Copiar Link
                      </button>
                      <button onClick={() => { if(id) { chatService.clearChat(id); loadMessages(); } setIsMenuOpen(false); }}>
                          <i className="fa-solid fa-eraser"></i> Limpar Chat (Local)
                      </button>
                      <button onClick={() => navigate('/groups')} style={{color:'#ff4d4d'}}>
                          <i className="fa-solid fa-arrow-right-from-bracket"></i> Sair
                      </button>
                  </div>
              )}
          </div>
      </header>

      <main>
          {messages.length === 0 && (
              <div className="flex flex-col items-center justify-center h-full opacity-50">
                  <i className="fa-regular fa-comments text-4xl mb-2"></i>
                  <p>Nenhuma mensagem ainda.</p>
              </div>
          )}

          {messages.map((msg) => {
              // Identify if message is sent by current user by comparing email if available, or fallback to type 'sent'
              const isMe = msg.senderEmail ? msg.senderEmail === currentUserEmail : msg.type === 'sent';
              
              return (
                  <div key={msg.id} className={`message-row ${isMe ? 'sent' : 'received'}`}>
                      <div className="message-bubble">
                          {!isMe && (
                              <div className="sender-name">
                                  {msg.senderAvatar && <img src={msg.senderAvatar} className="sender-avatar" />}
                                  {msg.senderName}
                              </div>
                          )}
                          
                          {msg.contentType === 'text' && msg.text}
                          
                          {msg.contentType === 'image' && msg.mediaUrl && (
                              <div className="media-content">
                                  <img src={msg.mediaUrl} alt="Mídia" />
                              </div>
                          )}
                          
                          {msg.contentType === 'video' && msg.mediaUrl && (
                              <div className="media-content">
                                  <video src={msg.mediaUrl} controls />
                              </div>
                          )}

                          {msg.contentType === 'audio' && (
                              <div className="audio-player">
                                  <div className="play-btn" onClick={() => handlePlayAudio(msg.id, msg.duration)}>
                                      <i className={`fa-solid ${playingAudioId === msg.id ? 'fa-pause' : 'fa-play'}`}></i>
                                  </div>
                                  <div style={{flex:1, height:'2px', background:'rgba(255,255,255,0.3)', margin:'0 10px'}}>
                                      <div style={{width: playingAudioId === msg.id ? '100%' : '0%', height:'100%', background:'currentColor', transition: 'width 3s linear'}}></div>
                                  </div>
                                  <span style={{fontSize:'10px'}}>{msg.duration}</span>
                              </div>
                          )}
                      </div>
                  </div>
              );
          })}
          <div ref={messagesEndRef} />
      </main>

      <div className="input-area">
          {isRecording ? (
              <>
                  <div className="recording-status">
                      <div className="rec-dot"></div>
                      <span>Gravando {formatTime(recordingTime)}</span>
                  </div>
                  <button className="icon-btn" onClick={cancelRecording} style={{color:'#ff4d4d'}}>
                      Cancelar
                  </button>
              </>
          ) : (
              <>
                  <button className="icon-btn" onClick={handleAttachmentClick}>
                      <i className="fa-solid fa-paperclip"></i>
                  </button>
                  <input 
                      type="file" 
                      ref={fileInputRef} 
                      hidden 
                      accept="image/*,video/*" 
                      onChange={handleFileChange} 
                  />
                  <input 
                      type="text" 
                      placeholder="Mensagem..." 
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                  />
              </>
          )}
          
          <button className="icon-btn" onClick={handleAudioAction}>
              <i className={`fa-solid ${inputText.trim() ? 'fa-paper-plane' : (isRecording ? 'fa-paper-plane' : 'fa-microphone')}`}></i>
          </button>
      </div>
    </div>
  );
};
