
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { authService } from '../services/authService';

export const ForgotPassword: React.FC = () => {
  const navigate = useNavigate();
  
  // States
  const [email, setEmail] = useState('');
  const [code, setCode] = useState<string[]>(['', '', '', '', '', '']);
  const [verificationSent, setVerificationSent] = useState(false);
  const [timer, setTimer] = useState(0);
  const [loading, setLoading] = useState(false);
  const [btnText, setBtnText] = useState('Enviar E-mail');
  const [btnColor, setBtnColor] = useState('#00c2ff'); // Default blue
  
  const codeInputsRef = useRef<(HTMLInputElement | null)[]>([]);

  // Timer Effect
  useEffect(() => {
    let interval: any;
    if (timer > 0) {
      interval = setInterval(() => setTimer((prev) => prev - 1), 1000);
    }
    return () => clearInterval(interval);
  }, [timer]);

  // Reset button text after error/success momentarily
  const flashButton = (text: string, color: string, duration = 1500) => {
    const originalText = verificationSent ? 'Verificar Código' : 'Enviar E-mail';
    const originalColor = '#00c2ff';
    
    setBtnText(text);
    setBtnColor(color);
    
    if (duration > 0) {
        setTimeout(() => {
            setBtnText(originalText);
            setBtnColor(originalColor);
        }, duration);
    }
  };

  // Handlers
  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!verificationSent) {
        // STAGE 1: Send Email (Type: RESET)
        if (!email) return;
        setLoading(true);
        
        try {
            // Pass 'reset' to send correct template
            await authService.sendVerificationCode(email, 'reset');
            setVerificationSent(true);
            setTimer(30);
            setBtnText('Verificar Código');
            // Focus first code input
            setTimeout(() => codeInputsRef.current[0]?.focus(), 100);
        } catch (err: any) {
            // Show error on button roughly
            flashButton(err.message || 'Erro ao enviar', '#ff6b6b');
        } finally {
            setLoading(false);
        }

    } else {
        // STAGE 2: Verify Code
        const fullCode = code.join('');
        if (fullCode.length < 6) return;
        
        setLoading(true);
        try {
            await authService.verifyCode(email, fullCode, true); // isResetFlow = true
            
            // Success visual
            setBtnText('Verificado!');
            setBtnColor('#10ac84');
            
            // Navigate
            localStorage.setItem('reset_email', email);
            setTimeout(() => {
                navigate('/reset-password');
            }, 1000);
        } catch (err: any) {
            flashButton('Código Incorreto', '#ff6b6b');
            // Clear code
            setTimeout(() => {
                setCode(['', '', '', '', '', '']);
                codeInputsRef.current[0]?.focus();
            }, 1500);
        } finally {
            setLoading(false);
        }
    }
  };

  const handleResend = async () => {
      if (timer > 0) return;
      try {
          await authService.sendVerificationCode(email, 'reset');
          setTimer(30);
          console.log("Código reenviado");
      } catch (error) {
          console.error(error);
      }
  };

  const handleCodeChange = (index: number, value: string) => {
      if (!/^\d*$/.test(value)) return;
      
      const newCode = [...code];
      newCode[index] = value.slice(-1);
      setCode(newCode);

      // Auto focus next
      if (value && index < 5) {
          codeInputsRef.current[index + 1]?.focus();
      }
  };

  const handleCodeKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
      if (e.key === 'Backspace' && !code[index] && index > 0) {
          codeInputsRef.current[index - 1]?.focus();
      }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
      e.preventDefault();
      const pasteData = e.clipboardData.getData('text').trim().replace(/\D/g, '');
      if (!pasteData) return;

      const newCode = [...code];
      for(let i = 0; i < 6; i++) {
          if (pasteData[i]) newCode[i] = pasteData[i];
      }
      setCode(newCode);
      
      // Focus last filled or last input
      const focusIndex = Math.min(pasteData.length, 5);
      codeInputsRef.current[focusIndex]?.focus();
  };

  const isBtnDisabled = !verificationSent 
    ? !email 
    : code.some(c => c === '') || loading;

  return (
    <>
        {/* Injected CSS from Prompt */}
        <style>{`
            /* Estilos globais e resets */
            * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
            
            .forgot-page-wrapper {
                background: radial-gradient(circle at top left, #0c0f14, #0a0c10);
                color:#fff;
                min-height:100vh;
                display:flex;
                flex-direction:column;
                align-items:center;
                justify-content:center;
                padding-bottom: 20px;
                overflow-x:hidden;
            }

            /* HEADER (Botão Voltar) */
            header.fp-header {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                display: flex;
                justify-content: flex-start;
                padding: 16px 20px;
                z-index: 10;
            }
            header.fp-header button {
                background: rgba(255,255,255,0.1);
                border: 1px solid #00c2ff;
                color: #00c2ff;
                font-size: 18px;
                cursor: pointer;
                transition: 0.3s;
                width: 40px;
                height: 40px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            header.fp-header button:hover {
                color: #fff;
                background: #00c2ff;
                color: #000;
            }

            /* LOGO CENTRALIZADA */
            .login-logo {
                width: 60px;
                height: 60px;
                background: rgba(255,255,255,0.02);
                border-radius: 16px;
                box-shadow: 0 0 20px rgba(0,194,255,0.3), inset 0 0 20px rgba(0,194,255,0.08);
                display: flex;
                justify-content: center;
                align-items: center;
                transition: .4s;
                margin: 0 auto 20px auto; 
                cursor: default; 
            }
            .login-logo::before, .login-logo::after {
                content:""; position:absolute; border-radius:50%; border:3px solid #00c2ff;
            }
            .login-logo::before { width:40px; height:22px; transform:rotate(25deg); }
            .login-logo::after { width:40px; height:22px; transform:rotate(-25deg); }

            /* CONTAINER PRINCIPAL */
            #verify-container {
                width: 100%;
                max-width: 360px;
                background: rgba(255,255,255,0.05);
                backdrop-filter: blur(12px);
                border-radius: 20px;
                padding: 30px 25px;
                box-shadow: 0 10px 30px rgba(0,0,0,0.5);
                border: 1px solid rgba(255,255,255,0.1);
                text-align: center;
            }

            h1 {
                font-size: 22px;
                font-weight: 800;
                margin-bottom: 10px;
                color: #fff;
                text-shadow: 0 0 5px rgba(0,194,255,0.5);
            }

            p.info-text {
                font-size: 15px;
                color: rgba(255, 255, 255, 0.9);
                margin-bottom: 25px;
                line-height: 1.4;
            }

            /* Campos de Input (Geral para Email) */
            .input-group {
                position: relative;
                margin-bottom: 20px;
                text-align: left;
            }
            .input-group input {
                width: 100%;
                padding: 12px 12px 12px 40px;
                background: rgba(255,255,255,0.1);
                border: 1px solid #00c2ff;
                border-radius: 10px;
                color: #fff;
                font-size: 16px;
                transition: 0.3s;
                outline: none;
            }
            .input-group input:focus {
                background: rgba(0,194,255,0.1);
                box-shadow: 0 0 8px rgba(0,194,255,0.8);
            }
            .input-group i {
                position: absolute;
                left: 15px;
                top: 50%;
                transform: translateY(-50%);
                color: #00c2ff;
                font-size: 18px;
            }

            /* Estilo para o campo de código de 6 dígitos */
            .code-input-group {
                display: flex;
                justify-content: center;
                gap: 10px;
                margin-bottom: 30px;
                opacity: 0;
                height: 0;
                overflow: hidden;
                transition: opacity 0.4s, height 0.4s;
            }
            .code-input-group.active {
                opacity: 1;
                height: 45px;
                margin-bottom: 30px;
            }

            .code-input-group input {
                width: 45px;
                height: 45px;
                text-align: center;
                font-size: 20px;
                font-weight: 600;
                background: rgba(255,255,255,0.1);
                border: 2px solid #00c2ff;
                border-radius: 8px;
                color: #fff;
                outline: none;
                transition: 0.3s;
            }

            .code-input-group input:focus {
                background: rgba(0,194,255,0.1);
                box-shadow: 0 0 8px rgba(0,194,255,0.8);
            }

            /* Botão Principal */
            #mainBtn {
                width: 100%;
                padding: 14px;
                background: #00c2ff;
                border: none;
                border-radius: 10px;
                color: #000;
                font-size: 18px;
                font-weight: 600;
                cursor: pointer;
                transition: background 0.3s, transform 0.1s, opacity 0.3s, box-shadow 0.3s;
                box-shadow: 0 4px 10px rgba(0,194,255,0.4);
                margin-bottom: 15px;
            }
            #mainBtn:hover:not(:disabled) {
                transform: translateY(-1px);
                box-shadow: 0 6px 15px rgba(0,194,255,0.6);
            }
            #mainBtn:disabled {
                background: rgba(0,194,255,0.4) !important;
                cursor: not-allowed;
                opacity: 0.6;
                box-shadow: none;
            }

            /* Botão Reenviar Código */
            #resendBtn {
                background: none;
                border: none;
                color: #00c2ff;
                font-size: 14px;
                cursor: pointer;
                transition: color 0.3s;
                padding: 10px;
                visibility: hidden;
                opacity: 0;
                transition: opacity 0.4s;
            }
            #resendBtn.active {
                visibility: visible;
                opacity: 1;
            }
            #resendBtn:hover:not(:disabled) {
                color: #fff;
                text-decoration: underline;
            }
            #resendBtn:disabled {
                color: rgba(0,194,255,0.5);
                cursor: not-allowed;
            }

            /* Link Voltar */
            .back-link {
                margin-top: 25px;
                font-size: 14px;
            }
            .back-link a {
                color: #00c2ff;
                text-decoration: none;
                transition: color 0.3s;
            }
            .back-link a:hover {
                color: #fff;
                text-decoration: underline;
            }
        `}</style>

        <div className="forgot-page-wrapper">
            <header className="fp-header">
                <button onClick={() => navigate('/')}><i className="fa-solid fa-arrow-left"></i></button>
            </header>

            <div id="verify-container">
                <div className="login-logo"></div>

                <h1>{verificationSent ? 'Verificação de Código' : 'Recuperação de Senha'}</h1>
                
                <p className="info-text">
                    {verificationSent 
                        ? <>Enviamos o código para <strong>{email}</strong>. Insira-o abaixo:</>
                        : "Por favor, insira o e-mail da sua conta para enviarmos o código de verificação."
                    }
                </p>

                <form onSubmit={handleEmailSubmit}>
                    <div className="input-group">
                        <i className="fa-solid fa-envelope"></i>
                        <input 
                            type="email" 
                            placeholder="E-mail" 
                            required 
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            readOnly={verificationSent}
                        />
                    </div>

                    <div className={`code-input-group ${verificationSent ? 'active' : ''}`}>
                        {code.map((digit, idx) => (
                            <input 
                                key={idx}
                                ref={el => { codeInputsRef.current[idx] = el }}
                                type="text" 
                                maxLength={1} 
                                className="code-input" 
                                inputMode="numeric"
                                value={digit}
                                onChange={(e) => handleCodeChange(idx, e.target.value)}
                                onKeyDown={(e) => handleCodeKeyDown(idx, e)}
                                onPaste={handlePaste}
                            />
                        ))}
                    </div>

                    <button 
                        type="submit" 
                        id="mainBtn" 
                        disabled={isBtnDisabled}
                        style={{ backgroundColor: btnColor }}
                    >
                        {loading ? <i className="fa-solid fa-circle-notch fa-spin"></i> : btnText}
                    </button>
                </form>

                <button 
                    id="resendBtn" 
                    className={verificationSent ? 'active' : ''}
                    onClick={handleResend}
                    disabled={timer > 0}
                >
                    {timer > 0 ? `Reenviar código (${timer}s)` : "Reenviar código"}
                </button>

                <div className="back-link">
                    Não conseguiu recuperar? <Link to="/">Voltar para o login</Link>
                </div>
            </div>
        </div>
    </>
  );
};
