
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { chatService } from '../services/chatService';
import { relationshipService } from '../services/relationshipService';
import { authService } from '../services/authService';
import { postService } from '../services/postService';
import { notificationService } from '../services/notificationService';
import { Post } from '../types';
import { db } from '@/database';

// --- Carousel Component ---
const ImageCarousel: React.FC<{ images: string[] }> = ({ images }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const scrollRef = useRef<HTMLDivElement>(null);

    const handleScroll = () => {
        if (scrollRef.current) {
            const scrollLeft = scrollRef.current.scrollLeft;
            const width = scrollRef.current.offsetWidth;
            const index = Math.round(scrollLeft / width);
            setCurrentIndex(index);
        }
    };

    return (
        <div className="relative w-full mb-2.5 overflow-hidden rounded-xl bg-black">
            <div className="absolute top-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded-full z-10 backdrop-blur-sm">
                {currentIndex + 1}/{images.length}
            </div>
            <div 
                ref={scrollRef}
                className="flex overflow-x-auto snap-x snap-mandatory no-scrollbar w-full aspect-[4/5]"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                onScroll={handleScroll}
            >
                {images.map((img, idx) => (
                    <img 
                        key={idx} 
                        src={img} 
                        alt={`Slide ${idx}`} 
                        className="w-full h-full flex-shrink-0 snap-center object-cover" 
                    />
                ))}
            </div>
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
                {images.map((_, idx) => (
                    <div 
                        key={idx} 
                        className={`w-1.5 h-1.5 rounded-full transition-all ${currentIndex === idx ? 'bg-[#00c2ff] scale-125' : 'bg-white/50'}`}
                    ></div>
                ))}
            </div>
        </div>
    );
};

export const UserProfile: React.FC = () => {
  const navigate = useNavigate();
  const { username } = useParams<{ username: string }>();
  const [activeTab, setActiveTab] = useState<'posts' | 'fotos' | 'reels'>('posts');
  
  // Profile Logic States
  const [userData, setUserData] = useState<any>(null);
  const [userPosts, setUserPosts] = useState<Post[]>([]);
  const [isPrivate, setIsPrivate] = useState(false);
  const [isMe, setIsMe] = useState(false);
  const [targetUserEmail, setTargetUserEmail] = useState<string>('');
  
  // Relationship States
  const [relationStatus, setRelationStatus] = useState<'none'|'following'|'requested'>('none');
  
  // Blocking & Menu States
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isBlocked, setIsBlocked] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const menuButtonRef = useRef<HTMLButtonElement>(null);

  // Notification Badges
  const [unreadNotifs, setUnreadNotifs] = useState(0);
  const [unreadMsgs, setUnreadMsgs] = useState(0);

  // Load User Data Logic
  useEffect(() => {
      const loadProfile = () => {
          const currentUsername = username ? (username.startsWith('@') ? username : `@${username}`) : "@usuario";
          const cleanHandle = currentUsername.replace('@', '').toLowerCase();

          // Find in Real DB via authService helper that checks DB
          const currentUser = authService.getCurrentUser();
          const targetUser = authService.getUserByHandle(cleanHandle);
          
          // Check if looking at self
          let isSelf = false;
          if (currentUser && currentUser.profile?.name === cleanHandle) {
              isSelf = true;
          }

          if (targetUser) {
              setTargetUserEmail(targetUser.email);
              
              // Fetch Real Stats from DB
              const followers = relationshipService.getFollowers(targetUser.profile?.name || '');
              const following = relationshipService.getFollowing(targetUser.email);
              
              // Fetch Real Posts from DB
              const posts = postService.getUserPosts(currentUsername);
              setUserPosts(posts.sort((a, b) => b.timestamp - a.timestamp));

              const profileData = {
                  username: `@${targetUser.profile?.name}`,
                  nickname: targetUser.profile?.nickname || targetUser.profile?.name,
                  avatar: targetUser.profile?.photoUrl,
                  bio: targetUser.profile?.bio || "Sem biografia.",
                  website: targetUser.profile?.website || undefined, // Add website to loaded data
                  stats: { 
                      posts: posts.length, 
                      followers: followers.length, 
                      following: following.length 
                  }
              };

              setUserData(profileData);
              setIsPrivate(targetUser.profile?.isPrivate || false);
              setIsMe(isSelf);

              // Status
              const blockedStatus = chatService.isUserBlocked(currentUsername);
              setIsBlocked(blockedStatus);

              const status = relationshipService.isFollowing(currentUsername);
              setRelationStatus(status);
          } else {
              setUserData(null); // Not Found
          }
      };

      loadProfile();
      
      // Subscribe to updates
      const unsubUsers = db.subscribe('users', loadProfile);
      const unsubRel = db.subscribe('relationships', loadProfile);
      const unsubPosts = db.subscribe('posts', loadProfile);

      return () => { unsubUsers(); unsubRel(); unsubPosts(); };

  }, [username]);

  // Notification Badges Effect
  useEffect(() => {
      const updateCounts = () => {
          setUnreadNotifs(notificationService.getUnreadCount());
          setUnreadMsgs(chatService.getUnreadCount());
      };
      updateCounts();
      const unsubNotif = db.subscribe('notifications', updateCounts);
      const unsubChat = db.subscribe('chats', updateCounts);
      
      return () => { unsubNotif(); unsubChat(); };
  }, []);

  // Click Outside Handler
  useEffect(() => {
      const handleClickOutside = (event: MouseEvent) => {
          if (menuRef.current && !menuRef.current.contains(event.target as Node) &&
              menuButtonRef.current && !menuButtonRef.current.contains(event.target as Node)) {
              setIsMenuOpen(false);
          }
      };
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (!userData) return (
      <div className="min-h-screen bg-[#0c0f14] text-white flex flex-col items-center justify-center">
          <p>Usuário não encontrado.</p>
          <button onClick={() => navigate('/feed')} className="mt-4 text-[#00c2ff]">Voltar ao Feed</button>
      </div>
  );

  const isFollowing = relationStatus === 'following';
  const followRequestSent = relationStatus === 'requested';
  
  // Visibility Rule: Visible if Public OR Following OR Is Me. AND Not Blocked.
  // Private Logic: If private and not following/me, content is hidden.
  const isContentVisible = (!isPrivate || isFollowing || isMe) && !isBlocked;

  // Messaging Rule: 
  // Public: Always allow messaging (don't need to follow).
  // Private: Must be following.
  const canMessage = (!isPrivate || isFollowing) && !isBlocked;

  const handleBack = () => {
      if (window.history.state && window.history.state.idx > 0) {
          navigate(-1);
      } else {
          navigate('/feed');
      }
  };

  const handleFollowClick = async () => {
    if (isFollowing || followRequestSent) {
        const action = followRequestSent ? 'cancelar solicitação para' : 'deixar de seguir';
        if (window.confirm(`Tem certeza que deseja ${action} ${userData.username}?`)) {
            await relationshipService.unfollowUser(userData.username);
            setRelationStatus('none');
        }
    } else {
        const newStatus = await relationshipService.followUser(userData.username);
        setRelationStatus(newStatus);
    }
  };

  const handleMessageClick = () => {
      const currentUserEmail = authService.getCurrentUserEmail();
      if (currentUserEmail && targetUserEmail) {
          const chatId = chatService.getPrivateChatId(currentUserEmail, targetUserEmail);
          navigate(`/chat/${chatId}`);
      }
  };

  const toggleBlockUser = () => {
      const action = isBlocked ? "desbloquear" : "bloquear";
      const confirmMessage = isBlocked 
        ? `Deseja desbloquear ${userData.username}?`
        : `Deseja bloquear ${userData.username}?`;

      if (window.confirm(confirmMessage)) {
          const newStatus = chatService.toggleBlockByContactName(userData.username);
          setIsBlocked(newStatus);
          setIsMenuOpen(false);
          
          if (newStatus) {
              relationshipService.unfollowUser(userData.username);
              setRelationStatus('none');
              alert(`${userData.username} foi bloqueado.`);
          } else {
              alert(`${userData.username} foi desbloqueado.`);
          }
      }
  };

  const handleCopyLink = () => {
      const url = window.location.href;
      navigator.clipboard.writeText(url).then(() => {
          alert('Link copiado!');
      });
      setIsMenuOpen(false);
  };

  const handleReport = () => {
      setIsMenuOpen(false);
      const reason = window.prompt("Motivo da denúncia:");
      if (reason) alert("Denúncia enviada.");
  };

  // Filtering Logic
  const textPosts = userPosts.filter(p => p.type === 'text' || p.type === 'poll');
  const photoPosts = userPosts.filter(p => p.type === 'photo');
  const reelPosts = userPosts.filter(p => p.type === 'video');

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-x-hidden">
        <style>{`
            header {
                display:flex; align-items:center; justify-content:space-between; padding:16px 32px;
                background: #0c0f14; position:fixed; width:100%; z-index:10; border-bottom:1px solid rgba(255,255,255,0.1);
                top: 0; height: 80px;
            }
            header button {
                background:none; border:none; color:#00c2ff; font-size:18px; cursor:pointer; transition:0.3s;
            }
            header button:hover { color:#fff; }

            #profileHeader {
                padding: 20px; display: flex; flex-direction: column; align-items: center; text-align: center;
                background: rgba(255,255,255,0.05); backdrop-filter: blur(5px); border-radius: 16px;
                margin: 20px; box-shadow: 0 4px 12px rgba(0,0,0,0.4);
            }
            .profile-avatar {
                width: 120px; height: 120px; border-radius: 50%; border: 4px solid #00c2ff;
                object-fit: cover; margin-bottom: 15px;
            }
            .profile-placeholder {
                width: 120px; height: 120px; border-radius: 50%; border: 4px solid #00c2ff;
                background: #333; display: flex; align-items: center; justify-content: center;
                margin-bottom: 15px; font-size: 50px; color: #555;
            }
            .profile-nickname { font-size: 24px; font-weight: 800; color: #fff; margin-bottom: 2px; text-transform: capitalize; }
            .profile-handle { font-size: 14px; color: #888; margin-bottom: 15px; font-weight: 600; }
            
            .profile-bio { font-size: 14px; color: rgba(255,255,255,0.7); max-width: 90%; margin-bottom: 15px; white-space: pre-wrap; }
            
            .profile-link {
                display: inline-flex; align-items: center; gap: 6px;
                color: #00c2ff; font-size: 14px; font-weight: 600;
                margin-bottom: 15px; text-decoration: none;
                background: rgba(0,194,255,0.1); padding: 6px 12px; border-radius: 20px;
                transition: 0.3s; border: 1px solid transparent;
            }
            .profile-link:hover {
                background: rgba(0,194,255,0.2); border-color: #00c2ff;
            }

            .profile-stats { display: flex; gap: 20px; margin-bottom: 15px; }
            
            .stat-item { display: flex; flex-direction: column; align-items: center; }
            .stat-count { font-size: 18px; font-weight: 700; color: #00c2ff; }
            .stat-label { font-size: 12px; color: rgba(255,255,255,0.5); }

            .profile-actions { display: flex; gap: 10px; width: 100%; justify-content: center; }
            .profile-actions button {
                flex-grow: 1; max-width: 150px; padding: 10px 15px; border: none; border-radius: 8px;
                font-weight: 600; cursor: pointer; transition: 0.3s;
            }
            #followButton { background: #00c2ff; color: #000; }
            #followButton:hover { background: #007bff; color: #fff; }
            #followButton.request-sent { background: transparent; color: #fff; border: 1px solid rgba(255,255,255,0.5); }
            #followButton.is-following { background: #1a1a1a; color: #00c2ff; border: 1px solid #00c2ff; }
            #messageButton { background: rgba(255,255,255,0.1); color: #00c2ff; border: 1px solid #00c2ff; }
            #messageButton:hover { background: #00c2ff; color: #000; }

            .status-message-container {
                text-align: center; padding: 50px 20px; margin-top: 30px;
                background: rgba(255,255,255,0.05); border-radius: 16px; border: 1px solid rgba(255,255,255,0.1);
            }
            .status-message-container i { font-size: 40px; color: #00c2ff; margin-bottom: 15px; }
            .status-message-container h2 { font-size: 20px; margin-bottom: 10px; }
            .status-message-container p { font-size: 14px; color: rgba(255,255,255,0.7); }
            .status-message-container.blocked i, .status-message-container.blocked h2 { color: #ff4d4d; }

            #profileNav {
                display: flex; justify-content: space-around; border-bottom: 1px solid rgba(255,255,255,0.1);
                margin-top: 20px; padding: 0 20px;
            }
            #profileNav button {
                background: none; border: none; padding: 10px 0; font-size: 16px; color: rgba(255,255,255,0.5);
                cursor: pointer; position: relative; transition: 0.3s; flex-grow: 1;
            }
            #profileNav button.active { color: #00c2ff; font-weight: 700; }
            #profileNav button.active::after {
                content: ''; position: absolute; bottom: -1px; left: 0; width: 100%; height: 3px;
                background: #00c2ff; border-radius: 2px 2px 0 0;
            }

            /* Dropdown Menu */
            .profile-dropdown {
                position: absolute; top: 60px; right: 20px; background: #1a1e26;
                border: 1px solid rgba(255,255,255,0.1); border-radius: 8px;
                box-shadow: 0 4px 15px rgba(0,0,0,0.5); z-index: 20; min-width: 180px;
                overflow: hidden; display: none;
            }
            .profile-dropdown.active { display: block; }
            .profile-dropdown button {
                display: block; width: 100%; padding: 12px 15px; text-align: left;
                background: none; border: none; color: #fff; font-size: 14px;
                cursor: pointer; transition: background 0.2s;
            }
            .profile-dropdown button:hover { background: rgba(0,194,255,0.1); color: #00c2ff; }
            .profile-dropdown button i { margin-right: 10px; width: 20px; text-align: center; }
            .profile-dropdown button.danger { color: #ff4d4d; }
            .profile-dropdown button.danger:hover { background: rgba(255,77,77,0.1); }

            /* FULL POST CARD STYLE (Used for Texts and Photos now) */
            .post-list { display: flex; flex-direction: column; gap: 15px; padding: 15px; width: 100%; }
            .post-card {
                background: #14171d; border-radius: 12px; padding: 15px;
                border: 1px solid rgba(255,255,255,0.05); cursor: pointer;
                box-shadow: 0 4px 10px rgba(0,0,0,0.3); margin-bottom: 10px;
            }
            .post-card-header { display: flex; align-items: center; gap: 10px; margin-bottom: 10px; }
            .post-card-avatar { width: 40px; height: 40px; border-radius: 50%; object-fit: cover; border: 2px solid #00c2ff; }
            .post-card-avatar-placeholder { width: 40px; height: 40px; border-radius: 50%; background: #1e2531; display: flex; align-items: center; justify-content: center; color: #00c2ff; font-size: 18px; border: 2px solid #00c2ff; }
            .post-card-info { display: flex; flex-direction: column; }
            .post-card-username { font-size: 14px; font-weight: 700; color: #fff; }
            .post-card-time { font-size: 12px; color: rgba(255,255,255,0.6); }
            
            .post-card-content { font-size: 15px; color: rgba(255,255,255,0.9); line-height: 1.4; margin-bottom: 10px; }
            .post-card-image { width: 100%; border-radius: 10px; margin-bottom: 10px; overflow: hidden; background: #000; display: flex; justify-content: center; }
            .post-card-image img { width: 100%; height: auto; max-height: 600px; object-fit: contain; display: block; }

            .post-card-actions {
                display: flex; justify-content: space-around; padding-top: 10px; border-top: 1px solid rgba(255,255,255,0.05);
            }
            .post-card-actions button {
                background: none; border: none; color: rgba(255,255,255,0.7); font-size: 14px; cursor: pointer; display: flex; align-items: center; gap: 6px;
            }
            .post-card-actions button:hover { color: #00c2ff; }

            /* REEL GRID ONLY */
            .reel-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 3px; padding: 3px; }
            .reel-item { position: relative; width: 100%; aspect-ratio: 9/16; cursor: pointer; background: #111; }
            .reel-thumbnail { width: 100%; height: 100%; object-fit: cover; display: block; }
            .reel-icon { position: absolute; top: 5px; right: 5px; color: white; background: rgba(0,0,0,0.5); padding: 3px; border-radius: 4px; font-size: 10px; }

            /* Hide Scrollbar for Carousel */
            .no-scrollbar::-webkit-scrollbar { display: none; }
            .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }

            /* Footer with Badges */
            footer {
                position:fixed; bottom:0; left:0; width:100%; background:#0c0f14;
                display:flex; justify-content:space-around; padding:14px 0;
                border-top-left-radius:20px; border-top-right-radius:20px; z-index:20;
                box-shadow:0 -2px 10px rgba(0,0,0,0.5);
            }
            footer button {
                background:none; border:none; color:#00c2ff; font-size:22px; cursor:pointer; transition:0.3s; padding:8px; border-radius:10px; position: relative;
            }
            footer button:hover { color:#fff; background:rgba(255,255,255,0.1); }
            
            .nav-badge {
                position: absolute; top: 2px; right: 2px;
                width: 10px; height: 10px; background: #ff4d4d;
                border-radius: 50%; border: 1px solid #0c0f14;
            }
            
            .empty-state { text-align: center; padding: 40px 0; color: #666; font-size: 14px; }
        `}</style>

        <header>
            <button onClick={handleBack}><i className="fa-solid fa-arrow-left"></i></button>
            
            {/* Standardized Logo */}
            <div 
                className="absolute left-1/2 -translate-x-1/2 w-[60px] h-[60px] bg-white/5 rounded-2xl flex justify-center items-center z-20 cursor-pointer shadow-[0_0_20px_rgba(0,194,255,0.3),inset_0_0_20px_rgba(0,194,255,0.08)]"
                onClick={() => navigate('/feed')}
            >
                 <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] rotate-[25deg]"></div>
                 <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] -rotate-[25deg]"></div>
            </div>
            
            <div style={{position: 'relative'}}>
                <button 
                    ref={menuButtonRef}
                    style={{marginLeft:'auto'}} 
                    onClick={() => setIsMenuOpen(!isMenuOpen)}
                >
                    <i className="fa-solid fa-ellipsis-vertical"></i>
                </button>
                <div ref={menuRef} className={`profile-dropdown ${isMenuOpen ? 'active' : ''}`}>
                    <button onClick={handleCopyLink}>
                        <i className="fa-solid fa-link"></i> Copiar Link
                    </button>
                    <button onClick={handleReport}>
                        <i className="fa-solid fa-flag"></i> Denunciar
                    </button>
                    <button className="danger" onClick={toggleBlockUser}>
                        <i className="fa-solid fa-ban"></i> {isBlocked ? 'Desbloquear' : 'Bloquear'}
                    </button>
                </div>
            </div>
        </header>

        <main className="flex-grow w-full max-w-[600px] mx-auto mt-20 pb-[100px]">
            <section id="profileHeader">
                {userData.avatar ? (
                    <img src={userData.avatar} className="profile-avatar" alt="Avatar" />
                ) : (
                    <div className="profile-placeholder">
                        <i className="fa-solid fa-user"></i>
                    </div>
                )}
                <span className="profile-nickname">{userData.nickname}</span>
                <span className="profile-handle">{userData.username}</span>
                
                {/* STATS - Visible only if allowed */}
                {(isContentVisible) && (
                    <div className="profile-stats">
                        <div className="stat-item"><span className="stat-count">{userData.stats.posts}</span><span className="stat-label">Posts</span></div>
                        <div className="stat-item"><span className="stat-count">{userData.stats.followers}</span><span className="stat-label">Seguidores</span></div>
                        <div className="stat-item"><span className="stat-count">{userData.stats.following}</span><span className="stat-label">Seguindo</span></div>
                    </div>
                )}

                {/* BIO - Visible only if allowed */}
                {(isContentVisible) && (
                    <p className="profile-bio">
                        {userData.bio}
                    </p>
                )}

                {/* Link/Website - Visible if allowed and exists */}
                {(isContentVisible && userData.website) && (
                    <a 
                        href={userData.website} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="profile-link"
                    >
                        <i className="fa-solid fa-link"></i> {userData.website.replace(/^https?:\/\//, '').replace(/\/$/, '')}
                    </a>
                )}

                {!isBlocked && !isMe && (
                    <div className="profile-actions">
                        <button 
                            id="followButton" 
                            className={isFollowing ? 'is-following' : (followRequestSent ? 'request-sent' : '')}
                            onClick={handleFollowClick}
                        >
                            {isFollowing ? 'Seguindo' : (followRequestSent ? 'Solicitado' : 'Seguir')}
                        </button>
                        
                        {/* Show message button if public OR if private and following */}
                        {canMessage && (
                            <button id="messageButton" onClick={handleMessageClick}>Mensagem</button>
                        )}
                    </div>
                )}
                
                {isMe && (
                    <div className="profile-actions">
                        <button onClick={() => navigate('/edit-profile')} style={{background: '#1e2531', color: '#fff', border:'1px solid #555'}}>Editar Perfil</button>
                    </div>
                )}
            </section>

            {isBlocked ? (
                <section>
                    <div className="status-message-container blocked">
                        <i className="fa-solid fa-ban"></i>
                        <h2>Você bloqueou este usuário</h2>
                        <p>Você não pode ver as publicações, mensagens ou informações de perfil.</p>
                        <button 
                            onClick={toggleBlockUser}
                            style={{marginTop: '20px', background: 'transparent', border: '1px solid #ff4d4d', color: '#ff4d4d', padding: '8px 16px', borderRadius: '8px', cursor: 'pointer'}}
                        >
                            Desbloquear
                        </button>
                    </div>
                </section>
            ) : !isContentVisible ? (
                <section>
                    <div className="status-message-container">
                        <i className="fa-solid fa-lock"></i>
                        <h2>Esta Conta é Privada</h2>
                        <p>Siga para ver os posts, reels e outras informações do perfil de {userData.nickname}.</p>
                    </div>
                </section>
            ) : (
                <>
                    <nav id="profileNav">
                        <button 
                            className={activeTab === 'posts' ? 'active' : ''}
                            onClick={() => setActiveTab('posts')}
                        >
                            <i className="fa-solid fa-list-ul"></i> Posts
                        </button>
                        <button 
                            className={activeTab === 'fotos' ? 'active' : ''}
                            onClick={() => setActiveTab('fotos')}
                        >
                            <i className="fa-solid fa-camera"></i> Fotos
                        </button>
                        <button 
                            className={activeTab === 'reels' ? 'active' : ''}
                            onClick={() => setActiveTab('reels')}
                        >
                            <i className="fa-solid fa-video"></i> Reels
                        </button>
                    </nav>

                    {/* POSTS TAB (Text List) */}
                    {activeTab === 'posts' && (
                        <div className="post-list">
                            {textPosts.length > 0 ? textPosts.map(post => (
                                <div key={post.id} className="post-card" onClick={() => navigate(`/post/${post.id}`)}>
                                    <div className="post-card-header">
                                        {userData.avatar ? (
                                            <img src={userData.avatar} className="post-card-avatar" alt="Av" />
                                        ) : (
                                            <div className="post-card-avatar-placeholder"><i className="fa-solid fa-user"></i></div>
                                        )}
                                        <div className="post-card-info">
                                            <span className="post-card-username">{userData.nickname}</span>
                                            <span className="post-card-time">{post.time}</span>
                                        </div>
                                    </div>
                                    <p className="post-card-content">{post.text}</p>
                                    <div className="post-card-actions">
                                        <button><i className="fa-regular fa-heart"></i> {post.likes}</button>
                                        <button><i className="fa-regular fa-comment"></i> {post.comments}</button>
                                        <button><i className="fa-solid fa-share"></i></button>
                                    </div>
                                </div>
                            )) : (
                                <div className="empty-state">Sem posts de texto.</div>
                            )}
                        </div>
                    )}

                    {/* FOTOS TAB (Full Feed Cards) */}
                    {activeTab === 'fotos' && (
                        <div className="post-list">
                            {photoPosts.length > 0 ? photoPosts.map((post) => (
                                <div key={post.id} className="post-card" onClick={() => navigate(`/post/${post.id}`)}>
                                    <div className="post-card-header">
                                        {userData.avatar ? (
                                            <img src={userData.avatar} className="post-card-avatar" alt="Av" />
                                        ) : (
                                            <div className="post-card-avatar-placeholder"><i className="fa-solid fa-user"></i></div>
                                        )}
                                        <div className="post-card-info">
                                            <span className="post-card-username">{userData.nickname}</span>
                                            <span className="post-card-time">{post.time}</span>
                                        </div>
                                    </div>
                                    
                                    <p className="post-card-content">
                                        {post.text}
                                    </p>

                                    {post.images && post.images.length > 1 ? (
                                        <ImageCarousel images={post.images} />
                                    ) : (
                                        <div className="post-card-image">
                                            <img src={post.image || post.images?.[0]} alt={`Post ${post.id}`} />
                                        </div>
                                    )}

                                    <div className="post-card-actions">
                                        <button><i className="fa-regular fa-heart"></i> {post.likes}</button>
                                        <button><i className="fa-regular fa-comment"></i> {post.comments}</button>
                                        <button><i className="fa-solid fa-share"></i></button>
                                    </div>
                                </div>
                            )) : (
                                <div className="empty-state">Sem fotos.</div>
                            )}
                        </div>
                    )}

                    {/* REELS TAB (Grid) */}
                    {activeTab === 'reels' && (
                        <div className="reel-grid">
                             {reelPosts.length > 0 ? reelPosts.map((post) => (
                                <div key={post.id} className="reel-item" onClick={() => navigate(`/post/${post.id}`)}>
                                    <video src={post.video} className="reel-thumbnail" muted />
                                    <div className="reel-icon">
                                        <i className="fa-solid fa-video"></i> {post.views}
                                    </div>
                                </div>
                            )) : (
                                <div className="empty-state" style={{gridColumn:'1/-1'}}>Sem reels.</div>
                            )}
                        </div>
                    )}
                </>
            )}
        </main>

        <footer>
            <button onClick={() => navigate('/feed')}><i className="fa-solid fa-newspaper"></i></button>
            <button onClick={() => navigate('/messages')}>
                <i className="fa-solid fa-comments"></i>
                {unreadMsgs > 0 && <div className="nav-badge"></div>}
            </button>
            <button onClick={() => navigate('/notifications')}>
                <i className="fa-solid fa-bell"></i>
                {unreadNotifs > 0 && <div className="nav-badge"></div>}
            </button>
            <button onClick={() => navigate('/profile')}><i className="fa-solid fa-user"></i></button>
        </footer>
    </div>
  );
};
