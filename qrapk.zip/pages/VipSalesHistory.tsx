
import React from 'react';
import { useNavigate } from 'react-router-dom';

export const VipSalesHistory: React.FC = () => {
  const navigate = useNavigate();

  // Mock Data
  const sales = [
      { id: 1, user: 'João Silva', date: '23/10/2023', amount: 'R$ 49,90', status: 'Aprovado' },
      { id: 2, user: 'Maria Souza', date: '22/10/2023', amount: 'R$ 49,90', status: 'Aprovado' },
      { id: 3, user: 'Pedro Rocha', date: '22/10/2023', amount: 'R$ 49,90', status: 'Pendente' },
  ];

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-x-hidden">
      <style>{`
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        
        header {
            display:flex; align-items:center; padding:16px;
            background: #0c0f14; position:fixed; width:100%; z-index:10;
            border-bottom:1px solid rgba(255,255,255,0.1); top: 0; height: 65px;
        }
        header button {
            background:none; border:none; color:#fff; font-size:24px; cursor:pointer;
            transition:0.3s; padding-right: 15px;
        }
        header h1 { font-size:20px; font-weight:600; }
        
        main {
            padding-top: 90px; padding-bottom: 40px;
            width: 100%; max-width: 600px; margin: 0 auto; padding-left: 20px; padding-right: 20px;
        }

        .sales-summary {
            background: rgba(255,215,0,0.1); border: 1px solid rgba(255,215,0,0.3);
            border-radius: 12px; padding: 20px; margin-bottom: 25px; text-align: center;
        }
        .total-label { font-size: 14px; color: #FFD700; text-transform: uppercase; letter-spacing: 1px; }
        .total-amount { font-size: 32px; font-weight: 800; color: #fff; margin-top: 5px; }

        .sale-item {
            background: rgba(255,255,255,0.05); border-radius: 10px; padding: 15px;
            margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center;
            border: 1px solid rgba(255,255,255,0.05);
        }
        .sale-info h3 { font-size: 16px; font-weight: 600; margin-bottom: 4px; }
        .sale-info p { font-size: 12px; color: #aaa; }
        .sale-value { text-align: right; }
        .amount { font-size: 16px; font-weight: 700; color: #00ff82; }
        .status { font-size: 12px; padding: 2px 6px; border-radius: 4px; background: rgba(255,255,255,0.1); display: inline-block; margin-top: 4px; }
        .status.pending { color: #ffaa00; background: rgba(255,170,0,0.1); }
        .status.approved { color: #00ff82; background: rgba(0,255,130,0.1); }
      `}</style>

      <header>
        <button onClick={() => navigate(-1)} aria-label="Voltar">
            <i className="fa-solid fa-arrow-left"></i>
        </button>
        <h1>Histórico de Vendas</h1>
      </header>

      <main>
        <div className="sales-summary">
            <div className="total-label">Total Faturado</div>
            <div className="total-amount">R$ 149,70</div>
        </div>

        <h3 style={{marginBottom: '15px', color: '#aaa', fontSize: '14px', textTransform: 'uppercase'}}>Últimas Transações</h3>

        {sales.map(sale => (
            <div key={sale.id} className="sale-item">
                <div className="sale-info">
                    <h3>{sale.user}</h3>
                    <p>{sale.date}</p>
                </div>
                <div className="sale-value">
                    <div className="amount">{sale.amount}</div>
                    <div className={`status ${sale.status === 'Pendente' ? 'pending' : 'approved'}`}>
                        {sale.status}
                    </div>
                </div>
            </div>
        ))}
      </main>
    </div>
  );
};
