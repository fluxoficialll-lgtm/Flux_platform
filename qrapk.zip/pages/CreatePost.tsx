
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { postService } from '../services/postService';
import { authService } from '../services/authService';
import { contentSafetyService } from '../services/contentSafetyService';
import { Post } from '../types';

interface MediaPreview {
  file: File; // The actual file to upload
  url: string; // The local preview URL
  type: 'image' | 'video';
}

// Mock Data for Locations
const LOCATIONS: any = {
    "Brasil": {
        "Ceará": ["Fortaleza", "Eusébio", "Aquiraz", "Sobral"],
        "São Paulo": ["São Paulo", "Campinas", "Santos", "Guarulhos"],
        "Rio de Janeiro": ["Rio de Janeiro", "Niterói", "Cabo Frio"],
        "Minas Gerais": ["Belo Horizonte", "Uberlândia", "Ouro Preto"]
    },
    "Estados Unidos": {
        "California": ["Los Angeles", "San Francisco", "San Diego"],
        "New York": ["New York City", "Buffalo"],
        "Florida": ["Miami", "Orlando"]
    },
    "Portugal": {
        "Lisboa": ["Lisboa", "Sintra", "Cascais"],
        "Porto": ["Porto", "Vila Nova de Gaia"]
    }
};

export const CreatePost: React.FC = () => {
  const navigate = useNavigate();
  const [text, setText] = useState('');
  const [mediaFiles, setMediaFiles] = useState<MediaPreview[]>([]); // Changed to store File objects
  const [isPublishDisabled, setIsPublishDisabled] = useState(true);
  const [isProcessing, setIsProcessing] = useState(false);

  // Sensitive Content State
  const [isAdultContent, setIsAdultContent] = useState(false);

  // Location State
  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [targetCountry, setTargetCountry] = useState('');
  const [targetState, setTargetState] = useState('');
  const [targetCity, setTargetCity] = useState('');
  const [displayLocation, setDisplayLocation] = useState('Global (Brasil)');

  const user = authService.getCurrentUser();
  const username = user?.profile?.name ? `@${user.profile.name}` : "@usuario";
  const avatarUrl = user?.profile?.photoUrl;

  useEffect(() => {
    const textLength = text.trim().length;
    const hasMedia = mediaFiles.length > 0;
    setIsPublishDisabled(!(textLength > 0 || hasMedia) || isProcessing);
  }, [text, mediaFiles, isProcessing]);

  const handleMediaChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files: File[] = event.target.files ? Array.from(event.target.files) : [];
    
    if (files.length > 0) {
      if (files.length + mediaFiles.length > 5) {
          alert("Você pode selecionar no máximo 5 arquivos no total.");
          return;
      }

      const newPreviews: MediaPreview[] = files.map(file => ({
          file: file,
          url: URL.createObjectURL(file), // Creates local preview URL
          type: file.type.startsWith('video/') ? 'video' : 'image'
      }));

      setMediaFiles(prev => [...prev, ...newPreviews]);
    }
  };

  const handleRemoveMedia = (index: number) => {
      setMediaFiles(prev => prev.filter((_, i) => i !== index));
  };

  // Location Handlers
  const handleCountryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      setTargetCountry(e.target.value);
      setTargetState('');
      setTargetCity('');
  };

  const handleStateChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
      setTargetState(e.target.value);
      setTargetCity('');
  };

  const saveLocation = () => {
      let loc = 'Global (Brasil)';
      if (targetCity) loc = `${targetCity}, ${targetState}`; 
      else if (targetState) loc = `${targetState}, Brasil`;
      else if (targetCountry) loc = targetCountry === 'Brasil' ? 'Global (Brasil)' : targetCountry;

      setDisplayLocation(loc);
      setIsLocationModalOpen(false);
  };

  const clearLocation = () => {
      setTargetCountry('');
      setTargetState('');
      setTargetCity('');
      setDisplayLocation('Global (Brasil)');
      setIsLocationModalOpen(false);
  };

  const handlePublishClick = async (e: React.MouseEvent) => {
    e.preventDefault();
    if (isPublishDisabled) return;
    
    setIsProcessing(true);

    try {
        // --- 1. UPLOAD MEDIA ---
        // Upload files one by one (or could be parallel)
        const uploadPromises = mediaFiles.map(m => postService.uploadMedia(m.file));
        const uploadedUrls = await Promise.all(uploadPromises);

        // --- 2. AUTO DETECTION (Safety) ---
        // Mock check for now, but passing URLs would be real implementation
        const analysis = await contentSafetyService.analyzeContent(text, uploadedUrls.map(u => ({ url: u })));
        let finalAdultStatus = isAdultContent;

        if (analysis.isAdult) {
            finalAdultStatus = true;
            alert(`⚠️ Aviso: Conteúdo sensível detectado. Marcado como +18.`);
        }

        const mainMediaUrl = uploadedUrls.length > 0 ? uploadedUrls[0] : undefined;
        const isVideo = mediaFiles.length > 0 && mediaFiles[0].type === 'video';

        const newPost: Post = {
          id: Date.now().toString(),
          type: isVideo ? 'video' : (uploadedUrls.length > 0 ? 'photo' : 'text'),
          username: username,
          avatar: avatarUrl,
          text: text,
          image: !isVideo ? mainMediaUrl : undefined,
          images: !isVideo && uploadedUrls.length > 0 ? uploadedUrls : undefined,
          video: isVideo ? mainMediaUrl : undefined,
          time: "Agora",
          timestamp: Date.now(),
          isPublic: true,
          isAdultContent: finalAdultStatus,
          views: 0,
          likes: 0,
          comments: 0,
          liked: false,
          location: displayLocation
        };

        await postService.addPost(newPost);
        navigate('/feed');
    } catch (error: any) {
        alert("Erro ao publicar: " + error.message);
    } finally {
        setIsProcessing(false);
    }
  };

  // Derived lists for dropdowns
  const countries = Object.keys(LOCATIONS);
  const states = targetCountry ? Object.keys(LOCATIONS[targetCountry] || {}) : [];
  const cities = (targetCountry && targetState) ? LOCATIONS[targetCountry][targetState] || [] : [];

  return (
    <div className="h-screen flex flex-col overflow-y-auto overflow-x-hidden font-['Inter']" style={{ background: 'radial-gradient(circle at 5% 5%, #0c0f14, #0a0c10)', color: '#fff' }}>
      {/* CSS Styles omitted for brevity, assumed same as before */}
      <style>{`
        /* Reuse existing styles */
        * { margin: 0; padding: 0; box-sizing: border-box; -webkit-font-smoothing: antialiased; }
        header.cp-header { display: flex; align-items: center; justify-content: space-between; padding: 16px 20px; background: #0c0f14; position: fixed; width: 100%; z-index: 50; border-bottom: 1px solid rgba(255, 255, 255, 0.1); top: 0; left: 0; }
        header.cp-header h1 { font-size: 18px; font-weight: 600; color: #00c2ff; }
        header.cp-header button.icon-btn { background: none; border: none; color: #00c2ff; font-size: 18px; cursor: pointer; padding: 8px; }
        #publishbtn { background: #00c2ff; color: #0c0f14; padding: 8px 16px; border-radius: 8px; font-weight: bold; font-size: 16px; border: none; cursor: pointer; }
        #publishbtn:disabled { background: rgba(0, 194, 255, 0.2); color: rgba(255, 255, 255, 0.5); cursor: not-allowed; }
        main.cp-main { flex-grow: 1; width: 100%; max-width: 600px; margin: 0 auto; padding: 100px 20px 40px 20px; }
        .post-creation-area { display: flex; gap: 15px; margin-bottom: 20px; background: rgba(255, 255, 255, 0.05); border-radius: 12px; padding: 15px; }
        .post-creation-area .avatar { width: 48px; height: 48px; border-radius: 50%; border: 3px solid #00c2ff; object-fit: cover; flex-shrink: 0; }
        .post-creation-area .avatar-placeholder { width: 48px; height: 48px; border-radius: 50%; border: 3px solid #00c2ff; background: #1e2531; flex-shrink: 0; display: flex; align-items: center; justify-content: center; color: #00c2ff; font-size: 20px; }
        .content-container { flex-grow: 1; overflow: hidden; }
        .text-input-container { flex-grow: 1; padding-bottom: 10px; }
        #posttext { width: 100%; min-height: 100px; background: none; border: none; resize: vertical; color: #fff; font-size: 16px; line-height: 1.4; padding: 10px 0; outline: none; }
        .icon-attachment-bar { display: flex; gap: 15px; padding-top: 10px; border-top: 1px solid rgba(255, 255, 255, 0.1); }
        .icon-attachment-bar button, .icon-attachment-bar label { background: none; border: none; color: #00c2ff; font-size: 20px; cursor: pointer; padding: 5px; }
        .icon-attachment-bar input[type="file"] { display: none; }
        #mediapreviewcontainer { margin-top: 15px; border: 1px dashed rgba(0,194,255,0.3); border-radius: 8px; padding: 10px; background: rgba(0,0,0,0.2); }
        .preview-gallery { display: flex; gap: 12px; overflow-x: auto; padding-bottom: 10px; }
        .media-wrapper { flex: 0 0 auto; height: 350px; min-width: 150px; position: relative; border-radius: 8px; overflow: hidden; border: 1px solid rgba(255,255,255,0.1); background: #000; display: flex; align-items: center; justify-content: center; }
        .media-preview-element { height: 100%; width: auto; max-width: 100%; object-fit: contain; }
        .video-badge { position: absolute; bottom: 5px; left: 5px; background: rgba(0,0,0,0.7); color: #fff; padding: 2px 6px; border-radius: 4px; font-size: 10px; }
        .remove-btn { position: absolute; top: 5px; right: 5px; background: rgba(0,0,0,0.6); color: #fff; border: none; border-radius: 50%; width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; cursor: pointer; }
        .options-container { display: flex; flex-direction: column; gap: 15px; }
        .option-item { background: rgba(255, 255, 255, 0.05); padding: 12px; border-radius: 10px; display: flex; justify-content: space-between; align-items: center; cursor: pointer; border: 1px solid transparent; }
        .option-item:hover { background: rgba(0, 194, 255, 0.15); border-color: #00c2ff; }
        .option-item span { font-size: 15px; color: #fff; }
        .option-item i { color: #00c2ff; }
        .server-selection { font-weight: bold; color: #00c2ff; margin-left: 10px; }
        .adult-toggle { display: flex; align-items: center; gap: 10px; }
        .switch { position: relative; display: inline-block; width: 40px; height: 22px; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #333; transition: .4s; border-radius: 22px; }
        .slider:before { position: absolute; content: ""; height: 16px; width: 16px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
        input:checked + .slider { background-color: #ff4d4d; }
        input:checked + .slider:before { transform: translateX(18px); }
        .location-modal-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.8); z-index: 50; display: flex; align-items: center; justify-content: center; }
        .location-modal { background: #1a1e26; border: 1px solid #00c2ff; border-radius: 16px; padding: 20px; width: 90%; max-width: 350px; }
        .modal-title { font-size: 18px; font-weight: 700; color: #fff; margin-bottom: 20px; text-align: center; }
        .select-group { margin-bottom: 15px; }
        .select-group label { display: block; font-size: 12px; color: #aaa; margin-bottom: 5px; }
        .select-group select { width: 100%; background: #0c0f14; border: 1px solid #333; color: #fff; padding: 10px; border-radius: 8px; outline: none; }
        .modal-actions { display: flex; gap: 10px; margin-top: 20px; }
        .modal-btn { flex: 1; padding: 10px; border-radius: 8px; border: none; font-weight: 700; cursor: pointer; }
        .save-loc-btn { background: #00c2ff; color: #000; }
        .clear-loc-btn { background: transparent; border: 1px solid #ff4d4d; color: #ff4d4d; }
      `}</style>

      <header className="cp-header">
        <button className="icon-btn" onClick={() => navigate('/feed')} aria-label="fechar" role="button">
          <i className="fa-solid fa-xmark"></i>
        </button>
        <h1>nova postagem</h1>
        <button id="publishbtn" disabled={isPublishDisabled} onClick={handlePublishClick}>
            {isProcessing ? <i className="fa-solid fa-circle-notch fa-spin"></i> : 'publicar'}
        </button>
      </header>

      <main className="cp-main">
        <form id="postform" onSubmit={(e) => e.preventDefault()}> 
          <div className="post-creation-area">
            {avatarUrl ? (
                <img src={avatarUrl} className="avatar" id="useravatar" alt="avatar do usuário" />
            ) : (
                <div className="avatar-placeholder">
                    <i className="fa-solid fa-user"></i>
                </div>
            )}
            
            <div className="content-container">
              <div className="text-input-container">
                <textarea 
                  id="posttext" 
                  placeholder="o que você está pensando? diga ao seu servidor..." 
                  maxLength={1000}
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                ></textarea>
              </div>

              <div className="icon-attachment-bar">
                <button type="button" onClick={() => alert('Ação: abrir a câmera para tirar foto.')} aria-label="abrir câmera">
                  <i className="fa-solid fa-camera"></i>
                </button>
                
                <label htmlFor="mediainput" aria-label="adicionar foto/vídeo">
                  <i className="fa-solid fa-image"></i>
                  <input 
                    type="file" 
                    id="mediainput" 
                    accept="image/*,video/*" 
                    multiple 
                    onChange={handleMediaChange} 
                  />
                </label>

                <button type="button" onClick={() => navigate('/create-poll')} aria-label="criar enquete">
                  <i className="fa-solid fa-square-poll-vertical"></i>
                </button>
              </div>

              {mediaFiles.length > 0 && (
                <div id="mediapreviewcontainer">
                  <div className="preview-gallery">
                    {mediaFiles.map((item, index) => (
                      <div key={index} className="media-wrapper">
                        {item.type === 'video' ? (
                          <>
                             <video src={item.url} className="media-preview-element" />
                             <div className="video-badge"><i className="fa-solid fa-video"></i></div>
                          </>
                        ) : (
                          <img src={item.url} alt={`preview ${index}`} className="media-preview-element" />
                        )}
                        <button className="remove-btn" onClick={() => handleRemoveMedia(index)}>
                            <i className="fa-solid fa-xmark"></i>
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          </div>

          <div className="options-container">
            <div className="option-item" role="button" onClick={() => navigate('/create-reel')} id="reels-option">
              <span>
                <i className="fa-solid fa-film reels-icon"></i> Postar Reels
              </span>
              <i className="fa-solid fa-chevron-right"></i>
            </div>
            
            <div className="option-item" onClick={() => setIsAdultContent(!isAdultContent)}>
                <span>
                    <i className="fa-solid fa-triangle-exclamation" style={{color: isAdultContent ? '#ff4d4d' : '#aaa'}}></i> Conteúdo Sensível (+18)
                </span>
                <div className="adult-toggle">
                    <label className="switch">
                        <input 
                            type="checkbox" 
                            checked={isAdultContent} 
                            onChange={() => setIsAdultContent(!isAdultContent)} 
                        />
                        <span className="slider"></span>
                    </label>
                </div>
            </div>

            <div className="option-item" role="button" onClick={() => setIsLocationModalOpen(true)}>
              <span>
                <i className="fa-solid fa-location-dot"></i> Alcance: 
                <span className="server-selection" id="currentaudience">{displayLocation}</span>
              </span>
              <i className="fa-solid fa-chevron-right"></i>
            </div>
          </div>
        </form>
      </main>

      {/* Location Modal */}
      {isLocationModalOpen && (
          <div className="location-modal-overlay" onClick={() => setIsLocationModalOpen(false)}>
              <div className="location-modal" onClick={(e) => e.stopPropagation()}>
                  <div className="modal-title">Definir Alcance do Post</div>
                  
                  <div className="select-group">
                      <label>País</label>
                      <select value={targetCountry} onChange={handleCountryChange}>
                          <option value="">Todos / Global</option>
                          {countries.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                  </div>

                  {targetCountry && (
                      <div className="select-group">
                          <label>Estado</label>
                          <select value={targetState} onChange={handleStateChange}>
                              <option value="">Todos do País</option>
                              {states.map((s: string) => <option key={s} value={s}>{s}</option>)}
                          </select>
                      </div>
                  )}

                  {targetState && (
                      <div className="select-group">
                          <label>Cidade</label>
                          <select value={targetCity} onChange={(e) => setTargetCity(e.target.value)}>
                              <option value="">Todas do Estado</option>
                              {cities.map((c: string) => <option key={c} value={c}>{c}</option>)}
                          </select>
                      </div>
                  )}

                  <div className="modal-actions">
                      <button className="modal-btn clear-loc-btn" onClick={clearLocation}>Global</button>
                      <button className="modal-btn save-loc-btn" onClick={saveLocation}>Salvar</button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};
