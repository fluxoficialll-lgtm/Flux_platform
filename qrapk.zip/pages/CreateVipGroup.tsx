
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { groupService } from '../services/groupService';
import { authService } from '../services/authService';
import { Group } from '../types';

export const CreateVipGroup: React.FC = () => {
  const navigate = useNavigate();
  
  // Form States
  const [groupName, setGroupName] = useState('');
  const [description, setDescription] = useState('');
  const [coverImage, setCoverImage] = useState<string | undefined>(undefined);
  
  // VIP Door States
  const [vipDoorImage, setVipDoorImage] = useState<string | undefined>(undefined);
  const [vipDoorText, setVipDoorText] = useState('');

  // Price & Access States
  const [price, setPrice] = useState('');
  const [currency, setCurrency] = useState<'BRL' | 'USD' | 'EUR' | 'BTC'>('BRL');
  const [accessType, setAccessType] = useState<'lifetime' | 'temporary'>('lifetime');
  const [expirationDate, setExpirationDate] = useState('');
  
  // Modal States
  const [isDateModalOpen, setIsDateModalOpen] = useState(false);

  useEffect(() => {
      // Check if user has payment provider connected
      const user = authService.getCurrentUser();
      if (!user?.paymentConfig?.isConnected) {
          alert("⚠️ Você precisa conectar sua conta SyncPay para criar um grupo VIP e receber pagamentos.");
          navigate('/financial/providers');
      }
  }, []);

  const handleCoverChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setCoverImage(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleVipDoorImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setVipDoorImage(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleAccessTypeChange = (type: 'lifetime' | 'temporary') => {
    setAccessType(type);
    if (type === 'temporary') {
      setIsDateModalOpen(true);
    } else {
      setExpirationDate('');
    }
  };

  const saveExpirationDate = () => {
    const dateInput = document.getElementById('expirationDate') as HTMLInputElement;
    if (dateInput && dateInput.value) {
      setExpirationDate(dateInput.value);
      setIsDateModalOpen(false);
      setAccessType('temporary');
    } else {
      alert('Por favor, selecione uma data.');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validate Minimum Price (R$ 6.00 due to Platform Fee)
    const numericPrice = parseFloat(price);
    if (isNaN(numericPrice) || numericPrice < 6.00) {
        alert("⚠️ O preço mínimo para criar um grupo VIP é R$ 6,00 (Taxa da plataforma: R$ 3,00).");
        return;
    }

    if (accessType === 'temporary' && !expirationDate) {
        alert("🚨 Por favor, defina a data de expiração para o acesso temporário.");
        setIsDateModalOpen(true);
        return;
    }

    const currentUserEmail = authService.getCurrentUserEmail();

    const newGroup: Group = {
      id: Date.now().toString(),
      name: groupName,
      description: description,
      coverImage: coverImage,
      isVip: true,
      price: price,
      currency: currency,
      accessType: accessType,
      expirationDate: expirationDate,
      vipDoor: {
        mediaItems: vipDoorImage ? [{ url: vipDoorImage, type: 'image' }] : [],
        text: vipDoorText || "Bem-vindo ao VIP!"
      },
      lastMessage: "Grupo criado. Configure os conteúdos.",
      time: "Agora",
      creatorEmail: currentUserEmail || undefined
    };

    groupService.createGroup(newGroup);
    
    alert("Grupo VIP criado com sucesso!");
    navigate('/groups');
  };

  const getCurrencySymbol = () => {
    switch (currency) {
      case 'USD': return '$';
      case 'EUR': return '€';
      case 'BTC': return '₿';
      default: return 'R$';
    }
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-x-hidden">
      <style>{`
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        
        header {
            display:flex; align-items:center; justify-content:space-between; padding:16px 32px;
            background: #0c0f14; position:fixed; width:100%; z-index:10; border-bottom:1px solid rgba(255,255,255,0.1);
            top: 0; height: 80px;
        }
        header button {
            background:none; border:none; color:#00c2ff; font-size:18px; cursor:pointer; transition:0.3s;
        }
        header button:hover { color:#fff; }

        main { flex-grow:1; display:flex; flex-direction:column; align-items:center; justify-content:flex-start; width:100%; padding-top: 100px; padding-bottom: 100px; }

        #groupCreationForm {
            width:100%; max-width:500px; padding:0 20px;
            display: flex; flex-direction: column; gap: 20px;
        }

        h1 {
            font-size: 24px; text-align: center; margin-bottom: 20px; 
            background: -webkit-linear-gradient(145deg, #FFD700, #B8860B); -webkit-background-clip: text; -webkit-text-fill-color: transparent;
            font-weight: 700;
        }

        /* COVER UPLOAD - ROUNDED */
        .cover-upload-container {
            display: flex; flex-direction: column; align-items: center; margin-bottom: 10px;
        }
        .cover-preview {
            width: 120px; height: 120px; border-radius: 50%;
            border: 3px solid #FFD700; background: rgba(255,255,255,0.05);
            display: flex; align-items: center; justify-content: center;
            overflow: hidden; position: relative; cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 0 20px rgba(255, 215, 0, 0.2);
        }
        .cover-preview:hover {
            border-color: #fff; box-shadow: 0 0 25px rgba(255, 215, 0, 0.4);
        }
        .cover-preview img {
            width: 100%; height: 100%; object-fit: cover;
        }
        .cover-icon {
            font-size: 40px; color: rgba(255,255,255,0.3);
        }
        .cover-label {
            margin-top: 10px; font-size: 14px; color: #FFD700; cursor: pointer; font-weight: 600;
        }

        .form-group { display: flex; flex-direction: column; }
        .form-group label { font-size: 14px; color: #FFD700; margin-bottom: 8px; font-weight: 600; }
        .form-group input, .form-group textarea {
            background: #1e2531; border: 1px solid rgba(255, 215, 0, 0.3); border-radius: 8px;
            color: #fff; padding: 12px; font-size: 16px; transition: border-color 0.3s;
        }
        .form-group input:focus, .form-group textarea:focus {
            border-color: #FFD700; outline: none; box-shadow: 0 0 5px rgba(255, 215, 0, 0.5);
        }
        .form-group textarea { resize: vertical; min-height: 100px; }

        /* VIP DOOR STYLES */
        .vip-door-section {
            border-top: 1px solid rgba(255,255,255,0.1);
            padding-top: 20px;
            margin-top: 10px;
        }
        .section-title {
            font-size: 16px; color: #FFD700; font-weight: 700; margin-bottom: 15px; display: flex; align-items: center; gap: 8px;
        }
        .vip-image-preview {
            width: 100%; 
            max-width: 260px; 
            aspect-ratio: 4 / 5;
            background: #1e2531; 
            border-radius: 12px; 
            border: 1px dashed rgba(255, 215, 0, 0.3); 
            display: flex; align-items: center; justify-content: center;
            cursor: pointer; overflow: hidden; position: relative; 
            margin: 0 auto 15px auto;
        }
        .vip-image-preview img { width: 100%; height: 100%; object-fit: cover; }
        .vip-image-preview i { font-size: 30px; color: rgba(255,255,255,0.3); }
        .vip-image-label {
            position: absolute; bottom: 10px; background: rgba(0,0,0,0.6); padding: 5px 10px; border-radius: 4px; font-size: 12px;
        }

        /* BUTTONS */
        .common-button {
            background: #FFD700; border: none; border-radius: 8px; color: #000;
            padding: 16px 20px; font-size: 18px; font-weight: 700; cursor: pointer;
            transition: background 0.3s, transform 0.1s; display: flex; align-items: center;
            justify-content: center; gap: 8px; box-shadow: 0 4px 8px rgba(255, 215, 0, 0.3);
            margin-top: 20px;
        }
        .common-button:hover { background: #e6c200; }
        .common-button:active { transform: scale(0.99); }

        /* PRICE & ACCESS */
        .price-group {
            display: flex; flex-direction: column; gap: 10px; padding-top: 20px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        .price-group label { font-size: 14px; color: #FFD700; font-weight: 600; }
        .price-input-container {
            display: flex; align-items: center; background: #1e2531;
            border: 1px solid rgba(255, 215, 0, 0.3); border-radius: 8px; overflow: hidden; margin-bottom: 5px; 
        }
        .price-input-container span {
            padding: 12px; background: #28303f; color: #aaa; font-size: 16px; font-weight: 700;
            min-width: 50px; text-align: center;
        }
        .price-input-container input {
            flex-grow: 1; border: none; background: none; padding: 12px; text-align: right;
            color: #fff; font-weight: 700; 
        }
        .fee-info { font-size: 11px; color: #aaa; margin-bottom: 15px; text-align: right; }

        .radio-group-container { display: flex; gap: 10px; margin-bottom: 15px; }
        .custom-radio {
            flex: 1; display: flex; align-items: center; justify-content: center;
            padding: 10px 15px; background: #1e2531; border: 1px solid rgba(255, 215, 0, 0.3);
            border-radius: 8px; color: #fff; cursor: pointer; transition: background 0.3s;
            font-size: 14px; font-weight: 600;
        }
        .custom-radio.selected { background: #FFD700; color: #000; }
        .custom-radio i { margin-right: 8px; }

        /* CURRENCY SELECTOR */
        .currency-selector {
            display: flex; gap: 8px; margin-bottom: 15px;
        }
        .currency-option {
            flex: 1;
            padding: 10px 5px;
            background: #1e2531;
            border: 1px solid rgba(255, 215, 0, 0.3);
            border-radius: 8px;
            color: #fff;
            cursor: pointer;
            text-align: center;
            font-size: 14px;
            font-weight: 600;
            transition: all 0.3s;
            display: flex;
            align-items: center; justify-content: center;
        }
        .currency-option.selected {
            background: #FFD700; color: #000; border-color: #FFD700;
        }

        /* Modal */
        .modal-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0, 0, 0, 0.8); display: flex; align-items: center; justify-content: center;
            z-index: 100;
        }
        .modal-content {
            background: #0c0f14; padding: 20px; border-radius: 16px; width: 90%; max-width: 350px;
            border: 1px solid #FFD700;
        }
        .date-modal input[type="date"] {
            background: #1e2531; border: 1px solid #FFD700;
            border-radius: 8px; color: #fff; padding: 12px; font-size: 16px; width: 100%;
        }
      `}</style>

      <header>
        <button onClick={() => navigate('/create-group')}><i className="fa-solid fa-xmark"></i></button>
        
        {/* Standardized Logo */}
        <div 
            className="absolute left-1/2 -translate-x-1/2 w-[60px] h-[60px] bg-white/5 rounded-2xl flex justify-center items-center z-20 cursor-pointer shadow-[0_0_20px_rgba(0,194,255,0.3),inset_0_0_20px_rgba(0,194,255,0.08)]"
            onClick={() => navigate('/feed')}
        >
             <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] rotate-[25deg]"></div>
             <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] -rotate-[25deg]"></div>
        </div>
      </header>

      <main>
        <form id="groupCreationForm" onSubmit={handleSubmit}>
            <h1>Novo Grupo VIP</h1>
            
            {/* 1. CAPA */}
            <div className="cover-upload-container">
                <label htmlFor="coverImageInput" className="cover-preview">
                    {coverImage ? (
                        <img src={coverImage} alt="Cover" />
                    ) : (
                        <i className="fa-solid fa-crown cover-icon"></i>
                    )}
                </label>
                <label htmlFor="coverImageInput" className="cover-label">Definir Capa</label>
                <input type="file" id="coverImageInput" accept="image/*" style={{display: 'none'}} onChange={handleCoverChange} />
            </div>

            {/* 2. NOME */}
            <div className="form-group">
                <label htmlFor="groupName">Nome do Grupo</label>
                <input 
                    type="text" 
                    id="groupName" 
                    value={groupName} 
                    onChange={(e) => setGroupName(e.target.value)} 
                    placeholder="Ex: Comunidade Flux Pro" 
                    required 
                />
            </div>
            
            {/* 3. DESCRIÇÃO */}
            <div className="form-group">
                <label htmlFor="groupDescription">Descrição</label>
                <textarea 
                    id="groupDescription" 
                    value={description} 
                    onChange={(e) => setDescription(e.target.value)} 
                    placeholder="Breve descrição do que os membros encontrarão."
                ></textarea>
            </div>

            {/* 4. VIP DOOR */}
            <div className="vip-door-section">
                <div className="section-title"><i className="fa-solid fa-door-open"></i> Porta do Grupo VIP</div>
                
                <div className="form-group">
                    <label>Foto de Capa da Porta</label>
                    <div className="vip-image-preview" onClick={() => document.getElementById('vipDoorImageInput')?.click()}>
                        {vipDoorImage ? (
                            <img src={vipDoorImage} alt="VIP Door" />
                        ) : (
                            <i className="fa-solid fa-image"></i>
                        )}
                        <div className="vip-image-label">Selecionar Imagem</div>
                    </div>
                    <input type="file" id="vipDoorImageInput" accept="image/*" style={{display:'none'}} onChange={handleVipDoorImageChange} />
                </div>

                <div className="form-group">
                    <label htmlFor="vipCopyright">Texto de Venda (Copyright)</label>
                    <textarea 
                        id="vipCopyright" 
                        value={vipDoorText} 
                        onChange={(e) => setVipDoorText(e.target.value)} 
                        placeholder="Escreva um texto persuasivo para vender o acesso ao grupo..."
                        style={{minHeight: '120px'}}
                    ></textarea>
                </div>
            </div>
            
            {/* 5. CONFIGURAÇÃO DE VENDA */}
            <div className="price-group">
                <label>Configuração de Venda (SyncPay)</label>
                
                <div className="radio-group-container">
                    <div className={`custom-radio ${accessType === 'lifetime' ? 'selected' : ''}`} onClick={() => handleAccessTypeChange('lifetime')}>
                        Vitalício
                    </div>
                    <div className={`custom-radio ${accessType === 'temporary' ? 'selected' : ''}`} onClick={() => handleAccessTypeChange('temporary')}>
                        Temporário
                    </div>
                </div>

                <div className="currency-selector">
                    <div className={`currency-option ${currency === 'BRL' ? 'selected' : ''}`} onClick={() => setCurrency('BRL')}>R$</div>
                </div>

                <div className="price-input-container">
                    <span>{getCurrencySymbol()}</span>
                    <input 
                        type="number" 
                        value={price} 
                        onChange={(e) => setPrice(e.target.value)} 
                        placeholder="0.00" 
                        step="0.01" 
                        min="6.00" 
                        required 
                    />
                </div>
                <div className="fee-info">
                    Taxa da plataforma: R$ 3,00 por venda. Mínimo: R$ 6,00.
                </div>
            </div>

            {/* 6. SALVAR */}
            <button type="submit" className="common-button">
                <i className="fa-solid fa-check"></i> Criar e Integrar
            </button>
        </form>
      </main>

      {/* EXPIRATION DATE MODAL */}
      {isDateModalOpen && (
          <div className="modal-overlay" onClick={() => setIsDateModalOpen(false)}>
            <div className="modal-content date-modal" onClick={(e) => e.stopPropagation()}>
                <h3 style={{color:'#FFD700', marginBottom:'15px', textAlign:'center'}}>Data de Expiração</h3>
                <input type="date" id="expirationDate" required />
                <button className="common-button" onClick={saveExpirationDate} style={{width:'100%', fontSize:'16px', padding:'10px'}}>
                    Confirmar
                </button>
            </div>
          </div>
      )}

    </div>
  );
};
