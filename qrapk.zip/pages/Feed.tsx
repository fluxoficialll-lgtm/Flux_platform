
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { authService } from '../services/authService';
import { postService } from '../services/postService';
import { recommendationService } from '../services/recommendationService';
import { notificationService } from '../services/notificationService';
import { chatService } from '../services/chatService';
import { Post, User, Story } from '../types';
import { db } from '@/database';

// --- Carousel Component ---
const ImageCarousel: React.FC<{ images: string[] }> = ({ images }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const scrollRef = useRef<HTMLDivElement>(null);

    const handleScroll = () => {
        if (scrollRef.current) {
            const scrollLeft = scrollRef.current.scrollLeft;
            const width = scrollRef.current.offsetWidth;
            const index = Math.round(scrollLeft / width);
            setCurrentIndex(index);
        }
    };

    return (
        <div className="relative w-full mb-2.5 overflow-hidden rounded-xl bg-black">
            {/* Counter */}
            <div className="absolute top-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded-full z-10 backdrop-blur-sm">
                {currentIndex + 1}/{images.length}
            </div>

            {/* Scroll Container */}
            <div 
                ref={scrollRef}
                className="flex overflow-x-auto snap-x snap-mandatory no-scrollbar w-full aspect-[4/5]"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                onScroll={handleScroll}
            >
                {images.map((img, idx) => (
                    <img 
                        key={idx} 
                        src={img} 
                        loading="lazy"
                        alt={`Slide ${idx}`} 
                        className="w-full h-full flex-shrink-0 snap-center object-cover" 
                    />
                ))}
            </div>

            {/* Dots */}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
                {images.map((_, idx) => (
                    <div 
                        key={idx} 
                        className={`w-1.5 h-1.5 rounded-full transition-all ${currentIndex === idx ? 'bg-[#00c2ff] scale-125' : 'bg-white/50'}`}
                    ></div>
                ))}
            </div>
        </div>
    );
};

// Helper Component to fetch real user data for a post
const PostHeader: React.FC<{ username: string, time: string, location?: string, isAdult?: boolean, onClick: () => void }> = ({ username, time, location, isAdult, onClick }) => {
    const [user, setUser] = useState<User | undefined>(undefined);

    useEffect(() => {
        // Fetch user data from DB based on username handle
        const u = authService.getUserByHandle(username);
        setUser(u);
    }, [username]);

    // Display logic: Nickname preferred, else Username
    const displayName = user?.profile?.nickname || user?.profile?.name || username;
    const displayAvatar = user?.profile?.photoUrl;

    return (
        <div className="flex items-center justify-between mb-2.5">
            <div className="flex items-center gap-3 cursor-pointer" onClick={onClick}>
                {displayAvatar ? (
                    <img src={displayAvatar} alt={displayName} loading="lazy" className="w-10 h-10 rounded-full border-2 border-[#00c2ff] object-cover" />
                ) : (
                    <div className="w-10 h-10 rounded-full border-2 border-[#00c2ff] bg-[#1e2531] flex items-center justify-center text-[#00c2ff]">
                        <i className="fa-solid fa-user"></i>
                    </div>
                )}
                <div className="flex flex-col">
                    <span className="font-semibold text-base hover:text-[#00c2ff] transition-colors flex items-center gap-2">
                        {displayName}
                        {isAdult && <span className="adult-badge">18+</span>}
                    </span>
                    <div className="flex flex-col">
                        <span className="text-xs text-[#aaa]">{time}</span>
                        {location && (
                            <span className="location-tag">
                                <i className="fa-solid fa-location-dot" style={{fontSize:'9px'}}></i> {location}
                            </span>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

// --- STORIES COMPONENT ---
const StoriesBar: React.FC = () => {
    const [stories, setStories] = useState<Story[]>([]);
    const [activeStory, setActiveStory] = useState<Story | null>(null);
    const [progress, setProgress] = useState(0);
    const storyTimer = useRef<any>(null);

    useEffect(() => {
        // Mock Stories Generation (Real implementation would fetch from DB/API)
        const currentUserEmail = authService.getCurrentUserEmail();
        
        // Filter out current user explicitly to ensure "Seu Story" never appears
        const users = authService.getAllUsers()
            .filter(u => u.email !== currentUserEmail)
            .slice(0, 5);
            
        const mockStories: Story[] = users.map(u => ({
            id: u.email, // Using email as ID for simplicity in mock
            username: u.profile?.name || 'user',
            userAvatar: u.profile?.photoUrl,
            mediaUrl: `https://picsum.photos/seed/${u.email}/400/800`, // Random vertical image
            type: 'image',
            timestamp: Date.now(),
            viewed: false
        }));
        
        setStories(mockStories);
    }, []);

    const openStory = (story: Story) => {
        setActiveStory(story);
        setProgress(0);
        
        // Mark as viewed visual logic
        setStories(prev => prev.map(s => s.id === story.id ? {...s, viewed: true} : s));
    };

    const closeStory = () => {
        setActiveStory(null);
        setProgress(0);
        clearInterval(storyTimer.current);
    };

    useEffect(() => {
        if (activeStory) {
            const duration = 5000; // 5s per story
            const interval = 50;
            const step = 100 / (duration / interval);

            storyTimer.current = setInterval(() => {
                setProgress(prev => {
                    if (prev >= 100) {
                        closeStory();
                        return 100;
                    }
                    return prev + step;
                });
            }, interval);
        }
        return () => clearInterval(storyTimer.current);
    }, [activeStory]);

    // Se não houver stories de amigos, não renderiza a barra (ou renderiza vazia, mas sem "Seu Story")
    if (stories.length === 0) return null;

    return (
        <>
            <div className="flex gap-4 overflow-x-auto w-full px-4 py-4 mb-2 scrollbar-hide">
                {/* REMOVIDO: Bolinha "Seu Story" / Adicionar Story */}
                
                {stories.map((story, idx) => (
                    <div key={idx} className="flex flex-col items-center gap-1 cursor-pointer flex-shrink-0" onClick={() => openStory(story)}>
                        <div className={`w-[68px] h-[68px] rounded-full p-[2px] ${story.viewed ? 'bg-gray-600' : 'bg-gradient-to-tr from-yellow-400 to-[#00c2ff]'}`}>
                            <div className="w-full h-full rounded-full border-[2px] border-[#0c0f14] overflow-hidden bg-black relative">
                                {story.userAvatar ? (
                                    <img src={story.userAvatar} className="w-full h-full object-cover" alt={story.username} />
                                ) : (
                                    <div className="w-full h-full flex items-center justify-center bg-[#1e2531] text-[#00c2ff]">
                                        <i className="fa-solid fa-user"></i>
                                    </div>
                                )}
                            </div>
                        </div>
                        <span className="text-xs text-gray-300 truncate w-16 text-center">{story.username}</span>
                    </div>
                ))}
            </div>

            {/* Fullscreen Story Viewer */}
            {activeStory && (
                <div className="fixed inset-0 z-50 bg-black flex flex-col">
                    <div className="h-1 bg-gray-700 w-full fixed top-0 z-50">
                        <div className="h-full bg-white transition-all duration-75 ease-linear" style={{ width: `${progress}%` }}></div>
                    </div>
                    
                    <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-50">
                        <div className="flex items-center gap-2">
                            <img src={activeStory.userAvatar || ''} className="w-8 h-8 rounded-full border border-white" />
                            <span className="font-bold text-sm text-white drop-shadow-md">{activeStory.username}</span>
                            <span className="text-xs text-gray-300 drop-shadow-md">• 2h</span>
                        </div>
                        <button onClick={closeStory} className="text-white text-2xl drop-shadow-md"><i className="fa-solid fa-xmark"></i></button>
                    </div>

                    <img src={activeStory.mediaUrl} className="w-full h-full object-cover" alt="Story" />
                    
                    <div className="absolute bottom-0 w-full p-4 bg-gradient-to-t from-black/80 to-transparent">
                        <div className="flex gap-2">
                            <input type="text" placeholder="Enviar mensagem..." className="flex-grow bg-transparent border border-white/50 rounded-full px-4 py-2 text-white placeholder-white/70 outline-none focus:border-white" />
                            <button className="text-white text-2xl"><i className="fa-regular fa-heart"></i></button>
                            <button className="text-white text-2xl"><i className="fa-regular fa-paper-plane"></i></button>
                        </div>
                    </div>
                </div>
            )}
        </>
    );
};

export const Feed: React.FC = () => {
  const navigate = useNavigate();
  const [posts, setPosts] = useState<Post[]>([]);
  const [activeTab, setActiveTab] = useState<'feed' | 'reels'>('feed');
  const [uiVisible, setUiVisible] = useState(true);
  const [activeLocationFilter, setActiveLocationFilter] = useState<string | null>(null);
  
  // Pagination States
  const [nextCursor, setNextCursor] = useState<number | undefined>(undefined);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const PAGE_SIZE = 10; 

  // Real-time Updates
  const [hasNewPosts, setHasNewPosts] = useState(false);
  const lastScrollY = useRef(0);
  
  // Notification Badges
  const [unreadNotifs, setUnreadNotifs] = useState(0);
  const [unreadMsgs, setUnreadMsgs] = useState(0);

  // View Counting Logic
  const observerRef = useRef<IntersectionObserver | null>(null);
  const viewedPosts = useRef<Set<string>>(new Set()); // Track viewed in this session (client-side opt)
  const postRefs = useRef<Map<string, HTMLDivElement>>(new Map());

  // Settings State
  const isAdultContentAllowed = localStorage.getItem('settings_18_plus') === 'true';

  // Initial check
  useEffect(() => {
    const userEmail = authService.getCurrentUserEmail();
    if (!userEmail) {
      navigate('/');
      return;
    }

    // Check for location filter
    const filter = localStorage.getItem('feed_location_filter');
    setActiveLocationFilter(filter);
  }, [navigate]);

  // Notification Badges Effect
  useEffect(() => {
      const updateCounts = () => {
          setUnreadNotifs(notificationService.getUnreadCount());
          setUnreadMsgs(chatService.getUnreadCount());
      };
      updateCounts();
      const unsubNotif = db.subscribe('notifications', updateCounts);
      const unsubChat = db.subscribe('chats', updateCounts);
      
      return () => { unsubNotif(); unsubChat(); };
  }, []);

  // Setup Intersection Observer for Views
  useEffect(() => {
      if (observerRef.current) observerRef.current.disconnect();

      observerRef.current = new IntersectionObserver((entries) => {
          entries.forEach(entry => {
              if (entry.isIntersecting) {
                  const postId = entry.target.getAttribute('data-post-id');
                  const currentUserEmail = authService.getCurrentUserEmail();
                  
                  if (postId && !viewedPosts.current.has(postId)) {
                      // Count view (Post Service handles unique check in DB)
                      if(currentUserEmail) {
                          postService.incrementView(postId, currentUserEmail);
                      }
                      viewedPosts.current.add(postId);
                      
                      // Update local state immediately for UI (Optimistic)
                      setPosts(prev => prev.map(p => {
                          // Only update visual count if we haven't already tracked it locally
                          // Ideally, we would check if user is in p.viewedBy, but that's heavy on render
                          if (p.id === postId) return { ...p, views: p.views + 1 };
                          return p;
                      }));
                  }
              }
          });
      }, {
          threshold: 0.5 // 50% visible to count as view
      });

      // Observe all current posts
      postRefs.current.forEach(el => observerRef.current?.observe(el));

      return () => observerRef.current?.disconnect();
  }, [posts]); // Re-run when posts change to attach to new elements

  // Fetch Posts Logic
  const fetchPosts = useCallback(async (cursor?: number, reset = false) => {
    if (loading) return;
    setLoading(true);
    
    try {
        const locationFilter = localStorage.getItem('feed_location_filter');
        
        const response = await postService.getFeedPaginated({
            limit: PAGE_SIZE,
            cursor: cursor,
            allowedTypes: ['text', 'photo', 'poll'],
            locationFilter: locationFilter,
            allowAdultContent: isAdultContentAllowed // Pass Safety Setting
        });
        
        const fetchedPosts = response.data;

        setPosts(prev => {
            if (reset) {
                return fetchedPosts;
            }
            // Deduplicate just in case
            const existingIds = new Set(prev.map(p => p.id));
            const uniqueNewPosts = fetchedPosts.filter(p => !existingIds.has(p.id));
            return [...prev, ...uniqueNewPosts];
        });

        setNextCursor(response.nextCursor);
        setHasMore(!!response.nextCursor);

    } catch (error) {
        console.error("Failed to fetch posts", error);
    } finally {
        setLoading(false);
    }
  }, [isAdultContentAllowed, loading]);

  // Handle Filter Change or Initial Load
  useEffect(() => {
      setPosts([]);
      setNextCursor(undefined);
      setHasMore(true);
      setHasNewPosts(false);
      viewedPosts.current.clear(); // Clear view cache on reload/filter change
      fetchPosts(undefined, true);
  }, [activeLocationFilter, isAdultContentAllowed]); 

  // --- REAL-TIME SUBSCRIPTION ---
  useEffect(() => {
      // Subscribe to 'posts' table changes
      const unsubscribe = db.subscribe('posts', () => {
          setHasNewPosts(true);
      });
      return () => unsubscribe();
  }, []);

  const handleLoadNewPosts = () => {
      setHasNewPosts(false);
      viewedPosts.current.clear();
      fetchPosts(undefined, true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // --- Scroll Handling ---
  useEffect(() => {
    const handleScroll = () => {
      const currentScroll = window.scrollY;
      
      // UI Hide/Show Logic
      if (currentScroll > lastScrollY.current && currentScroll > 80) {
        setUiVisible(false);
      } else {
        setUiVisible(true);
      }
      lastScrollY.current = currentScroll;

      // Infinite Scroll logic
      if (
          window.innerHeight + currentScroll >= document.body.offsetHeight - 300 &&
          !loading &&
          hasMore
      ) {
         fetchPosts(nextCursor);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [loading, hasMore, nextCursor, fetchPosts]);

  // --- Interactions ---

  const handleLike = (id: string) => {
    setPosts(prev => prev.map(post => {
      if (post.id === id) {
        const newLiked = !post.liked;
        return {
          ...post,
          liked: newLiked,
          likes: post.likes + (newLiked ? 1 : -1)
        };
      }
      return post;
    }));
    // Persist
    postService.toggleLike(id);
  };

  const handleVote = (postId: string, optionIndex: number) => {
    setPosts(prev => prev.map(post => {
        if (post.id === postId && post.pollOptions && post.votedOptionIndex == null) {
            const newOptions = [...post.pollOptions];
            newOptions[optionIndex].votes += 1;
            return {
                ...post,
                pollOptions: newOptions,
                votedOptionIndex: optionIndex
            };
        }
        return post;
    }));
  };

  const handleUserClick = (username: string) => {
    const cleanName = username.startsWith('@') ? username.substring(1) : username;
    navigate(`/user/${cleanName}`);
  };

  const handleShare = async (post: Post) => {
    const shareUrl = `${window.location.origin}/#/post/${post.id}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: `Post de ${post.username}`,
          text: post.text.substring(0, 100) + (post.text.length > 100 ? '...' : ''),
          url: shareUrl,
        });
      } catch (error) {
        console.log('Error sharing', error);
      }
    } else {
      try {
        await navigator.clipboard.writeText(shareUrl);
        alert('Link copiado para a área de transferência!');
      } catch (err) {
        console.error('Failed to copy: ', err);
        alert('Não foi possível compartilhar.');
      }
    }
  };

  const formatText = (text: string) => {
    return text.split(/(@\w+)/g).map((part, i) => 
      part.startsWith('@') ? (
        <span key={i} className="text-[#00c2ff] font-semibold cursor-pointer" onClick={(e) => { e.stopPropagation(); handleUserClick(part); }}>{part}</span>
      ) : (
        part
      )
    );
  };

  const getPercentage = (votes: number, total: number) => {
    if (total === 0) return 0;
    return Math.round((votes / total) * 100);
  };

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-x-hidden">
      <style>{`
        .poll-voted {
            background: #00c2ff !important;
            color: #0c0f14;
            font-weight: 700;
        }
        .poll-bar-transition {
            transition: width 0.5s ease-out;
        }
        .loading-spinner {
            display: flex;
            justify-content: center;
            padding: 20px;
            color: #00c2ff;
            font-size: 24px;
        }
        .location-tag {
            font-size: 11px;
            color: #00c2ff;
            display: flex; align-items: center; gap: 4px;
            margin-top: 2px;
        }
        .filter-banner {
            width: 100%;
            background: rgba(0, 194, 255, 0.1);
            color: #00c2ff;
            text-align: center;
            padding: 8px;
            font-size: 13px;
            font-weight: 600;
            border-bottom: 1px solid rgba(0,194,255,0.2);
            position: fixed;
            top: 80px;
            z-index: 9;
            backdrop-filter: blur(5px);
        }
        /* Hide Scrollbar for Carousel */
        .no-scrollbar::-webkit-scrollbar {
            display: none;
        }
        .no-scrollbar {
            -ms-overflow-style: none;  /* IE and Edge */
            scrollbar-width: none;  /* Firefox */
        }
        .scrollbar-hide::-webkit-scrollbar {
            display: none;
        }
        
        /* New Posts Pill */
        .new-posts-pill {
            position: fixed; top: 90px; left: 50%; transform: translateX(-50%);
            background: #00c2ff; color: #000; padding: 8px 16px;
            border-radius: 20px; font-weight: 700; font-size: 13px;
            cursor: pointer; z-index: 40; box-shadow: 0 4px 15px rgba(0, 194, 255, 0.4);
            display: flex; align-items: center; gap: 6px;
            animation: popIn 0.3s ease-out;
        }
        
        /* Footer Badge - Tighter positioning */
        .nav-badge {
            position: absolute; top: 2px; right: 2px;
            width: 10px; height: 10px; background: #ff4d4d;
            border-radius: 50%; border: 1px solid #0c0f14;
        }
        footer button { 
            position: relative; 
            background: none; border: none; 
            padding: 10px; 
            cursor: pointer;
            transition: color 0.3s;
        }

        .adult-badge {
            background: #ff4d4d; color: #fff; font-size: 9px; font-weight: bold;
            padding: 1px 5px; border-radius: 4px; margin-left: 6px;
            border: 1px solid rgba(255,255,255,0.2);
        }

        @keyframes popIn { from { transform: translateX(-50%) scale(0.8); opacity: 0; } to { transform: translateX(-50%) scale(1); opacity: 1; } }
      `}</style>

      {/* HEADER */}
      <header className="flex items-center justify-between p-[16px_32px] bg-[#0c0f14] fixed w-full z-10 border-b border-white/10 top-0 h-[80px]">
        <button onClick={() => navigate('/location-filter')} className="bg-none border-none text-[#00c2ff] text-lg cursor-pointer hover:text-white">
            <i className={`fa-solid ${activeLocationFilter ? 'fa-location-dot' : 'fa-globe'}`}></i>
        </button>
        
        {/* Logo */}
        <div 
            className="absolute left-1/2 -translate-x-1/2 w-[60px] h-[60px] bg-white/5 rounded-2xl flex justify-center items-center z-20 cursor-pointer shadow-[0_0_20px_rgba(0,194,255,0.3),inset_0_0_20px_rgba(0,194,255,0.08)]"
            onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}
        >
             <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] rotate-[25deg]"></div>
             <div className="absolute w-[40px] h-[22px] rounded-[50%] border-[3px] border-[#00c2ff] -rotate-[25deg]"></div>
        </div>
        
        <div className="w-[18px]"></div> 
      </header>

      {/* New Posts Button */}
      {hasNewPosts && (
          <button className="new-posts-pill" onClick={handleLoadNewPosts}>
              <i className="fa-solid fa-arrow-up"></i> Novas publicações
          </button>
      )}

      {activeLocationFilter && (
          <div className="filter-banner">
              <i className="fa-solid fa-location-dot mr-1"></i> Exibindo conteúdo de: {activeLocationFilter}
          </div>
      )}

      {/* VIEW BUTTONS */}
      <div 
        id="viewButtons" 
        className={`fixed left-1/2 -translate-x-1/2 z-30 bg-black/40 px-3 py-1.5 rounded-xl backdrop-blur-md shadow-lg flex gap-4 transition-all duration-300 ${uiVisible ? (activeLocationFilter ? 'top-[125px]' : 'top-[90px]') : '-top-[100px]'}`}
      >
        <button 
            className={`bg-none border border-[#00c2ff] rounded-lg text-[#00c2ff] px-4 py-1.5 cursor-pointer text-base transition-all ${activeTab === 'feed' ? 'bg-[#00c2ff] text-black' : 'hover:bg-[#00c2ff] hover:text-black'}`}
            onClick={() => setActiveTab('feed')}
        >
            Feed
        </button>
        <button 
            className={`bg-none border border-[#00c2ff] rounded-lg text-[#00c2ff] px-4 py-1.5 cursor-pointer text-base transition-all ${activeTab === 'reels' ? 'bg-[#00c2ff] text-black' : 'hover:bg-[#00c2ff] hover:text-black'}`}
            onClick={() => navigate('/reels')}
        >
            Reels
        </button>
      </div>

      {/* MAIN CONTENT */}
      <main className={`flex-grow flex flex-col items-center justify-start w-full mt-5 transition-all ${activeLocationFilter ? 'pt-[170px]' : 'pt-[140px]'} pb-[160px]`}>
        <div className="w-full max-w-[500px] px-0">
            
            {/* STORIES SECTION */}
            <StoriesBar />

            <div className="px-4">
                {posts.map((post) => (
                    <div 
                        key={post.id} 
                        ref={el => {
                            if(el) postRefs.current.set(post.id, el);
                            else postRefs.current.delete(post.id);
                        }}
                        data-post-id={post.id}
                        className="relative bg-white/5 backdrop-blur-md rounded-2xl p-4 mb-5 shadow-lg"
                    >
                        
                        {/* Post Header with Dynamic Real Data */}
                        <PostHeader 
                            username={post.username} 
                            time={post.time} 
                            location={activeLocationFilter ? post.location : undefined}
                            isAdult={post.isAdultContent}
                            onClick={() => handleUserClick(post.username)}
                        />

                        {/* Post Text */}
                        <p className="mb-2.5 text-[15px] leading-[1.4] whitespace-pre-wrap break-words">
                            {formatText(post.text)}
                        </p>

                        {/* Post Content (Photo or Carousel) */}
                        {post.type === 'photo' && (
                            <>
                                {post.images && post.images.length > 1 ? (
                                    <ImageCarousel images={post.images} />
                                ) : (
                                    post.image && (
                                        /* Single Image: Fully adaptive height */
                                        <img 
                                            src={post.image} 
                                            loading="lazy"
                                            alt="Post content" 
                                            className="w-full h-auto max-h-[800px] rounded-xl object-contain mb-2.5" 
                                        />
                                    )
                                )}
                            </>
                        )}

                        {/* Post Content (Poll) */}
                        {post.type === 'poll' && post.pollOptions && (
                            <div className="mt-2.5 mb-2.5 p-2.5 bg-[rgba(0,194,255,0.05)] rounded-lg">
                                {(() => {
                                    const totalVotes = post.pollOptions!.reduce((acc, curr) => acc + curr.votes, 0);
                                    return post.pollOptions!.map((option, idx) => {
                                        const pct = getPercentage(option.votes, totalVotes);
                                        const isVoted = post.votedOptionIndex === idx;
                                        
                                        return (
                                            <div 
                                                key={idx}
                                                onClick={() => handleVote(post.id, idx)}
                                                className={`relative mb-2 p-2.5 rounded-lg cursor-pointer overflow-hidden font-medium transition-colors ${isVoted ? 'poll-voted' : 'bg-[#1e2531] hover:bg-[#28303f]'}`}
                                            >
                                                <div 
                                                    className="absolute top-0 left-0 h-full bg-[#00c2ff] opacity-30 z-0 poll-bar-transition" 
                                                    style={{ width: `${pct}%` }}
                                                ></div>
                                                <div className="relative z-10 flex justify-between items-center">
                                                    <span>{option.text}</span>
                                                    <span>{pct}%</span>
                                                </div>
                                            </div>
                                        );
                                    });
                                })()}
                            </div>
                        )}

                        {/* Actions Bar */}
                        <div className="flex justify-between items-center mt-2.5">
                            <div className="flex gap-3 text-sm">
                                <button 
                                    onClick={() => handleLike(post.id)}
                                    className={`flex items-center gap-1.5 px-3 py-2 rounded-xl transition-all ${post.liked ? 'text-red-500 bg-[#00c2ff]/10' : 'text-[#00c2ff] bg-black/40 hover:bg-[#00c2ff] hover:text-black'}`}
                                >
                                    <i className={`${post.liked ? 'fa-solid' : 'fa-regular'} fa-heart`}></i>
                                    <span>{post.likes}</span>
                                </button>
                                
                                <button 
                                    onClick={() => navigate(`/post/${post.id}`)}
                                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-[#00c2ff] bg-black/40 hover:bg-[#00c2ff] hover:text-black transition-all"
                                >
                                    <i className="fa-regular fa-comment"></i> {post.comments}
                                </button>
                                
                                <button 
                                    onClick={() => handleShare(post)}
                                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-[#00c2ff] bg-black/40 hover:bg-[#00c2ff] hover:text-black transition-all"
                                >
                                    <i className="fa-solid fa-share"></i>
                                </button>
                            </div>
                            <div className="text-xs text-[#aaa] flex items-center gap-3">
                                <span><i className="fa-solid fa-eye"></i> {post.views}</span>
                            </div>
                        </div>

                    </div>
                ))}
            </div>

            {loading && (
                <div className="loading-spinner">
                    <i className="fa-solid fa-circle-notch fa-spin"></i>
                </div>
            )}

            {!hasMore && !loading && posts.length > 0 && (
                <div className="text-center text-gray-500 pb-10 text-sm">
                    Você chegou ao fim do feed.
                </div>
            )}
            
            {!loading && posts.length === 0 && (
                <div className="text-center text-gray-500 pb-10 text-sm flex flex-col items-center gap-2">
                    <i className="fa-solid fa-ban text-2xl"></i>
                    {activeLocationFilter ? `Nenhum post encontrado em "${activeLocationFilter}".` : "Nenhum post encontrado."}
                </div>
            )}
        </div>
      </main>

      {/* FAB (Post Button) */}
      <button 
        onClick={() => navigate('/create-post')} 
        className={`fixed bottom-[80px] right-[20px] w-[60px] h-[60px] bg-[#00c2ff] border-none rounded-full text-white text-[28px] cursor-pointer shadow-[0_4px_12px_rgba(0,194,255,0.3)] z-15 flex items-center justify-center hover:bg-[#007bff] transition-transform duration-300 ${uiVisible ? 'scale-100' : 'scale-0'}`}
      >
        <i className="fa-solid fa-plus"></i>
      </button>

      {/* FOOTER */}
      <footer className={`fixed bottom-0 left-0 w-full bg-[#0c0f14] flex justify-around py-3.5 rounded-t-2xl z-20 shadow-[0_-2px_10px_rgba(0,0,0,0.5)] transition-transform duration-300 ${uiVisible ? 'translate-y-0' : 'translate-y-full'}`}>
        <button 
            className="text-white text-[22px] cursor-pointer p-2 transition-all"
            onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}
        >
            <i className="fa-solid fa-newspaper"></i>
        </button>
        <button 
            onClick={() => navigate('/messages')}
            className="text-[#00c2ff] text-[22px] cursor-pointer p-2 transition-all"
        >
            <i className="fa-solid fa-comments"></i>
            {unreadMsgs > 0 && <div className="nav-badge"></div>}
        </button>
        <button 
            onClick={() => navigate('/notifications')}
            className="text-[#00c2ff] text-[22px] cursor-pointer p-2 transition-all"
        >
            <i className="fa-solid fa-bell"></i>
            {unreadNotifs > 0 && <div className="nav-badge"></div>}
        </button>
        <button 
            onClick={() => navigate('/profile')} 
            className="text-[#00c2ff] text-[22px] cursor-pointer p-2 transition-all"
        >
            <i className="fa-solid fa-user"></i>
        </button>
      </footer>

    </div>
  );
};
