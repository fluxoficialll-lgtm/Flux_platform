
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { postService } from '../services/postService';
import { authService } from '../services/authService';
import { notificationService } from '../services/notificationService';
import { chatService } from '../services/chatService';
import { Post, Comment, User } from '../types';
import { db } from '@/database';

// --- Carousel Component ---
const ImageCarousel: React.FC<{ images: string[] }> = ({ images }) => {
    const [currentIndex, setCurrentIndex] = useState(0);
    const scrollRef = useRef<HTMLDivElement>(null);

    const handleScroll = () => {
        if (scrollRef.current) {
            const scrollLeft = scrollRef.current.scrollLeft;
            const width = scrollRef.current.offsetWidth;
            const index = Math.round(scrollLeft / width);
            setCurrentIndex(index);
        }
    };

    return (
        <div className="relative w-full mb-2.5 overflow-hidden rounded-xl bg-black">
            {/* Counter */}
            <div className="absolute top-2 right-2 bg-black/60 text-white text-xs px-2 py-1 rounded-full z-10 backdrop-blur-sm">
                {currentIndex + 1}/{images.length}
            </div>

            {/* Scroll Container */}
            <div 
                ref={scrollRef}
                className="flex overflow-x-auto snap-x snap-mandatory no-scrollbar w-full aspect-[4/5]"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                onScroll={handleScroll}
            >
                {images.map((img, idx) => (
                    <img 
                        key={idx} 
                        src={img} 
                        alt={`Slide ${idx}`} 
                        className="w-full h-full flex-shrink-0 snap-center object-cover" 
                    />
                ))}
            </div>

            {/* Dots */}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
                {images.map((_, idx) => (
                    <div 
                        key={idx} 
                        className={`w-1.5 h-1.5 rounded-full transition-all ${currentIndex === idx ? 'bg-[#00c2ff] scale-125' : 'bg-white/50'}`}
                    ></div>
                ))}
            </div>
        </div>
    );
};

export const PostDetails: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [post, setPost] = useState<Post | null>(null);
  
  // Local state for interactions within this view
  const [isLiked, setIsLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(0);
  
  // Comments state
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  
  // Reply State
  const [replyingTo, setReplyingTo] = useState<{ id: string, username: string } | null>(null);

  // Mention System State
  const [mentionQuery, setMentionQuery] = useState<string | null>(null);
  const [mentionList, setMentionList] = useState<User[]>([]);
  const [allUsers, setAllUsers] = useState<User[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  // Get current user
  const currentUser = authService.getCurrentUser();
  const username = currentUser?.profile?.name ? `@${currentUser.profile.name}` : "Você";
  const userAvatar = currentUser?.profile?.photoUrl;

  // Notification Badges
  const [unreadNotifs, setUnreadNotifs] = useState(0);
  const [unreadMsgs, setUnreadMsgs] = useState(0);

  useEffect(() => {
    if (id) {
      const foundPost = postService.getPostById(id);
      if (foundPost) {
        setPost(foundPost);
        setIsLiked(foundPost.liked);
        setLikeCount(foundPost.likes);
        setComments(foundPost.commentsList || []);
      } else {
        alert("Post não encontrado");
        navigate('/feed');
      }
    }
    // Load users for mention list
    setAllUsers(authService.getAllUsers());
  }, [id, navigate]);

  // Notification Badges Effect
  useEffect(() => {
      const updateCounts = () => {
          setUnreadNotifs(notificationService.getUnreadCount());
          setUnreadMsgs(chatService.getUnreadCount());
      };
      updateCounts();
      const unsubNotif = db.subscribe('notifications', updateCounts);
      const unsubChat = db.subscribe('chats', updateCounts);
      
      return () => { unsubNotif(); unsubChat(); };
  }, []);

  // Handle Input with Mention Detection
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setNewComment(val);

      // Check for @ char at current cursor position
      const cursor = e.target.selectionStart || 0;
      const textBeforeCursor = val.slice(0, cursor);
      
      // Regex: look for @ followed by any characters, at end of string
      const match = textBeforeCursor.match(/@(\w*)$/);
      
      if (match) {
          const query = match[1].toLowerCase();
          setMentionQuery(query);
          
          // Filter users - search by nickname OR handle
          const filtered = allUsers.filter(u => {
              const handle = u.profile?.name?.toLowerCase() || '';
              const name = u.profile?.nickname?.toLowerCase() || '';
              return handle.includes(query) || name.includes(query);
          });
          setMentionList(filtered.slice(0, 5)); // Limit to 5 suggestions
      } else {
          setMentionQuery(null);
      }
  };

  const insertMention = (user: User) => {
      // Always insert handle for data consistency
      const handle = user.profile?.name || 'user';
      const cursor = inputRef.current?.selectionStart || 0;
      const text = newComment;
      
      // Find start of mention
      const start = text.lastIndexOf('@', cursor - 1);
      if (start === -1) return;

      const prefix = text.slice(0, start);
      const suffix = text.slice(cursor);
      
      const inserted = `${prefix}@${handle} ${suffix}`;
      
      setNewComment(inserted);
      setMentionQuery(null);
      
      // Restore focus
      setTimeout(() => {
          if(inputRef.current) {
              inputRef.current.focus();
              // Move cursor to end of inserted handle
              const newPos = start + handle.length + 2; // @ + handle + space
              inputRef.current.setSelectionRange(newPos, newPos);
          }
      }, 0);
  };

  const handleBack = () => {
    if (window.history.state && window.history.state.idx > 0) {
        navigate(-1);
    } else {
        navigate('/feed');
    }
  };

  const handleLike = () => {
    if (post) {
        const updatedPost = postService.toggleLike(post.id);
        if (updatedPost) {
            setPost(updatedPost);
            setIsLiked(updatedPost.liked);
            setLikeCount(updatedPost.likes);
        }
    }
  };

  const handleSend = () => {
    if (!newComment.trim() || !post) return;

    if (replyingTo) {
        // Send Reply
        const savedReply = postService.addReply(post.id, replyingTo.id, newComment.trim(), username, userAvatar);
        if (savedReply) {
            // Update local state
            setComments(prev => prev.map(c => {
                if (c.id === replyingTo.id) {
                    return {
                        ...c,
                        replies: [...(c.replies || []), savedReply]
                    };
                }
                return c;
            }));
            setNewComment('');
            setReplyingTo(null);
            setMentionQuery(null);
        }
    } else {
        // Send Comment
        const savedComment = postService.addComment(post.id, newComment.trim(), username, userAvatar);
        if (savedComment) {
            setComments(prev => [savedComment, ...prev]);
            setNewComment('');
            setMentionQuery(null);
        }
    }
  };

  const handleCommentLike = (commentId: string) => {
      if (!post) return;
      const success = postService.toggleCommentLike(post.id, commentId);
      if (success) {
          // Manual toggle for performance:
          const toggle = (list: Comment[]): Comment[] => {
              return list.map(c => {
                  if (c.id === commentId) {
                      const newLiked = !c.likedByMe;
                      return { ...c, likedByMe: newLiked, likes: (c.likes || 0) + (newLiked ? 1 : -1) };
                  }
                  if (c.replies) {
                      return { ...c, replies: toggle(c.replies) };
                  }
                  return c;
              });
          };
          setComments(prev => toggle(prev));
      }
  };

  const handleReplyClick = (comment: Comment) => {
      setReplyingTo({ id: comment.id, username: comment.username });
      inputRef.current?.focus();
  };

  const handleUserClick = (username: string) => {
      const cleanName = username.startsWith('@') ? username.substring(1) : username;
      navigate(`/user/${cleanName}`);
  };

  // Poll Logic
  const handleVote = (optionIndex: number) => {
    if (!post || !post.pollOptions || post.votedOptionIndex != null) return;

    const newOptions = [...post.pollOptions];
    newOptions[optionIndex].votes += 1;
    
    const updatedPost = {
        ...post,
        pollOptions: newOptions,
        votedOptionIndex: optionIndex
    };
    
    setPost(updatedPost);
  };

  const getPercentage = (votes: number, total: number) => {
    if (total === 0) return 0;
    return Math.round((votes / total) * 100);
  };

  // Text Formatting (Mentions)
  const formatText = (text: string) => {
    return text.split(/(@\w+)/g).map((part, i) => 
      part.startsWith('@') ? (
        <span key={i} className="text-[#00c2ff] font-semibold cursor-pointer" onClick={(e) => { e.stopPropagation(); handleUserClick(part); }}>{part}</span>
      ) : (
        part
      )
    );
  };

  // Helper to resolve display name
  // PRIORITY: Nickname > Name (@handle) > Username
  const getDisplayName = (usernameOrHandle: string) => {
      const user = authService.getUserByHandle(usernameOrHandle);
      // Fallback to handle if no nickname
      return user?.profile?.nickname || user?.profile?.name || usernameOrHandle;
  };

  if (!post) return <div>Carregando...</div>;

  const renderComment = (comment: Comment, isReply = false) => {
      const displayName = getDisplayName(comment.username);
      
      return (
      <div key={comment.id} className={`comment ${isReply ? 'reply' : ''}`}>
          {comment.avatar ? (
              <img 
                src={comment.avatar} 
                className="comment-avatar" 
                alt={displayName} 
                onClick={() => handleUserClick(comment.username)}
              />
          ) : (
              <div className="comment-avatar-placeholder" onClick={() => handleUserClick(comment.username)}>
                  <i className="fa-solid fa-user"></i>
              </div>
          )}
          <div className="comment-content">
              <div className="comment-header" onClick={() => handleUserClick(comment.username)}>
                  {displayName}
              </div>
              <p className="comment-text">{comment.text}</p>
              
              <div className="comment-footer">
                  <span className="comment-time">há 2h</span>
                  
                  <button className={`action-link ${comment.likedByMe ? 'liked' : ''}`} onClick={() => handleCommentLike(comment.id)}>
                      {comment.likedByMe ? <i className="fa-solid fa-heart"></i> : <i className="fa-regular fa-heart"></i>} 
                      {comment.likes && comment.likes > 0 && <span>{comment.likes}</span>}
                  </button>
                  
                  {!isReply && (
                      <button className="action-link" onClick={() => handleReplyClick(comment)}>
                          Responder
                      </button>
                  )}
              </div>

              {/* Render Replies */}
              {comment.replies && comment.replies.length > 0 && (
                  <div className="replies-list">
                      {comment.replies.map(reply => renderComment(reply, true))}
                  </div>
              )}
          </div>
      </div>
      );
  };

  return (
    <div className="min-h-screen flex flex-col font-['Inter']" style={{ background: 'radial-gradient(circle at top left, #0c0f14, #0a0c10)', color: '#fff' }}>
      <style>{`
        /* Estilos globais e resets */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }

        header {
            display:flex; align-items:center; justify-content:space-between; padding:16px 32px;
            background: #0c0f14; position:fixed; width:100%; z-index:10;
            border-bottom:1px solid rgba(255,255,255,0.1); top: 0; height: 80px;
        }
        header button { background:none; border:none; color:#00c2ff; font-size:18px; cursor:pointer; transition:0.3s; }
        header button:hover { color:#fff; }
        .header-title { font-size: 18px; font-weight: 600; color: #fff; }

        main { flex-grow:1; display:flex; flex-direction:column; align-items:center; width:100%; padding-top: 100px; padding-bottom: 100px; }
        #singlePostContent { width:100%; max-width:480px; padding: 0 16px; }

        .post { 
            position:relative; background: rgba(255,255,255,0.05); backdrop-filter: blur(12px); 
            border-radius: 16px; padding:16px; box-shadow:0 4px 15px rgba(0,0,0,0.5); margin-bottom: 20px;
        }
        .post-header { display:flex; align-items:center; gap:12px; margin-bottom:10px; }
        .post-header .avatar { width:40px; height:40px; border-radius:50%; border:2px solid #00c2ff; object-fit:cover; cursor:pointer; }
        .post-header .avatar-placeholder { width:40px; height:40px; border-radius:50%; border:2px solid #00c2ff; background: #1e2531; display: flex; align-items: center; justify-content: center; color: #00c2ff; cursor: pointer; }
        .post-header .username { font-weight:600; font-size:16px; cursor:pointer; }
        .post-text { margin-bottom:10px; font-size:15px; line-height:1.4; white-space: pre-wrap; }
        
        /* Post Image Style - Flexible Aspect Ratio */
        .post-image-container {
            width: 100%; 
            margin-bottom: 10px; 
            background: transparent; /* Transparent background */
            border-radius: 12px; 
            overflow: hidden;
            display: flex;
            justify-content: center;
        }
        .post-image { 
            width: 100%; 
            height: auto; 
            max-height: 800px; /* Increased to allow 9:16 fully */
            object-fit: contain; 
        }
        
        .post-actions { display:flex; justify-content:space-between; align-items:center; padding: 8px 0; border-top: 1px solid rgba(255,255,255,0.1); border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 15px; }
        .post-actions .action-group { display:flex; gap:16px; font-size:14px; }
        .post-actions button { background: none; border:none; color:#00c2ff; padding:6px 12px; border-radius:12px; cursor:pointer; transition:0.3s; display:flex; align-items:center; gap:6px; font-size: 14px; }
        .post-actions button:hover { background: rgba(0,194,255,0.2); }
        .post-actions .views { color: #aaa; font-size: 13px; display:flex; align-items:center; gap: 4px; }

        /* POLL STYLES */
        .poll-voted {
            background: #00c2ff !important;
            color: #0c0f14;
            font-weight: 700;
        }
        .poll-bar-transition {
            transition: width 0.5s ease-out;
        }

        /* COMENTÁRIOS */
        #commentsSection { margin-top: 20px; }
        
        .comment-input-wrapper {
            margin-bottom: 20px; background: rgba(0,0,0,0.2); border-radius: 10px; padding: 10px; position: relative;
        }
        .replying-banner {
            font-size: 12px; color: #aaa; margin-bottom: 5px; display: flex; justify-content: space-between;
        }
        .replying-banner button { background: none; border: none; color: #ff4d4d; cursor: pointer; font-size: 12px; }
        
        .comment-input-area { display:flex; gap: 10px; }
        .comment-input-area input { flex-grow: 1; padding: 10px; border: 1px solid #00c2ff; border-radius: 8px; background: #0c0f14; color: #fff; outline: none; }
        .comment-input-area button { background: #00c2ff; color: #000; border: none; padding: 10px 15px; border-radius: 8px; cursor: pointer; transition: 0.3s; }
        .comment-input-area button:hover { background: #007bff; }
        
        /* Mention List */
        .mention-list {
            position: absolute; bottom: 100%; left: 0; width: 100%;
            background: #1a1e26; border: 1px solid #00c2ff; border-radius: 8px;
            overflow: hidden; z-index: 20; box-shadow: 0 4px 15px rgba(0,0,0,0.5);
        }
        .mention-item {
            display: flex; align-items: center; padding: 10px; cursor: pointer; border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        .mention-item:hover { background: rgba(0,194,255,0.1); }
        .mention-avatar { width: 30px; height: 30px; border-radius: 50%; object-fit: cover; margin-right: 10px; border: 1px solid #00c2ff; }
        .mention-placeholder { width: 30px; height: 30px; border-radius: 50%; background: #333; display: flex; align-items: center; justify-content: center; margin-right: 10px; font-size: 12px; }
        .mention-info { display: flex; flex-direction: column; }
        .mention-name { font-size: 13px; font-weight: 600; color: #fff; }
        .mention-handle { font-size: 11px; color: #aaa; }

        .comment { 
            background: rgba(255,255,255,0.05); padding: 12px; border-radius: 12px; margin-bottom: 10px;
            display: flex; align-items: flex-start; gap: 12px;
        }
        .comment.reply {
            background: rgba(255,255,255,0.02); margin-top: 10px; border-left: 2px solid #333;
        }
        
        .comment-avatar { width: 36px; height: 36px; border-radius: 50%; object-fit: cover; border: 1px solid #00c2ff; cursor: pointer; flex-shrink: 0; }
        .comment-avatar-placeholder { width: 36px; height: 36px; border-radius: 50%; background: #333; border: 1px solid #00c2ff; display: flex; align-items: center; justify-content: center; color: #aaa; cursor: pointer; flex-shrink: 0; font-size: 12px; }
        .comment-content { display: flex; flex-direction: column; flex-grow: 1; }
        .comment-header { font-weight: 700; font-size: 14px; color: #fff; cursor: pointer; margin-bottom: 2px; }
        .comment-text { font-size: 14px; color: #ddd; line-height: 1.3; }
        
        .comment-footer { display: flex; align-items: center; gap: 15px; margin-top: 5px; font-size: 12px; color: #888; }
        .action-link { background: none; border: none; color: #888; cursor: pointer; display: flex; align-items: center; gap: 4px; padding: 0; font-size: 12px; font-weight: 600; }
        .action-link:hover { color: #ccc; }
        .action-link.liked { color: #ff4d4d; }
        .action-link.liked i { font-weight: 900; }

        .replies-list { width: 100%; }

        /* Hide Scrollbar for Carousel */
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }

        /* Updated Footer Badge Positioning */
        footer { position:fixed; bottom:0; left:0; width:100%; background:#0c0f14; display:flex; justify-content:space-around; padding:14px 0; border-top-left-radius:20px; border-top-right-radius:20px; z-index:20; box-shadow:0 -2px 10px rgba(0,0,0,0.5); }
        footer button { background:none; border:none; color:#00c2ff; font-size:22px; cursor:pointer; transition:0.3s; padding:8px; border-radius:10px; position: relative; }
        footer button:hover { color:#fff; background:rgba(255,255,255,0.1); }
        
        .nav-badge {
            position: absolute; top: 2px; right: 2px;
            width: 10px; height: 10px; background: #ff4d4d;
            border-radius: 50%; border: 1px solid #0c0f14;
        }

        .adult-badge {
            background: #ff4d4d; color: #fff; font-size: 9px; font-weight: bold;
            padding: 1px 5px; border-radius: 4px; margin-left: 6px;
            border: 1px solid rgba(255,255,255,0.2);
        }
      `}</style>

      <header>
        <button onClick={handleBack}><i className="fa-solid fa-arrow-left"></i></button>
        <span className="header-title">Visualizar Post</span>
        <button style={{visibility:'hidden'}}><i className="fa-solid fa-ellipsis-v"></i></button>
      </header>

      <main>
        <div id="singlePostContent">
          <div className="post" id="postItem">
            <div className="post-header">
              {post.avatar ? (
                  <img src={post.avatar} className="avatar" onClick={() => handleUserClick(post.username)} alt="Avatar" />
              ) : (
                  <div className="avatar-placeholder" onClick={() => handleUserClick(post.username)}>
                      <i className="fa-solid fa-user"></i>
                  </div>
              )}
              <span className="username" onClick={() => handleUserClick(post.username)}>
                  {getDisplayName(post.username)}
                  {post.isAdultContent && <span className="adult-badge">18+</span>}
              </span>
            </div>
            
            <p className="post-text">
                {formatText(post.text)}
            </p>
            
            {/* Carousel Logic */}
            {post.type === 'photo' && (
                <>
                    {post.images && post.images.length > 1 ? (
                        <ImageCarousel images={post.images} />
                    ) : (
                        post.image && (
                            /* Full Adaptive Image */
                            <div className="post-image-container">
                                <img src={post.image} className="post-image" alt="Content" />
                            </div>
                        )
                    )}
                </>
            )}

            {/* Video Logic */}
            {post.type === 'video' && post.video && (
                 <video src={post.video} controls className="post-image" style={{maxHeight: '700px'}} />
            )}

            {/* Poll Logic */}
            {post.type === 'poll' && post.pollOptions && (
                <div className="mt-2.5 mb-2.5 p-2.5 bg-[rgba(0,194,255,0.05)] rounded-lg">
                    {(() => {
                        const totalVotes = post.pollOptions!.reduce((acc, curr) => acc + curr.votes, 0);
                        return post.pollOptions!.map((option, idx) => {
                            const pct = getPercentage(option.votes, totalVotes);
                            const isVoted = post.votedOptionIndex === idx;
                            
                            return (
                                <div 
                                    key={idx}
                                    onClick={() => handleVote(idx)}
                                    className={`relative mb-2 p-2.5 rounded-lg cursor-pointer overflow-hidden font-medium transition-colors ${isVoted ? 'poll-voted' : 'bg-[#1e2531] hover:bg-[#28303f]'}`}
                                >
                                    <div 
                                        className="absolute top-0 left-0 h-full bg-[#00c2ff] opacity-30 z-0 poll-bar-transition" 
                                        style={{ width: `${pct}%` }}
                                    ></div>
                                    <div className="relative z-10 flex justify-between items-center">
                                        <span>{option.text}</span>
                                        <span>{pct}%</span>
                                    </div>
                                </div>
                            );
                        });
                    })()}
                </div>
            )}
            
            <div className="post-actions">
              <div className="action-group">
                <button className="like-btn" onClick={handleLike}>
                    <i className={isLiked ? "fa-solid fa-heart" : "fa-regular fa-heart"} style={{color: isLiked ? 'red' : '#00c2ff'}}></i> 
                    <span>{likeCount}</span>
                </button>
                <button onClick={() => inputRef.current?.focus()}>
                    <i className="fa-regular fa-comment"></i> 
                    <span>{comments.length}</span>
                </button>
                <button><i className="fa-solid fa-share"></i></button>
              </div>
              <div className="views">
                <i className="fa-solid fa-eye"></i> <span>{post.views}</span> Visualizações
              </div>
            </div>
          </div>

          <div id="commentsSection">
            <h2>Comentários</h2>
            
            <div className="comment-input-wrapper">
                {/* Mention List Overlay */}
                {mentionQuery !== null && mentionList.length > 0 && (
                    <div className="mention-list">
                        {mentionList.map(u => (
                            <div key={u.email} className="mention-item" onClick={() => insertMention(u)}>
                                {u.profile?.photoUrl ? (
                                    <img src={u.profile.photoUrl} className="mention-avatar" />
                                ) : (
                                    <div className="mention-placeholder"><i className="fa-solid fa-user"></i></div>
                                )}
                                <div className="mention-info">
                                    <span className="mention-name">{u.profile?.nickname || u.profile?.name}</span>
                                    <span className="mention-handle">@{u.profile?.name}</span>
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {replyingTo && (
                    <div className="replying-banner">
                        <span>Respondendo a {replyingTo.username}</span>
                        <button onClick={() => setReplyingTo(null)}>Cancelar</button>
                    </div>
                )}
                <div className="comment-input-area">
                  <input 
                    ref={inputRef}
                    type="text" 
                    id="commentInput" 
                    placeholder={replyingTo ? "Escreva sua resposta..." : "Adicione um comentário..."}
                    value={newComment}
                    onChange={handleInputChange}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  />
                  <button id="sendCommentBtn" onClick={handleSend}><i className="fa-solid fa-paper-plane"></i></button>
                </div>
            </div>

            <div id="commentsList">
              {comments.length > 0 ? comments.map(comment => renderComment(comment)) : (
                  <div className="text-gray-500 text-sm text-center py-4">Seja o primeiro a comentar!</div>
              )}
            </div>
          </div>

        </div>
      </main>

      <footer>
        <button onClick={() => navigate('/feed')}><i className="fa-solid fa-newspaper"></i></button>
        <button onClick={() => navigate('/messages')}>
            <i className="fa-solid fa-comments"></i>
            {unreadMsgs > 0 && <div className="nav-badge"></div>}
        </button>
        <button onClick={() => navigate('/notifications')}>
            <i className="fa-solid fa-bell"></i>
            {unreadNotifs > 0 && <div className="nav-badge"></div>}
        </button>
        <button onClick={() => navigate('/profile')}><i className="fa-solid fa-user"></i></button>
      </footer>
    </div>
  );
};
