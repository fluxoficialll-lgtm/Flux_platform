
import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { groupService } from '../services/groupService';
import { authService } from '../services/authService';
import { Group } from '../types';

type TabType = 'geral' | 'membros' | 'regras' | 'acoes';

export const GroupSettings: React.FC = () => {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [group, setGroup] = useState<Group | undefined>(undefined);
  const [activeTab, setActiveTab] = useState<TabType>('geral');
  const [isAdmin, setIsAdmin] = useState(false);
  
  // Form States (Geral)
  const [editName, setEditName] = useState('');
  const [editDesc, setEditDesc] = useState('');
  const [coverPreview, setCoverPreview] = useState<string | undefined>(undefined);

  // Members State
  const [members, setMembers] = useState<{ id: string, name: string, role: string, isMe: boolean, avatar?: string }[]>([]);
  const [memberSearch, setMemberSearch] = useState('');

  // Permissions State (Regras)
  const [settings, setSettings] = useState({
      onlyAdminsPost: false,
      approveMembers: false,
      notifications: true
  });

  useEffect(() => {
      if (id) {
          const foundGroup = groupService.getGroupById(id);
          if (foundGroup) {
              setGroup(foundGroup);
              setEditName(foundGroup.name);
              setEditDesc(foundGroup.description);
              setCoverPreview(foundGroup.coverImage);
              
              const email = authService.getCurrentUserEmail();
              setIsAdmin(foundGroup.creatorEmail === email);
              
              // Load Settings
              setSettings({
                  onlyAdminsPost: foundGroup.settings?.onlyAdminsPost || false,
                  approveMembers: foundGroup.settings?.approveMembers || false,
                  notifications: true // Local state mostly
              });

              // Load members
              const rawMembers = groupService.getGroupMembers(id);
              const mappedMembers = rawMembers.map(u => ({
                  id: u.email,
                  name: u.profile?.nickname || u.profile?.name || 'Membro',
                  role: u.email === foundGroup.creatorEmail ? 'Admin' : 'Membro',
                  isMe: u.email === email,
                  avatar: u.profile?.photoUrl
              }));
              setMembers(mappedMembers);
          } else {
              navigate('/groups');
          }
      }
  }, [id, navigate]);

  const handleCoverChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => setCoverPreview(ev.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSaveGeneral = () => {
      if (!group) return;
      const updatedGroup = { ...group, name: editName, description: editDesc, coverImage: editPreview };
      groupService.updateGroup(updatedGroup);
      alert('Informações salvas com sucesso!');
  };

  const editPreview = coverPreview; // Alias for clean usage

  const handleToggleSetting = (key: string) => {
      if (!group) return;
      const newSettings = { ...settings, [key]: !settings[key as keyof typeof settings] };
      setSettings(newSettings);

      // Persist immediately for settings
      if (key !== 'notifications') {
          const updatedGroup = {
              ...group,
              settings: {
                  ...group.settings,
                  [key]: newSettings[key as keyof typeof settings]
              }
          };
          groupService.updateGroup(updatedGroup);
      }
  };

  const handleRemoveMember = (memberId: string) => {
      if (!group) return;
      if(window.confirm('Remover este membro do grupo?')) {
          groupService.removeMember(group.id, memberId);
          setMembers(prev => prev.filter(m => m.id !== memberId));
      }
  };

  const handleDeleteGroup = () => {
      if(window.confirm('ATENÇÃO: Esta ação é irreversível. Apagar grupo?')) {
          if(id) groupService.deleteGroup(id);
          navigate('/groups');
      }
  };

  if (!group) return <div className="min-h-screen bg-[#0c0f14] flex items-center justify-center text-white">Carregando...</div>;

  const filteredMembers = members.filter(m => m.name.toLowerCase().includes(memberSearch.toLowerCase()));

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_top_left,_#0c0f14,_#0a0c10)] text-white font-['Inter'] flex flex-col overflow-hidden">
        <style>{`
            /* CSS Reset & Base */
            * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter', sans-serif; }
            
            /* Header */
            header {
                display:flex; align-items:center; padding:16px;
                background: #0c0f14; position:fixed; width:100%; top:0; z-index:20;
                border-bottom:1px solid rgba(255,255,255,0.1); height: 65px;
            }
            header button { background:none; border:none; color:#00c2ff; font-size:20px; cursor:pointer; padding-right: 15px; }
            header h1 { font-size:18px; font-weight:600; color: #fff; }

            /* Tabs */
            .tabs-container {
                position: fixed; top: 65px; width: 100%; background: #0c0f14; z-index: 15;
                display: flex; border-bottom: 1px solid rgba(255,255,255,0.1);
            }
            .tab-btn {
                flex: 1; padding: 14px 0; text-align: center; font-size: 13px; font-weight: 600;
                color: #888; cursor: pointer; transition: 0.3s; position: relative;
                background: none; border: none; text-transform: uppercase; letter-spacing: 0.5px;
            }
            .tab-btn.active { color: #00c2ff; }
            .tab-btn.active::after {
                content: ''; position: absolute; bottom: -1px; left: 0; width: 100%; height: 2px; background: #00c2ff;
            }

            /* Main Content */
            main {
                padding-top: 130px; padding-bottom: 40px; width: 100%; max-width: 600px; 
                margin: 0 auto; padding-left: 20px; padding-right: 20px;
                overflow-y: auto; flex-grow: 1;
            }

            /* Cards & Inputs */
            .card {
                background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.05);
                border-radius: 12px; padding: 20px; margin-bottom: 20px;
            }
            
            .input-group { margin-bottom: 15px; }
            .input-label { font-size: 12px; color: #00c2ff; margin-bottom: 6px; display: block; font-weight: 600; }
            .input-field {
                width: 100%; background: #14171d; border: 1px solid rgba(255,255,255,0.1);
                border-radius: 8px; padding: 12px; color: #fff; font-size: 14px; outline: none;
                transition: border-color 0.2s;
            }
            .input-field:focus { border-color: #00c2ff; }
            textarea.input-field { resize: vertical; min-height: 100px; }

            /* Cover Image */
            .cover-wrapper {
                position: relative; width: 100px; height: 100px; margin: 0 auto 20px auto;
            }
            .cover-img {
                width: 100%; height: 100%; object-fit: cover; border-radius: 50%;
                border: 2px solid #00c2ff; cursor: pointer;
            }
            .cover-edit-badge {
                position: absolute; bottom: 0; right: 0; background: #00c2ff; color: #000;
                width: 28px; height: 28px; border-radius: 50%; display: flex; 
                align-items: center; justify-content: center; font-size: 14px;
                border: 2px solid #0c0f14; pointer-events: none;
            }

            /* Toggles (Regras) */
            .toggle-row {
                display: flex; align-items: center; justify-content: space-between;
                padding: 15px 0; border-bottom: 1px solid rgba(255,255,255,0.05);
            }
            .toggle-row:last-child { border-bottom: none; }
            .toggle-label h4 { font-size: 15px; font-weight: 500; color: #fff; }
            .toggle-label p { font-size: 12px; color: #888; margin-top: 2px; }

            /* Switch */
            .switch { position: relative; display: inline-block; width: 40px; height: 22px; flex-shrink: 0; }
            .switch input { opacity: 0; width: 0; height: 0; }
            .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #333; transition: .4s; border-radius: 22px; }
            .slider:before { position: absolute; content: ""; height: 16px; width: 16px; left: 3px; bottom: 3px; background-color: white; transition: .4s; border-radius: 50%; }
            input:checked + .slider { background-color: #00c2ff; }
            input:checked + .slider:before { transform: translateX(18px); }

            /* Member List */
            .search-bar { margin-bottom: 15px; position: relative; }
            .search-bar i { position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #666; font-size: 14px; }
            .search-bar input { padding-left: 35px; }

            .member-item {
                display: flex; align-items: center; padding: 12px 0; 
                border-bottom: 1px solid rgba(255,255,255,0.05);
            }
            .member-avatar {
                width: 40px; height: 40px; border-radius: 50%; background: #222;
                display: flex; align-items: center; justify-content: center; 
                margin-right: 12px; object-fit: cover; border: 1px solid #333;
            }
            .member-info { flex-grow: 1; }
            .member-name { font-size: 14px; font-weight: 500; color: #fff; }
            .member-role { font-size: 11px; color: #00c2ff; background: rgba(0,194,255,0.1); padding: 2px 6px; border-radius: 4px; margin-left: 6px; }
            
            .btn-action {
                padding: 6px 12px; border-radius: 6px; font-size: 12px; cursor: pointer; border: none; transition: 0.2s;
            }
            .btn-remove { background: rgba(255, 77, 77, 0.1); color: #ff4d4d; }
            .btn-remove:hover { background: rgba(255, 77, 77, 0.2); }

            /* Danger Zone */
            .danger-btn {
                width: 100%; padding: 15px; background: rgba(255, 77, 77, 0.05);
                border: 1px solid rgba(255, 77, 77, 0.3); color: #ff4d4d;
                border-radius: 10px; font-weight: 600; cursor: pointer;
                display: flex; align-items: center; justify-content: center; gap: 10px;
                transition: 0.2s;
            }
            .danger-btn:hover { background: rgba(255, 77, 77, 0.15); }

            .save-btn {
                width: 100%; padding: 14px; background: #00c2ff; color: #000;
                border: none; border-radius: 10px; font-weight: 700; margin-top: 10px;
                cursor: pointer; transition: 0.2s;
            }
            .save-btn:hover { background: #0099cc; }
            
            .menu-link {
                display: flex; align-items: center; justify-content: space-between;
                padding: 15px; background: rgba(255,255,255,0.03); border-radius: 10px;
                border: 1px solid rgba(255,255,255,0.05); margin-bottom: 10px; cursor: pointer;
            }
            .menu-link:hover { border-color: #00c2ff; }
            .menu-link i { color: #00c2ff; font-size: 18px; margin-right: 10px; width: 24px; text-align: center; }
            .menu-link span { font-size: 15px; font-weight: 500; }
        `}</style>

        <header>
            <button onClick={() => navigate(-1)}><i className="fa-solid fa-arrow-left"></i></button>
            <h1>Administrar Grupo</h1>
        </header>

        <div className="tabs-container">
            <button className={`tab-btn ${activeTab === 'geral' ? 'active' : ''}`} onClick={() => setActiveTab('geral')}>Geral</button>
            <button className={`tab-btn ${activeTab === 'membros' ? 'active' : ''}`} onClick={() => setActiveTab('membros')}>Membros</button>
            <button className={`tab-btn ${activeTab === 'regras' ? 'active' : ''}`} onClick={() => setActiveTab('regras')}>Regras</button>
            <button className={`tab-btn ${activeTab === 'acoes' ? 'active' : ''}`} onClick={() => setActiveTab('acoes')}>Ações</button>
        </div>

        <main>
            {/* TAB: GERAL */}
            {activeTab === 'geral' && (
                <div className="animate-fade-in">
                    {isAdmin ? (
                        <div className="card">
                            <div className="cover-wrapper" onClick={() => document.getElementById('coverInput')?.click()}>
                                {coverPreview ? (
                                    <img src={coverPreview} className="cover-img" alt="Cover" />
                                ) : (
                                    <div className="cover-img" style={{background: '#333', display:'flex', alignItems:'center', justifyContent:'center'}}>
                                        <i className="fa-solid fa-users text-2xl text-gray-500"></i>
                                    </div>
                                )}
                                <div className="cover-edit-badge"><i className="fa-solid fa-pen"></i></div>
                                <input type="file" id="coverInput" hidden accept="image/*" onChange={handleCoverChange} />
                            </div>

                            <div className="input-group">
                                <label className="input-label">Nome do Grupo</label>
                                <input 
                                    type="text" 
                                    className="input-field" 
                                    value={editName} 
                                    onChange={(e) => setEditName(e.target.value)} 
                                />
                            </div>

                            <div className="input-group">
                                <label className="input-label">Descrição</label>
                                <textarea 
                                    className="input-field" 
                                    value={editDesc} 
                                    onChange={(e) => setEditDesc(e.target.value)} 
                                />
                            </div>

                            <button className="save-btn" onClick={handleSaveGeneral}>Salvar Alterações</button>
                        </div>
                    ) : (
                        <div className="card" style={{textAlign:'center', color:'#aaa'}}>
                            <p>Apenas administradores podem editar as informações principais.</p>
                        </div>
                    )}
                </div>
            )}

            {/* TAB: MEMBROS */}
            {activeTab === 'membros' && (
                <div className="animate-fade-in">
                    <div className="card">
                        <div className="search-bar">
                            <i className="fa-solid fa-magnifying-glass"></i>
                            <input 
                                type="text" 
                                className="input-field" 
                                placeholder="Buscar membro..." 
                                value={memberSearch}
                                onChange={(e) => setMemberSearch(e.target.value)}
                            />
                        </div>
                        
                        <div style={{fontSize:'12px', color:'#00c2ff', marginBottom:'10px', fontWeight:'600'}}>
                            TOTAL: {members.length}
                        </div>

                        {filteredMembers.map(member => (
                            <div key={member.id} className="member-item">
                                {member.avatar ? (
                                    <img src={member.avatar} className="member-avatar" alt={member.name} />
                                ) : (
                                    <div className="member-avatar"><i className="fa-solid fa-user text-gray-500"></i></div>
                                )}
                                <div className="member-info">
                                    <div className="member-name">
                                        {member.name}
                                        {member.role === 'Admin' && <span className="member-role">Admin</span>}
                                    </div>
                                </div>
                                {isAdmin && !member.isMe && (
                                    <button className="btn-action btn-remove" onClick={() => handleRemoveMember(member.id)}>
                                        <i className="fa-solid fa-ban"></i>
                                    </button>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* TAB: REGRAS */}
            {activeTab === 'regras' && (
                <div className="animate-fade-in">
                    <div className="card">
                        <div className="toggle-row">
                            <div className="toggle-label">
                                <h4>Notificações do Grupo</h4>
                                <p>Receber alertas de mensagens</p>
                            </div>
                            <label className="switch">
                                <input type="checkbox" checked={settings.notifications} onChange={() => handleToggleSetting('notifications')} />
                                <span className="slider"></span>
                            </label>
                        </div>

                        {isAdmin && (
                            <>
                                <div className="toggle-row">
                                    <div className="toggle-label">
                                        <h4>Apenas Admins postam</h4>
                                        <p>Membros apenas leem mensagens</p>
                                    </div>
                                    <label className="switch">
                                        <input type="checkbox" checked={settings.onlyAdminsPost} onChange={() => handleToggleSetting('onlyAdminsPost')} />
                                        <span className="slider"></span>
                                    </label>
                                </div>

                                <div className="toggle-row">
                                    <div className="toggle-label">
                                        <h4>Aprovar Novos Membros</h4>
                                        <p>Entrada mediante aceitação</p>
                                    </div>
                                    <label className="switch">
                                        <input type="checkbox" checked={settings.approveMembers} onChange={() => handleToggleSetting('approveMembers')} />
                                        <span className="slider"></span>
                                    </label>
                                </div>
                            </>
                        )}
                    </div>
                    
                    {isAdmin && (
                        <div className="menu-link" onClick={() => navigate(`/group-limits/${id}`)}>
                            <div style={{display:'flex', alignItems:'center'}}>
                                <i className="fa-solid fa-sliders"></i>
                                <span>Controles Avançados e Limites</span>
                            </div>
                            <i className="fa-solid fa-chevron-right text-gray-500" style={{fontSize:'14px'}}></i>
                        </div>
                    )}
                </div>
            )}

            {/* TAB: AÇÕES */}
            {activeTab === 'acoes' && (
                <div className="animate-fade-in">
                    <div className="menu-link" onClick={() => navigate(`/group-links/${id}`)}>
                        <div style={{display:'flex', alignItems:'center'}}>
                            <i className="fa-solid fa-link"></i>
                            <span>Links de Convite</span>
                        </div>
                        <i className="fa-solid fa-chevron-right text-gray-500" style={{fontSize:'14px'}}></i>
                    </div>

                    <div className="menu-link" onClick={() => navigate(`/group-chat/${id}`)}>
                        <div style={{display:'flex', alignItems:'center'}}>
                            <i className="fa-regular fa-comment-dots"></i>
                            <span>Ir para o Chat</span>
                        </div>
                        <i className="fa-solid fa-chevron-right text-gray-500" style={{fontSize:'14px'}}></i>
                    </div>

                    <div style={{marginTop: '30px'}}>
                        <button className="danger-btn" onClick={() => {
                            if(window.confirm('Sair do grupo?')) {
                                groupService.leaveGroup(id!);
                                navigate('/groups');
                            }
                        }}>
                            <i className="fa-solid fa-arrow-right-from-bracket"></i> Sair do Grupo
                        </button>

                        {isAdmin && (
                            <button className="danger-btn" style={{marginTop:'10px', borderColor:'#ff0000', background:'rgba(255,0,0,0.1)'}} onClick={handleDeleteGroup}>
                                <i className="fa-solid fa-trash"></i> Apagar Grupo Permanentemente
                            </button>
                        )}
                    </div>
                </div>
            )}
        </main>
    </div>
  );
};
