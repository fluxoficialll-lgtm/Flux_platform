
/**
 * Configurações de Autenticação (Backend)
 * 
 * SEGURANÇA: As chaves secretas devem ser carregadas de variáveis de ambiente.
 * Nunca comite chaves reais no código fonte.
 */

export const googleAuthConfig = {
    // Chave Pública (Pode ser usada no Frontend/Vite)
    clientId: process.env.GOOGLE_CLIENT_ID || "302886927628-1ubai85cjaabnud3j18b62fmjvk7m91q.apps.googleusercontent.com",
    
    // Chave Privada (MANTER APENAS NO BACKEND E EM ENV VARS)
    // Em produção, certifique-se de definir GOOGLE_CLIENT_SECRET no ambiente do servidor
    clientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
    
    redirectUri: process.env.APP_URL || "http://localhost:3000"
};
