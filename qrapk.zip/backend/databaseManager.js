
import pg from 'pg';
import cassandra from 'cassandra-driver';
import Redis from 'ioredis';

// Estado da Conexão
const state = {
    pg: false,
    scylla: false,
    redis: false
};

// 1. CONEXÃO RELACIONAL (PostgreSQL) - Usuários, Financeiro
const pgPool = new pg.Pool({
    user: process.env.PG_USER || 'flux_admin',
    host: process.env.PG_HOST || 'localhost',
    database: process.env.PG_DB || 'flux_core',
    password: process.env.PG_PASSWORD || 'flux_password_secure',
    port: 5432,
    max: 50, // Aumentado para escala
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000, // Fail fast para fallback
});

// 2. CONEXÃO NO-SQL (ScyllaDB) - Posts, Feed, Chat (Big Data)
const scyllaClient = new cassandra.Client({
    contactPoints: [process.env.SCYLLA_HOST || 'localhost'],
    localDataCenter: 'datacenter1',
    keyspace: 'flux_data',
    pooling: {
        coreConnectionsPerHost: {
            [cassandra.types.distance.local]: 4,
            [cassandra.types.distance.remote]: 2
        } 
    },
    socketOptions: { connectTimeout: 2000 } // Fail fast
});

// 3. CACHE (Redis)
const redisClient = new Redis({
    host: process.env.REDIS_HOST || 'localhost',
    port: 6379,
    connectTimeout: 2000,
    retryStrategy: (times) => Math.min(times * 50, 2000)
});

const initDatabases = async () => {
    try {
        // Postgres Init
        await pgPool.query('SELECT NOW()');
        state.pg = true;
        console.log('✅ PostgreSQL Conectado (Produção Ready)');
        
        // Inicializa tabelas essenciais se não existirem
        await pgPool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                email VARCHAR(255) UNIQUE NOT NULL,
                data JSONB
            );
            CREATE TABLE IF NOT EXISTS groups (
                id VARCHAR(50) PRIMARY KEY,
                data JSONB
            );
        `);

    } catch (e) { console.warn('⚠️ PostgreSQL offline (Usando Memória)'); }

    try {
        // Redis Init
        await redisClient.ping();
        state.redis = true;
        console.log('✅ Redis Conectado (Cache Ready)');
    } catch (e) { console.warn('⚠️ Redis offline (Sem Cache)'); }

    try {
        // Scylla Init (Requires keyspace creation manually or via init script usually)
        await scyllaClient.connect();
        state.scylla = true;
        console.log('✅ ScyllaDB Conectado (Big Data Ready)');
        
        // Schema básico para Posts (Time Series)
        await scyllaClient.execute(`
            CREATE TABLE IF NOT EXISTS posts (
                id text,
                timestamp bigint,
                data text,
                PRIMARY KEY (id, timestamp)
            ) WITH CLUSTERING ORDER BY (timestamp DESC);
        `);
    } catch (e) { console.warn('⚠️ ScyllaDB offline (Usando Mock de Posts)'); }
};

// --- Data Access Object (DAO) ---

export const dbManager = {
    init: initDatabases,
    state, // Expor estado para o server.js decidir entre DB ou Mock

    posts: {
        // ScyllaDB é otimizado para Time Series (Feed)
        async list(limit = 20, cursor = Date.now()) {
            if (!state.scylla) return null; // Retorna null para ativar fallback
            try {
                const query = 'SELECT data FROM posts WHERE timestamp < ? LIMIT ? ALLOW FILTERING';
                const result = await scyllaClient.execute(query, [cursor, limit], { prepare: true });
                return result.rows.map(row => JSON.parse(row.data));
            } catch (e) {
                console.error("Scylla Error:", e);
                return null;
            }
        },
        async create(post) {
            if (!state.scylla) return null;
            try {
                const query = 'INSERT INTO posts (id, timestamp, data) VALUES (?, ?, ?)';
                await scyllaClient.execute(query, [post.id, post.timestamp, JSON.stringify(post)], { prepare: true });
                return true;
            } catch (e) { return false; }
        }
    },

    groups: {
        async list() {
            if (!state.pg) return null;
            try {
                const res = await pgPool.query('SELECT data FROM groups LIMIT 50');
                return res.rows.map(r => r.data);
            } catch (e) { return null; }
        },
        async create(group) {
            if (!state.pg) return null;
            try {
                await pgPool.query('INSERT INTO groups (id, data) VALUES ($1, $2)', [group.id, group]);
                return true;
            } catch (e) { return false; }
        }
    },

    users: {
        async findByEmail(email) {
            if (!state.pg) return null;
            try {
                const res = await pgPool.query('SELECT data FROM users WHERE email = $1', [email]);
                return res.rows[0]?.data;
            } catch (e) { return null; }
        }
    }
};
