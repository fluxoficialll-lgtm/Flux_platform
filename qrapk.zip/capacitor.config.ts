import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.flux.app',
  appName: 'Flux',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    // Configurações adicionais de plugins viriam aqui
  }
};

export default config;