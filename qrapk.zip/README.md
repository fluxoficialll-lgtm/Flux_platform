
<div align="center">
<img width="1200" height="475" alt="Flux Platform" src="https://github.com/user-attachments/assets/0aa67016-6eaf-458a-adb2-6e31a0763ed6" />
</div>

# Flux Platform (Scalable Architecture)

Aplicação moderna preparada para alta escala (50M+ usuários) utilizando arquitetura API-First com Fallback Local.

## 🚀 Como Rodar (Desenvolvimento Local)

1.  **Instalar dependências:**
    ```bash
    npm install
    ```

2.  **Iniciar Frontend + Backend (Modo Dev):**
    ```bash
    npm run dev
    ```
    *Acesse http://localhost:5173*

3.  **Iniciar Infraestrutura Real (Opcional, Recomendado para testes de carga):**
    ```bash
    npm run db:up
    # Inicia PostgreSQL, ScyllaDB, Redis e Elasticsearch via Docker
    ```

---

## ☁️ Como Hospedar (Deployment)

A aplicação está configurada como um **Monólito Modular**. O servidor Node.js (`server.js`) serve tanto a API quanto os arquivos estáticos do Frontend (React). Isso facilita o deployment em plataformas como Render, Railway ou Heroku.

### Opção 1: Render.com (Recomendado)

1.  Crie uma conta no [Render](https://render.com).
2.  Clique em **New +** -> **Web Service**.
3.  Conecte seu repositório GitHub/GitLab.
4.  Use as configurações:
    *   **Build Command:** `npm install && npm run build`
    *   **Start Command:** `npm start`
5.  Adicione as variáveis de ambiente (Environment Variables):
    *   `NODE_ENV`: `production`
    *   `GEMINI_API_KEY`: (Sua chave da Google AI)

### Opção 2: Railway.app

1.  Crie um projeto no [Railway](https://railway.app).
2.  Faça deploy do repositório.
3.  O Railway detectará automaticamente o `package.json` e usará `npm start`.
4.  (Opcional) Adicione serviços de banco de dados (Postgres, Redis) dentro do próprio Railway e conecte as variáveis de ambiente.

---

## 🏗️ Arquitetura

*   **Frontend:** React 19 + Vite (SPA). Otimizado com Code Splitting e Lazy Loading.
*   **Backend:** Node.js + Express Cluster. Atua como API Gateway e Servidor de Arquivos Estáticos.
*   **Dados:** 
    *   *Modo Cloud:* Conecta-se a serviços externos (AWS/GCP/Supabase).
    *   *Modo Fallback:* Se o banco de dados não estiver disponível, o sistema usa mocks em memória e SQLite local (WASM) para garantir que a UI nunca quebre.

## 🛠️ Comandos Úteis

*   `npm run build`: Compila o Frontend para a pasta `dist/`.
*   `npm start`: Inicia o servidor de produção (requer build prévio).
