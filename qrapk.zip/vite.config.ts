
import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, '.', '');
    
    // Em produção (APK), usamos a URL definida no ambiente ou hardcoded se necessário
    const apiUrl = process.env.VITE_API_URL || 'http://localhost:3000';
    
    return {
      server: {
        port: 5173,
        host: '0.0.0.0',
        proxy: {
          '/api': {
            target: 'http://localhost:3000',
            changeOrigin: true,
            secure: false
          },
          '/uploads': {
            target: 'http://localhost:3000',
            changeOrigin: true,
            secure: false
          }
        }
      },
      build: {
        outDir: 'dist',
        assetsDir: 'assets',
        sourcemap: false,
        minify: 'terser', 
        terserOptions: {
            compress: {
                drop_console: true, 
                drop_debugger: true
            }
        },
        rollupOptions: {
            output: {
                manualChunks: {
                    'vendor-react': ['react', 'react-dom', 'react-router-dom'],
                    'vendor-ui': ['@fortawesome/fontawesome-free'],
                    'vendor-utils': ['sql.js'] 
                }
            }
        }
      },
      plugins: [react()],
      define: {
        'process.env.API_KEY': JSON.stringify(env.GEMINI_API_KEY),
        'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY),
        'process.env.GOOGLE_CLIENT_ID': JSON.stringify("302886927628-1ubai85cjaabnud3j18b62fmjvk7m91q.apps.googleusercontent.com"),
        // Injeta a URL da API no código do frontend para que o APK saiba onde bater
        'process.env.VITE_API_URL': JSON.stringify(apiUrl)
      },
      resolve: {
        alias: {
          '@': path.resolve(__dirname),
        }
      }
    };
});