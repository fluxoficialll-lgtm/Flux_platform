
export interface User {
  email: string;
  password?: string; // stored for mock purposes
  isVerified: boolean;
  isProfileCompleted: boolean;
  profile?: UserProfile;
  googleId?: string;
  paymentConfig?: PaymentProviderConfig; // New: Store provider settings
  notificationSettings?: NotificationSettings; // New
  securitySettings?: SecuritySettings; // New
  lastSeen?: number; // Timestamp for Online status
  sessions?: UserSession[];
  changeHistory?: ChangeHistory;
}

export interface UserSession {
    id: string;
    device: string;
    location: string;
    timestamp: number;
    isActive: boolean;
}

export interface ChangeHistory {
    usernameChanges: number[];
    nicknameChanges: number[];
}

export interface NotificationSettings {
    pauseAll: boolean;
    likes: boolean;
    comments: boolean;
    followers: boolean;
    mentions: boolean;
    messages: boolean;
    email: boolean;
    groups: boolean;
}

export interface SecuritySettings {
    twoFactorEnabled: boolean;
    saveLoginInfo: boolean;
}

export interface UserProfile {
  name: string; // unique, lowercase (@username)
  nickname?: string; // Display Name (Apelido) - Optional
  bio?: string;
  website?: string; // New: Link no perfil
  photoUrl?: string;
  isPrivate: boolean;
  // Required for Real Payments
  cpf?: string;
  phone?: string;
}

export interface PaymentProviderConfig {
    providerId: string; // 'syncpay' | 'suitpay' | 'mercadopago' 
    clientId?: string; // SyncPay specific
    clientSecret?: string; // SyncPay specific
    accessToken?: string; // Stored JWT/Token
    tokenExpiresAt?: number; // Timestamp
    publicKey?: string; // Legacy
    privateKey?: string; // Legacy
    isConnected: boolean;
}

export interface VerificationSession {
  code: string;
  expiresAt: number; // timestamp
  attempts: number;
}

export interface LockoutState {
  attempts: number;
  blockedUntil: number | null;
}

export interface PollOption {
  text: string;
  votes: number;
}

export interface Comment {
  id: string;
  username: string;
  avatar?: string;
  text: string;
  timestamp: number;
  likes?: number; // New
  likedByMe?: boolean; // New
  replies?: Comment[]; // New
}

export interface Post {
  id: string;
  type: 'photo' | 'poll' | 'text' | 'video';
  username: string;
  text: string;
  image?: string; // Base64 or URL (Primary/Thumbnail)
  images?: string[]; // New: Array for Carousel
  video?: string; // Base64 or URL
  avatar?: string;
  isPublic: boolean;
  isAdultContent?: boolean; // New: 18+ Content Flag
  time: string; // Display string like "Agora" or "10m"
  timestamp: number; // For sorting
  views: number;
  viewedBy?: string[]; // New: Array of user emails who viewed this
  likes: number;
  comments: number;
  liked: boolean;
  pollOptions?: PollOption[];
  votedOptionIndex?: number | null;
  commentsList?: Comment[]; // New: Store actual comments
  title?: string; // New: For Reels/Posts title
  location?: string; // New: For Location Filtering
}

export interface Story {
    id: string;
    username: string;
    userAvatar?: string;
    mediaUrl: string;
    type: 'image' | 'video';
    timestamp: number;
    viewed: boolean;
}

export interface PaginatedResponse<T> {
    data: T[];
    nextCursor?: number;
}

export interface VipMediaItem {
  url: string;
  type: 'image' | 'video';
}

export interface GroupLink {
  id: string;
  name: string; // Identifier (e.g., "Instagram Bio")
  code: string; // Unique hash
  joins: number; // Stat counter
  createdAt: number;
  maxUses?: number; // Maximum number of joins allowed
  expiresAt?: string; // Expiration date string
}

export interface GroupSettingsConfig {
    memberLimit?: number;
    onlyAdminsPost?: boolean;
    msgSlowMode?: boolean;
    msgSlowModeInterval?: number;
    approveMembers?: boolean;
    joinSlowMode?: boolean;
    joinSlowModeInterval?: number;
    forbiddenWords?: string[];
}

export interface Group {
  id: string;
  name: string;
  description: string;
  coverImage?: string; // Base64
  isVip: boolean;
  isPrivate?: boolean; // New property for Private groups
  price?: string;
  currency?: 'BRL' | 'USD' | 'EUR' | 'BTC'; // New property for Currency
  accessType?: 'lifetime' | 'temporary';
  expirationDate?: string;
  vipDoor?: {
    media?: string; // Base64 (Legacy)
    mediaType?: 'image' | 'video' | null; // (Legacy)
    mediaItems?: VipMediaItem[]; // New: Array of media
    text?: string;
  };
  lastMessage?: string; // For preview
  time?: string; // For preview
  creatorEmail?: string; // Identifies the owner of the group
  links?: GroupLink[]; // New: List of invite links
  
  // New: Membership and Settings
  members?: string[]; // Array of user emails
  pendingMembers?: string[]; // New: For private groups
  bannedUsers?: string[]; // New: Real ban system
  admins?: string[]; // New: Real admin system (besides creator)
  settings?: GroupSettingsConfig;
}

// --- Backend Types ---

export interface NotificationItem {
  id: number;
  type: 'like' | 'comment' | 'follow' | 'mention' | 'sale' | 'pending';
  subtype?: 'friend' | 'group_join' | 'group_invite';
  username: string; // Quem gerou a notificação
  time: string;
  timestamp: number;
  avatar: string;
  text?: string;
  postImage?: string;
  isFollowing?: boolean;
  recipientEmail: string; // Para quem é a notificação
  read: boolean;
}

export interface Relationship {
  followerEmail: string;
  followingUsername: string; // Using username as ID for following
  status: 'pending' | 'accepted';
}

export interface ChatMessage {
    id: number;
    text: string;
    type: 'sent' | 'received';
    contentType: 'text' | 'audio' | 'image' | 'video';
    mediaUrl?: string; // New field for attachments
    timestamp: string;
    status: 'sent' | 'delivered' | 'read';
    duration?: string;
    // New fields for Groups
    senderName?: string;
    senderAvatar?: string;
    senderEmail?: string;
}

export interface ChatData {
    id: string | number;
    contactName: string;
    isBlocked: boolean;
    messages: ChatMessage[];
}

// --- Payment & Access Types ---

export interface VipAccess {
    userId: string; // Email
    groupId: string;
    status: 'active' | 'expired';
    purchaseDate: number;
    transactionId: string;
}

export interface SyncPayTransaction {
    identifier: string;
    pixCode: string;
    amount: number;
    status: 'pending' | 'paid' | 'expired' | 'completed' | 'withdrawal'; // Added withdrawal
    clientId: string; // Quem pagou (Email do cliente)
    ownerId: string; // Quem recebe (Email do dono do grupo)
    groupId: string;
    platformFee: number;
    ownerNet: number;
    timestamp: number;
    pixKey?: string; // For withdrawals
}

export enum AuthError {
  USER_NOT_FOUND = "Gmail não existe",
  WRONG_PASSWORD = "Senha incorreta",
  EMAIL_NOT_VERIFIED = "Verifique seu email",
  INVALID_FORMAT = "Formato inválido",
  ALREADY_EXISTS = "Email já cadastrado",
  PASSWORD_TOO_SHORT = "Senha muito curta",
  PASSWORDS_DONT_MATCH = "Senhas não coincidem",
  TERMS_REQUIRED = "Aceite os termos",
  CODE_INVALID = "Código incorreto",
  CODE_EXPIRED = "Código expirado",
  TOO_MANY_ATTEMPTS = "Muitas tentativas. Bloqueado por 24h.",
  NAME_TAKEN = "Nome indisponível",
  NAME_REQUIRED = "Nome obrigatório",
  GENERIC = "Ocorreu um erro"
}